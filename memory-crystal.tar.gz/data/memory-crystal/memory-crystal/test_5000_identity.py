# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import json
import os
from pathlib import Path

BUILD_ROOT = Path(__file__).resolve().parent.parent / "build"
BASE = BUILD_ROOT / "process_baseline"
CANDIDATE_ROOT = BUILD_ROOT / "p0"

TARGETS = {
    "sleep": "/bin/sleep",
    "cat":   "/bin/cat",
    "echo":  "/bin/echo",
}


def parse_maps(path):
    data = json.loads(path.read_text())

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("mappings", "maps", "records"):
            if isinstance(data.get(key), list):
                return data[key]

    raise RuntimeError(f"Unsupported maps format: {path}")


def load_reference_run(name, run):
    root = BASE / name / f"run{run:02d}"

    memory = (root / "memory.bin").read_bytes()

    # The original 40-process experiment intentionally treated P0
    # as one contiguous normalized memory image.  Preserve that
    # exact model here.
    return memory


def build_reference_crystal(name):
    memories = [
        load_reference_run(name, r)
        for r in range(1, 5)
    ]

    hidden = load_reference_run(name, 5)

    if len({len(x) for x in memories}) != 1:
        raise RuntimeError(
            f"REFERENCE SIZE MISMATCH for {name}"
        )

    size = len(memories[0])

    invariant = bytearray(size)
    mask = bytearray(size)

    for i in range(size):
        value = memories[0][i]

        if all(m[i] == value for m in memories[1:]):
            invariant[i] = value
            mask[i] = 1

    return {
        "size": size,
        "invariant": invariant,
        "mask": mask,
    }, hidden


def mapping_blob(root, index, start, length=None):
    if length is not None:
        exact = root / f"{start:016x}_{length:x}.bin"

        if exact.exists() and exact.stat().st_size == length:
            return exact

    prefix = f"{start:016x}_"

    for p in root.glob(prefix + "*.bin"):
        if length is None or p.stat().st_size == length:
            return p

    if length is not None:
        for p in root.rglob(f"{start:016x}_{length:x}.bin"):
            if p.is_file() and p.stat().st_size == length:
                return p

    return None


def load_candidate(d):
    metadata = json.loads(
        (d / "metadata.json").read_text()
    )

    maps = parse_maps(d / "maps.json")

    # Reconstruct the exact contiguous P0 memory image used by
    # the original 40-process algorithm.
    chunks = []

    for index, m in enumerate(maps):
        start = int(m["start"])
        end = int(m["end"])
        length = end - start

        blob = mapping_blob(
            d,
            index,
            start,
            length
        )

        if blob is None:
            continue

        data = blob.read_bytes()

        if len(data) != length:
            continue

        chunks.append(data)

    memory = b"".join(chunks)

    # A single acquired P0 observation has no empirical variance
    # model of its own.  Every byte observed in that one capture is
    # therefore available for comparison.
    mask = bytearray(b"\x01") * len(memory)

    return {
        "metadata": metadata,
        "memory": memory,
        "size": len(memory),
        "mask": mask,
    }


def candidate_directories():
    return sorted(
        d for d in CANDIDATE_ROOT.iterdir()
        if d.is_dir()
        and (d / "metadata.json").exists()
        and (d / "maps.json").exists()
    )


def compare(sample, target):
    size = min(
        len(sample),
        target["size"]
    )

    mask = target["mask"]
    inv = target["invariant"]

    matched = 0
    tested = 0

    for i in range(size):
        if mask[i]:
            tested += 1

            if sample[i] == inv[i]:
                matched += 1

    pct = (
        matched / tested * 100.0
        if tested else 0.0
    )

    return matched, tested, pct


def main():
    print("=" * 72)
    print("5000-PROCESS MEMORY IDENTITY TEST")
    print("=" * 72)
    print()
    print("Reference: 4-run empirical P0 crystal")
    print("Hidden sample: run05")
    print("Candidate universe: acquired P0 corpus")
    print()

    candidates = candidate_directories()

    print(f"Candidates: {len(candidates):,}")
    print()

    for target, expected_path in TARGETS.items():

        print("=" * 72)
        print(f"TARGET:   {target}")
        print(f"EXPECTED: {expected_path}")
        print("=" * 72)

        crystal, hidden = build_reference_crystal(target)

        deterministic_count = sum(
            crystal["mask"]
        )

        print(f"Crystal regions:     {len(crystal):,}")
        print(f"Deterministic bytes: {deterministic_count:,}")
        print()

        if not crystal["size"]:
            raise RuntimeError(
                f"REFERENCE CRYSTAL EMPTY for {target}; "
                f"not scanning candidates"
            )

        results = []

        for n, d in enumerate(candidates, 1):
            try:
                candidate = load_candidate(d)

                matched, compared, pct = compare(
                    candidate["memory"],
                    crystal
                )

                metadata = candidate["metadata"]

                results.append({
                    "dir": d,
                    "name": metadata.get("name", d.name),
                    "path": metadata.get("path", ""),
                    "compared": compared,
                    "matched": matched,
                    "pct": pct,
                })

            except Exception as e:
                print(f"[WARN] {d.name}: {e}")

            if n % 500 == 0:
                print(
                    f"  scanned {n:,}/{len(candidates):,}"
                )

        results.sort(
            key=lambda x: (x["pct"], x["compared"]),
            reverse=True
        )

        print()
        print("TOP 10 MEMORY MATCHES")
        print()

        for rank, r in enumerate(results[:10], 1):
            print(
                f"{rank:2d}. "
                f"{r['name']:<30} "
                f"{r['pct']:9.4f}% "
                f"{r['matched']:>8,}/"
                f"{r['compared']:<8,} "
                f"{r['path']}"
            )

        print()

        expected_real = os.path.realpath(expected_path)

        expected_rows = []

        for rank, r in enumerate(results, 1):
            if os.path.realpath(r["path"]) == expected_real:
                expected_rows.append((rank, r))

        print("EXPECTED PROCESS RESULT")

        if expected_rows:
            rank, r = expected_rows[0]

            print(f"rank:     {rank}/{len(results)}")
            print(f"match:    {r['pct']:.4f}%")
            print(
                f"bytes:    "
                f"{r['matched']:,}/"
                f"{r['compared']:,}"
            )
            print(f"candidate: {r['path']}")

            if rank > 1:
                above = results[rank - 2]

                print()
                print("NEAREST CANDIDATE ABOVE IT")
                print(f"name:     {above['name']}")
                print(f"path:     {above['path']}")
                print(f"match:    {above['pct']:.4f}%")
                print(
                    f"bytes:    "
                    f"{above['matched']:,}/"
                    f"{above['compared']:,}"
                )

        else:
            print(
                "EXPECTED PROCESS NOT PRESENT "
                "IN ACQUIRED P0 CORPUS"
            )

        print()


if __name__ == "__main__":
    main()