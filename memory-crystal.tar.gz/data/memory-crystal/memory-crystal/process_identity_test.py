# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import json
import hashlib
from pathlib import Path
from collections import defaultdict

BUILD_ROOT = Path(__file__).resolve().parent.parent / "build"
BASES = [
    BUILD_ROOT / "process_baseline",
    BUILD_ROOT / "process_baseline2",
]

def load_processes():
    processes = {}

    for base in BASES:
        if not base.exists():
            continue

        for proc in sorted(base.iterdir()):
            if not proc.is_dir():
                continue

            runs = sorted(proc.glob("run*/memory.bin"))

            if len(runs) < 5:
                continue

            memories = [p.read_bytes() for p in runs]

            if len({len(x) for x in memories}) != 1:
                continue

            size = len(memories[0])

            # Determine bytes invariant across all five launches.
            invariant = bytearray(size)
            mask = bytearray(size)

            for i in range(size):
                v = memories[0][i]

                if all(m[i] == v for m in memories[1:]):
                    invariant[i] = v
                    mask[i] = 1

            meta = json.loads(
                (proc / "run01" / "metadata.json").read_text()
            )

            processes[proc.name] = {
                "memories": memories,
                "size": size,
                "invariant": invariant,
                "mask": mask,
                "elf": meta.get("path", proc.name),
            }

    return processes

def compare(sample, target):
    size = min(len(sample), target["size"])

    mask = target["mask"]
    inv = target["invariant"]

    matched = 0
    tested = 0

    for i in range(size):
        if mask[i]:
            tested += 1
            if sample[i] == inv[i]:
                matched += 1

    return matched, tested

def main():
    processes = load_processes()

    print(f"KNOWN PROCESSES: {len(processes)}")
    print()

    # Use run05 as the hidden sample for every process.
    # Compare it against crystals built from runs01-04.
    for name, target in sorted(processes.items()):

        training = target["memories"][:4]
        sample = target["memories"][4]

        size = target["size"]

        invariant = bytearray(size)
        mask = bytearray(size)

        for i in range(size):
            v = training[0][i]

            if all(m[i] == v for m in training[1:]):
                invariant[i] = v
                mask[i] = 1

        results = []

        for candidate, c in processes.items():
            matched = 0
            tested = 0

            maxsize = min(size, c["size"])

            for i in range(maxsize):
                if mask[i] and c["mask"][i]:
                    tested += 1

                    if sample[i] == c["invariant"][i]:
                        matched += 1

            pct = (matched / tested * 100.0) if tested else 0.0

            results.append(
                (pct, matched, tested, candidate)
            )

        results.sort(reverse=True)

        print("=" * 72)
        print(f"HIDDEN SAMPLE: {name}")
        print(f"P0 SIZE:       {size:,}")
        print()
        print("TOP CANDIDATES")
        print()

        for pct, matched, tested, candidate in results[:8]:
            marker = " <==" if candidate == name else ""
            print(
                f"{candidate:15s} "
                f"{pct:8.4f}% "
                f"{matched:7,}/{tested:,}{marker}"
            )

        rank = [
            candidate for _, _, _, candidate in results
        ].index(name) + 1

        print()
        print(f"TRUE IDENTITY RANK: {rank}/{len(results)}")
        print()

if __name__ == "__main__":
    main()