#include <errno.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <bpf/libbpf.h>
#include <bpf/bpf.h>

struct register_snapshot {
    uint32_t pid;
    uint32_t tid;

    uint64_t ip;
    uint64_t ax;
    uint64_t bx;
    uint64_t cx;
    uint64_t dx;
    uint64_t si;
    uint64_t di;
    uint64_t bp;
    uint64_t sp;

    uint64_t r8;
    uint64_t r9;
    uint64_t r10;
    uint64_t r11;
    uint64_t r12;
    uint64_t r13;
    uint64_t r14;
    uint64_t r15;
};

struct transform_event {
    uint32_t pid;
    uint32_t uid;
    uint32_t flags;
    uint32_t match;

    uint64_t target_dev;
    uint64_t target_ino;
    uint64_t target_parent_dev;
    uint64_t target_parent_ino;

    uint64_t read_count;
    uint64_t final_count;

    char comm[16];
};

static volatile sig_atomic_t stopping;

static void handle_signal(int sig)
{
    (void)sig;
    stopping = 1;
}

static int handle_event(void *ctx, void *data, size_t size)
{
    const struct register_snapshot *e = data;

    (void)ctx;

    if (size != sizeof(*e)) {
        fprintf(stderr,
                "unexpected event size: %zu\n",
                size);
        return 0;
    }

    printf(
        "{\"pid\":%u,"
        "\"tid\":%u,"
        "\"ip\":\"0x%llx\","
        "\"rax\":\"0x%llx\","
        "\"rbx\":\"0x%llx\","
        "\"rcx\":\"0x%llx\","
        "\"rdx\":\"0x%llx\","
        "\"rsi\":\"0x%llx\","
        "\"rdi\":\"0x%llx\","
        "\"rbp\":\"0x%llx\","
        "\"rsp\":\"0x%llx\","
        "\"r8\":\"0x%llx\","
        "\"r9\":\"0x%llx\","
        "\"r10\":\"0x%llx\","
        "\"r11\":\"0x%llx\","
        "\"r12\":\"0x%llx\","
        "\"r13\":\"0x%llx\","
        "\"r14\":\"0x%llx\","
        "\"r15\":\"0x%llx\"}\n",
        e->pid,
        e->tid,
        (unsigned long long)e->ip,
        (unsigned long long)e->ax,
        (unsigned long long)e->bx,
        (unsigned long long)e->cx,
        (unsigned long long)e->dx,
        (unsigned long long)e->si,
        (unsigned long long)e->di,
        (unsigned long long)e->bp,
        (unsigned long long)e->sp,
        (unsigned long long)e->r8,
        (unsigned long long)e->r9,
        (unsigned long long)e->r10,
        (unsigned long long)e->r11,
        (unsigned long long)e->r12,
        (unsigned long long)e->r13,
        (unsigned long long)e->r14,
        (unsigned long long)e->r15
    );

    fflush(stdout);
    return 0;
}

static int handle_transform_event(void *ctx, void *data, size_t size)
{
    const struct transform_event *e = data;

    (void)ctx;

    if (size != sizeof(*e)) {
        fprintf(stderr,
                "unexpected transform event size: %zu\n",
                size);
        return 0;
    }

    printf(
        "[p0-transform-systemwide] BLOCKED "
        "pid=%u "
        "uid=%u "
        "comm=%.*s "
        "operation=final-transform "
        "match=%u "
        "flags=0x%x "
        "target_dev=%llu "
        "target_ino=%llu "
        "parent_dev=%llu "
        "parent_ino=%llu "
        "read_count=%llu "
        "final_count=%llu\n",
        e->pid,
        e->uid,
        16, e->comm,
        e->match,
        e->flags,
        (unsigned long long)e->target_dev,
        (unsigned long long)e->target_ino,
        (unsigned long long)e->target_parent_dev,
        (unsigned long long)e->target_parent_ino,
        (unsigned long long)e->read_count,
        (unsigned long long)e->final_count
    );

    fflush(stdout);
    return 0;
}

static void usage(const char *name)
{
    fprintf(stderr,
        "usage: %s --pid PID --binary PATH "
        "--offset FILE_OFFSET [--seconds N]\n"
        "       %s --enforce\n",
        name, name);
}

int main(int argc, char **argv)
{
    struct bpf_object *obj = NULL;
    struct bpf_program *prog = NULL;
    struct bpf_link *link = NULL;
    struct ring_buffer *ring = NULL;

    pid_t pid = -1;
    const char *binary = NULL;
    long long offset = -1;
    int seconds = 0;
    int enforce = 0;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--pid") && i + 1 < argc) {
            pid = (pid_t)strtol(argv[++i], NULL, 10);
        } else if (!strcmp(argv[i], "--binary") && i + 1 < argc) {
            binary = argv[++i];
        } else if (!strcmp(argv[i], "--offset") && i + 1 < argc) {
            offset = strtoll(argv[++i], NULL, 0);
        } else if (!strcmp(argv[i], "--seconds") && i + 1 < argc) {
            seconds = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--enforce")) {
            enforce = 1;
        } else {
            usage(argv[0]);
            return 2;
        }
    }

    if (!enforce && (pid <= 0 || !binary || offset < 0)) {
        usage(argv[0]);
        return 2;
    }

    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);

    libbpf_set_strict_mode(LIBBPF_STRICT_ALL);

    if (enforce) {
        int events_fd;
        struct ring_buffer *enforce_ring = NULL;

        /*
         * The enforcement LSM programs are already loaded and attached.
         *
         * 19338/19339 -> processes map 4000 + events ringbuf 3999.
         *
         * Do NOT load another object, attach another LSM, or repin
         * anything here. Consume the ringbuf owned by the live instance.
         */
        events_fd = bpf_map_get_fd_by_id(3999);

        if (events_fd < 0) {
            fprintf(stderr,
                    "failed to open transform events map id 3999: %s\n",
                    strerror(errno));
            return 1;
        }

        enforce_ring = ring_buffer__new(
            events_fd,
            handle_transform_event,
            NULL,
            NULL
        );

        if (!enforce_ring) {
            fprintf(stderr,
                    "enforcement ring_buffer__new failed\n");
            close(events_fd);
            return 1;
        }

        fprintf(stderr,
                "transform enforcement event consumer attached: "
                "events_map_id=3999\n");

        while (!stopping) {
            int ret = ring_buffer__poll(enforce_ring, 100);

            if (ret < 0 && ret != -EINTR) {
                fprintf(stderr,
                        "enforcement ring_buffer__poll failed: %d\n",
                        ret);
                break;
            }
        }

        ring_buffer__free(enforce_ring);
        close(events_fd);
        return 0;
    }

    obj = bpf_object__open_file(
        "p0_transform_runtime_bpf.o",
        NULL
    );

    if (!obj) {
        fprintf(stderr, "bpf_object__open_file failed\n");
        return 1;
    }

    if (bpf_object__load(obj)) {
        fprintf(stderr, "bpf_object__load failed\n");
        bpf_object__close(obj);
        return 1;
    }

    prog = bpf_object__find_program_by_name(
        obj,
        "p0_capture_registers"
    );

    if (!prog) {
        fprintf(stderr, "program not found\n");
        bpf_object__close(obj);
        return 1;
    }

    link = bpf_program__attach_uprobe(
        prog,
        false,
        pid,
        binary,
        (size_t)offset
    );

    long link_err = libbpf_get_error(link);
    if (link_err) {
        fprintf(stderr,
                "bpf_program__attach_uprobe failed: %s (%ld)\n",
                strerror(-link_err),
                link_err);
        bpf_object__close(obj);
        return 1;
    }

    struct bpf_map *map =
        bpf_object__find_map_by_name(obj, "events");

    if (!map) {
        fprintf(stderr, "events map not found\n");
        bpf_link__destroy(link);
        bpf_object__close(obj);
        return 1;
    }

    int map_fd = bpf_map__fd(map);

    ring = ring_buffer__new(
        map_fd,
        handle_event,
        NULL,
        NULL
    );

    if (!ring) {
        fprintf(stderr, "ring_buffer__new failed\n");
        bpf_link__destroy(link);
        bpf_object__close(obj);
        return 1;
    }

    fprintf(stderr,
        "attached: pid=%d binary=%s offset=0x%llx\n",
        pid,
        binary,
        offset);

    unsigned int elapsed = 0;

    while (!stopping) {
        int ret = ring_buffer__poll(ring, 100);

        if (ret < 0 && ret != -EINTR) {
            fprintf(stderr,
                    "ring_buffer__poll failed: %d\n",
                    ret);
            break;
        }

        if (seconds > 0) {
            elapsed++;
            if (elapsed >= (unsigned int)seconds * 10)
                break;
        }
    }

    ring_buffer__free(ring);
    bpf_link__destroy(link);
    bpf_object__close(obj);

    return 0;
}
