#include "p0_vmlinux.h"

#include <bpf/bpf_core_read.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>

#ifndef MAY_READ
#define MAY_READ 0x00000004
#endif

#ifndef MAY_WRITE
#define MAY_WRITE 0x00000002
#endif

#define FLAG_TARGET_READ       (1U << 0)
#define FLAG_DATA_MANIPULATION (1U << 1)

#define TRANSFORM_MATCH 1

struct register_snapshot {
    __u32 pid;
    __u32 tid;
    __u64 ip;

    __u64 ax;
    __u64 bx;
    __u64 cx;
    __u64 dx;
    __u64 si;
    __u64 di;
    __u64 bp;
    __u64 sp;

    __u64 r8;
    __u64 r9;
    __u64 r10;
    __u64 r11;
    __u64 r12;
    __u64 r13;
    __u64 r14;
    __u64 r15;
};

struct transform_state {
    __u32 flags;
    __u32 reserved;

    __u64 target_dev;
    __u64 target_ino;

    __u64 target_parent_dev;
    __u64 target_parent_ino;

    __u32 target_name_len;
    __u32 reserved2;

    char target_name[64];

    __u64 read_count;
    __u64 final_count;
    __u64 final_latch;
};

struct transform_event {
    __u32 pid;
    __u32 uid;
    __u32 flags;
    __u32 match;

    __u64 target_dev;
    __u64 target_ino;

    __u64 target_parent_dev;
    __u64 target_parent_ino;

    __u64 read_count;
    __u64 final_count;

    char comm[16];
};

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 20);
} events SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 16384);
    __type(key, __u32);
    __type(value, struct transform_state);
} processes SEC(".maps");

static __always_inline __u32 current_tgid(void)
{
    return (__u32)(bpf_get_current_pid_tgid() >> 32);
}

static __always_inline __u64 inode_dev(struct inode *inode)
{
    struct super_block *sb;

    if (!inode)
        return 0;

    sb = BPF_CORE_READ(inode, i_sb);
    if (!sb)
        return 0;

    return (__u64)BPF_CORE_READ(sb, s_dev);
}

static __always_inline int same_inode(
    struct inode *inode,
    __u64 dev,
    __u64 ino)
{
    if (!inode)
        return 0;

    if (inode_dev(inode) != dev)
        return 0;

    if ((__u64)BPF_CORE_READ(inode, i_ino) != ino)
        return 0;

    return 1;
}

static __always_inline int dentry_name_matches(
    struct dentry *dentry,
    struct transform_state *st)
{
    struct qstr qname;
    __u32 len;

    if (!dentry)
        return 0;

    qname = BPF_CORE_READ(dentry, d_name);
    len = qname.len;

    if (len != st->target_name_len)
        return 0;

#pragma unroll
    for (int i = 0; i < 64; i++) {
        char actual;
        char expected;

        if ((__u32)i >= len)
            break;

        actual = 0;
        expected = st->target_name[i];

        if (bpf_probe_read_kernel(
                &actual,
                sizeof(actual),
                qname.name + i) < 0)
            return 0;

        if (actual != expected)
            return 0;
    }

    return 1;
}

static __always_inline int transform_match(
    struct transform_state *st)
{
    __u64 old_latch;

    if (!(st->flags & FLAG_TARGET_READ))
        return 0;

    if (!(st->flags & FLAG_DATA_MANIPULATION))
        return 0;

    old_latch = __sync_fetch_and_or(
        &st->final_latch,
        1ULL
    );

    if (old_latch & 1ULL)
        return 0;

    return 1;
}

static __always_inline void emit_transform_match(
    __u32 pid,
    struct transform_state *st)
{
    struct transform_event *e;

    e = bpf_ringbuf_reserve(
        &events,
        sizeof(*e),
        0
    );

    if (!e)
        return;

    e->pid = pid;
    e->uid = (__u32)bpf_get_current_uid_gid();
    e->flags = st->flags;
    e->match = TRANSFORM_MATCH;

    e->target_dev = st->target_dev;
    e->target_ino = st->target_ino;

    e->target_parent_dev = st->target_parent_dev;
    e->target_parent_ino = st->target_parent_ino;

    e->read_count = st->read_count;
    e->final_count = st->final_count;

    bpf_get_current_comm(
        e->comm,
        sizeof(e->comm)
    );

    bpf_ringbuf_submit(e, 0);
}

SEC("uprobe")
int p0_capture_registers(struct pt_regs *ctx)
{
    struct register_snapshot *event;
    __u64 pid_tgid;

    pid_tgid = bpf_get_current_pid_tgid();

    event = bpf_ringbuf_reserve(
        &events,
        sizeof(*event),
        0
    );

    if (!event)
        return 0;

    event->pid = pid_tgid >> 32;
    event->tid = (__u32)pid_tgid;
    event->ip = BPF_CORE_READ(ctx, ip);

    event->ax = BPF_CORE_READ(ctx, ax);
    event->bx = BPF_CORE_READ(ctx, bx);
    event->cx = BPF_CORE_READ(ctx, cx);
    event->dx = BPF_CORE_READ(ctx, dx);
    event->si = BPF_CORE_READ(ctx, si);
    event->di = BPF_CORE_READ(ctx, di);
    event->bp = BPF_CORE_READ(ctx, bp);
    event->sp = BPF_CORE_READ(ctx, sp);

    event->r8  = BPF_CORE_READ(ctx, r8);
    event->r9  = BPF_CORE_READ(ctx, r9);
    event->r10 = BPF_CORE_READ(ctx, r10);
    event->r11 = BPF_CORE_READ(ctx, r11);
    event->r12 = BPF_CORE_READ(ctx, r12);
    event->r13 = BPF_CORE_READ(ctx, r13);
    event->r14 = BPF_CORE_READ(ctx, r14);
    event->r15 = BPF_CORE_READ(ctx, r15);

    bpf_ringbuf_submit(event, 0);

    return 0;
}

SEC("lsm/file_permission")
int BPF_PROG(
    p0_transform_file_permission,
    struct file *file,
    int mask)
{
    __u32 pid;
    struct inode *inode;
    struct transform_state *st;

    pid = current_tgid();

    inode = BPF_CORE_READ(file, f_inode);
    if (!inode)
        return 0;

    if (mask & MAY_READ) {
        struct transform_state zero = {};
        struct dentry *dentry;
        struct dentry *parent;
        struct qstr qname;
        __u32 name_len;

        dentry = BPF_CORE_READ(file, f_path.dentry);
        parent = dentry ? BPF_CORE_READ(dentry, d_parent) : NULL;

        st = bpf_map_lookup_elem(
            &processes,
            &pid
        );

        if (!st) {
            zero.flags = FLAG_TARGET_READ;
            zero.target_dev = inode_dev(inode);
            zero.target_ino =
                (__u64)BPF_CORE_READ(inode, i_ino);

            if (parent) {
                struct inode *parent_inode;

                parent_inode =
                    BPF_CORE_READ(parent, d_inode);

                if (parent_inode) {
                    zero.target_parent_dev =
                        inode_dev(parent_inode);
                    zero.target_parent_ino =
                        (__u64)BPF_CORE_READ(
                            parent_inode,
                            i_ino
                        );
                }
            }

            if (dentry) {
                qname = BPF_CORE_READ(dentry, d_name);
                name_len = qname.len;

                if (name_len > 63)
                    name_len = 63;

                zero.target_name_len = name_len;

                if (name_len) {
                    bpf_probe_read_kernel(
                        zero.target_name,
                        name_len,
                        qname.name
                    );
                }
            }

            zero.read_count = 1;

            bpf_map_update_elem(
                &processes,
                &pid,
                &zero,
                BPF_ANY
            );

            return 0;
        }

        /*
         * A new read establishes the current target.
         * Once manipulation has been observed, do not
         * silently replace the transaction underneath it.
         */
        if (!(st->flags & FLAG_DATA_MANIPULATION)) {
            struct inode *parent_inode;

            dentry = BPF_CORE_READ(file, f_path.dentry);
            parent = dentry
                ? BPF_CORE_READ(dentry, d_parent)
                : NULL;

            st->target_dev = inode_dev(inode);
            st->target_ino =
                (__u64)BPF_CORE_READ(inode, i_ino);

            st->target_parent_dev = 0;
            st->target_parent_ino = 0;
            st->target_name_len = 0;

            if (parent) {
                parent_inode =
                    BPF_CORE_READ(parent, d_inode);

                if (parent_inode) {
                    st->target_parent_dev =
                        inode_dev(parent_inode);
                    st->target_parent_ino =
                        (__u64)BPF_CORE_READ(
                            parent_inode,
                            i_ino
                        );
                }
            }

            if (dentry) {
                qname = BPF_CORE_READ(dentry, d_name);
                name_len = qname.len;

                if (name_len > 63)
                    name_len = 63;

                st->target_name_len = name_len;

                if (name_len) {
                    bpf_probe_read_kernel(
                        st->target_name,
                        name_len,
                        qname.name
                    );
                }
            }

            st->flags |= FLAG_TARGET_READ;
            st->read_count++;
        }

        return 0;
    }

    if (!(mask & MAY_WRITE))
        return 0;

    st = bpf_map_lookup_elem(
        &processes,
        &pid
    );

    if (!st)
        return 0;

    if (!same_inode(
            inode,
            st->target_dev,
            st->target_ino))
        return 0;

    if (!transform_match(st))
        return 0;

    st->final_count++;

    emit_transform_match(pid, st);

    return -13;
}

SEC("lsm/inode_rename")
int BPF_PROG(
    p0_transform_inode_rename,
    struct inode *old_dir,
    struct dentry *old_dentry,
    struct inode *new_dir,
    struct dentry *new_dentry,
    unsigned int flags)
{
    __u32 pid;
    struct transform_state *st;

    pid = current_tgid();

    st = bpf_map_lookup_elem(
        &processes,
        &pid
    );

    if (!st)
        return 0;

    if (!(st->flags & FLAG_TARGET_READ))
        return 0;

    if (!(st->flags & FLAG_DATA_MANIPULATION))
        return 0;

    if (!new_dir || !new_dentry)
        return 0;

    if (inode_dev(new_dir) !=
        st->target_parent_dev)
        return 0;

    if ((__u64)BPF_CORE_READ(
            new_dir,
            i_ino) != st->target_parent_ino)
        return 0;

    if (!dentry_name_matches(
            new_dentry,
            st))
        return 0;

    if (!transform_match(st))
        return 0;

    st->final_count++;

    emit_transform_match(pid, st);

    return -13;
}

char LICENSE[] SEC("license") = "GPL";
