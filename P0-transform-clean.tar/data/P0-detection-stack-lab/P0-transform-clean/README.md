# P0 Transform – Detection & Blocking Stack

Automatic arming of data-transforming processes so the final rename/commit is blocked by an LSM hook (`-EACCES`), while known/verified algorithms can later be allowlisted.

## What this does

1. **Kernel (BPF + LSM)**  
   - On file read → records `FLAG_TARGET_READ` + target metadata in the pinned map `/sys/fs/bpf/processes`.  
   - On final rename → if `FLAG_DATA_MANIPULATION` is set, returns `-EACCES` and the original file is preserved.

2. **Userspace daemon (`p0_auto_arm.py`)**  
   - Watches the processes map.  
   - Arms non-allowlisted, interesting data-file targets with `FLAG_DATA_MANIPULATION` (flags = `0x3`).  
   - Logs an unblock command for each armed PID.

## Prerequisites

- Root privileges  
- BPF maps and LSM programs already loaded and pinned (especially `/sys/fs/bpf/processes`)  
- `bpftool` available  
- Python 3  
- Optional: signature list at `/data/tmp/p0-crypto-master/p0-signature-list.json` (allowlist currently loaded but not yet used for decisions)

## Files

| File | Role |
|------|------|
| `p0_auto_arm.py` | Automatic arming daemon |
| `/sys/fs/bpf/processes` | Pinned BPF map (PID → process state) |
| Signature list (optional) | Future PERMIT path for ROT12/ROT13 etc. |

## Start the daemon

```bash
cd /data/P0-detection-stack-lab/P0-transform-clean

# Ensure no old instance is running
pkill -f p0_auto_arm.py 2>/dev/null || true
sleep 1

# Start (foreground – leave this terminal open)
python3 p0_auto_arm.py

