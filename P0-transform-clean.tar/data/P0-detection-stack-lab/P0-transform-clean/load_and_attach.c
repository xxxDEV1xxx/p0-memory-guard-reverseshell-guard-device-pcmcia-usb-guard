#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <bpf/libbpf.h>
#include <bpf/bpf.h>

int main(int argc, char **argv)
{
    struct bpf_object *obj;
    struct bpf_program *prog;
    struct bpf_link *link;
    int err;

    libbpf_set_strict_mode(LIBBPF_STRICT_ALL);

    obj = bpf_object__open_file("p0_transform_runtime_bpf.o", NULL);
    if (!obj) {
        fprintf(stderr, "open failed\n");
        return 1;
    }

    err = bpf_object__load(obj);
    if (err) {
        fprintf(stderr, "load failed: %d\n", err);
        return 1;
    }

    /* Pin the maps so they survive */
    struct bpf_map *map;
    bpf_object__for_each_map(map, obj) {
        const char *name = bpf_map__name(map);
        char path[128];
        snprintf(path, sizeof(path), "/sys/fs/bpf/%s", name);
        bpf_map__pin(map, path);
        printf("pinned map %s -> %s\n", name, path);
    }

    /* Attach every program that can be attached (LSM + uprobe) */
    bpf_object__for_each_program(prog, obj) {
        const char *name = bpf_program__name(prog);
        link = bpf_program__attach(prog);
        if (libbpf_get_error(link)) {
            fprintf(stderr, "attach %s failed: %ld\n",
                    name, libbpf_get_error(link));
        } else {
            printf("attached %s\n", name);
            /* keep the link alive by pinning it */
            char path[128];
            snprintf(path, sizeof(path), "/sys/fs/bpf/link_%s", name);
            bpf_link__pin(link, path);
            printf("  pinned link -> %s\n", path);
        }
    }

    printf("LSM programs should now be active. Press Ctrl-C to exit (maps stay pinned).\n");
    while (1)
        sleep(3600);

    return 0;
}
