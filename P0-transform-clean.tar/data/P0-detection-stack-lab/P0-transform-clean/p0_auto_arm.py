#!/usr/bin/env python3
"""
P0 Transform – automatic arming daemon
- Parses bpftool 'formatted' layout
- Ignores pure library noise
- Still arms data files even when target_name is polluted (e.g. …cpython…)
"""

import json
import os
import re
import signal
import struct
import subprocess
import sys
import time
from pathlib import Path

PROCESSES_MAP = Path("/sys/fs/bpf/processes")
SIGNATURE_LIST = Path("/data/tmp/p0-crypto-master/p0-signature-list.json")

FLAG_TARGET_READ       = 1 << 0
FLAG_DATA_MANIPULATION = 1 << 1

POLL_INTERVAL = 0.15
ARMED = set()
ALLOWLIST = set()

# Pure library / runtime noise (only ignore when NO data-file hint is present)
LIBRARY_RE = re.compile(
    r'(\.so(\.|$)|libc|ld-linux|libpthread|libdl|libm\.|'
    r'libgcc|libstdc|libssl|libcrypto|gpg-error|'
    r'locale\.|systemd)',
    re.IGNORECASE
)

DATA_HINT_RE = re.compile(
    r'(\.txt|\.csv|\.json|\.log|\.dat|\.bin|test-auto|helloworld|/tmp/)',
    re.IGNORECASE
)

def log(msg):
    line = f"[p0-auto-arm] {msg}"
    print(line, flush=True)
    os.system(f'logger -t p0-transform "{msg}"')

def load_allowlist():
    global ALLOWLIST
    if not SIGNATURE_LIST.exists():
        log(f"WARNING: signature list missing at {SIGNATURE_LIST}")
        ALLOWLIST = set()
        return
    try:
        data = json.loads(SIGNATURE_LIST.read_text())
    except Exception as e:
        log(f"WARNING: failed to parse signature list: {e}")
        ALLOWLIST = set()
        return
    allow = set()
    for sig in data.get("signatures", []):
        if (sig.get("decision") == "PERMIT" and
            sig.get("verification", {}).get("status") == "VERIFIED"):
            algo = (sig.get("algorithm") or sig.get("name") or "").upper()
            if algo:
                allow.add(algo)
    ALLOWLIST = allow
    log(f"allowlist loaded: {sorted(ALLOWLIST)}")

def le_key(pid: int) -> str:
    return (f"{pid & 0xff:02x} "
            f"{(pid >> 8) & 0xff:02x} "
            f"{(pid >> 16) & 0xff:02x} "
            f"{(pid >> 24) & 0xff:02x}")

def dump_map():
    try:
        out = subprocess.check_output(
            ["bpftool", "map", "dump", "pinned", str(PROCESSES_MAP), "-j"],
            stderr=subprocess.DEVNULL
        )
        data = json.loads(out)
        return data if isinstance(data, list) else []
    except Exception as e:
        log(f"map dump failed: {e}")
        return []

def extract_entry(e):
    if not isinstance(e, dict):
        return None, None
    fmt = e.get("formatted")
    if isinstance(fmt, dict):
        pid = fmt.get("key")
        val = fmt.get("value")
        if pid is not None and isinstance(val, dict):
            try:
                return int(pid), val
            except (TypeError, ValueError):
                pass
    pid = e.get("key")
    val = e.get("value")
    if isinstance(pid, int) and isinstance(val, dict):
        return pid, val
    return None, None

def arm_entry(pid: int, val: dict):
    if pid in ARMED:
        return
    try:
        name = (val.get("target_name") or "").encode()[:64].ljust(64, b"\x00")
        packed = struct.pack(
            "<IIQQQQII",
            FLAG_TARGET_READ | FLAG_DATA_MANIPULATION,
            0,
            int(val["target_dev"]),
            int(val["target_ino"]),
            int(val["target_parent_dev"]),
            int(val["target_parent_ino"]),
            int(val["target_name_len"]),
            0,
        )
        packed += name
        packed += struct.pack(
            "<QQQ",
            int(val.get("read_count", 0)),
            int(val.get("final_count", 0)),
            int(val.get("final_latch", 0)),
        )
        assert len(packed) == 136
    except (KeyError, TypeError, ValueError) as e:
        log(f"skip arm pid={pid}: incomplete value ({e})")
        return

    keyhex = le_key(pid)
    cmd = (
        ["bpftool", "map", "update", "pinned", str(PROCESSES_MAP),
         "key", "hex"] + keyhex.split() +
        ["value", "hex"] + [f"{b:02x}" for b in packed]
    )
    try:
        subprocess.check_call(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        ARMED.add(pid)
        name_str = (val.get("target_name") or "?")[:50]
        log(f"ARMED pid={pid} target={name_str!r} flags=0x3")
        log(f"BLOCKED – to unblock: bpftool map delete pinned /sys/fs/bpf/processes key hex {keyhex}")
    except Exception as e:
        log(f"FAILED to arm pid={pid}: {e}")

def should_arm(val: dict) -> bool:
    flags = val.get("flags", 0)
    if not (flags & FLAG_TARGET_READ):
        return False
    if flags & FLAG_DATA_MANIPULATION:
        return False

    name = (val.get("target_name") or "").strip("\x00").strip()
    if not name or len(name) < 2:
        return False

    # If it looks like a data file, arm even when the name is polluted
    if DATA_HINT_RE.search(name):
        return True

    # Otherwise ignore pure library / runtime noise
    if LIBRARY_RE.search(name):
        return False

    return False

def main():
    log("P0 automatic arming daemon starting")
    log("decision: KNOWN+VERIFIED = PERMIT | everything else = ARM → block final rename")
    load_allowlist()

    if not PROCESSES_MAP.exists():
        log(f"ERROR: processes map not found at {PROCESSES_MAP}")
        sys.exit(1)

    stopping = False
    def handle(sig, frame):
        nonlocal stopping
        stopping = True
        log("shutdown requested")
    signal.signal(signal.SIGINT, handle)
    signal.signal(signal.SIGTERM, handle)

    log("watching processes map for FLAG_TARGET_READ entries …")
    while not stopping:
        for e in dump_map():
            pid, val = extract_entry(e)
            if pid is None or val is None:
                continue
            if should_arm(val):
                arm_entry(pid, val)
        time.sleep(POLL_INTERVAL)

    log("exiting cleanly")

if __name__ == "__main__":
    main()
