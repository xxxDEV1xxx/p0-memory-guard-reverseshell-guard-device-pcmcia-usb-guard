#!/usr/bin/env python3
"""
P0 Transform – userspace arming + syslog decision
Follows the whitepaper:
  structural hit (or test arm) → allowlist check → arm FLAG_DATA_MANIPULATION
  kernel then blocks the final rename/write
"""

import ctypes
import json
import os
import signal
import struct
import sys
import time
from pathlib import Path

PROCESSES_MAP = Path("/sys/fs/bpf/processes")
EVENTS_MAP   = Path("/sys/fs/bpf/events")
SIGNATURE_LIST = Path("/data/tmp/p0-crypto-master/p0-signature-list.json")

FLAG_TARGET_READ       = 1 << 0
FLAG_DATA_MANIPULATION = 1 << 1

# transform_state is 136 bytes (from the BPF side)
STATE_FMT = "IIQQQQII64sQQQ"   # flags, reserved, target_dev, target_ino, ...
STATE_SIZE = 136

def log(msg):
    print(f"[p0-arm] {msg}", flush=True)
    # also send to syslog so the operator sees the unblock hint
    os.system(f'logger -t p0-transform "{msg}"')

def load_allowlist():
    if not SIGNATURE_LIST.exists():
        return set()
    data = json.loads(SIGNATURE_LIST.read_text())
    allow = set()
    for sig in data.get("signatures", []):
        if (sig.get("decision") == "PERMIT" and
            sig.get("verification", {}).get("status") == "VERIFIED"):
            algo = (sig.get("algorithm") or sig.get("name") or "").upper()
            if algo:
                allow.add(algo)
    return allow

def open_map(path):
    # open the pinned map via bpf syscall
    # We use the simple open() + BPF_OBJ_GET path
    from bpf import BPF   # fallback if available
    return None

# Minimal pure-ctypes map update (no bcc needed)
BPF_MAP_UPDATE_ELEM = 2
BPF_ANY = 0

libc = ctypes.CDLL("libc.so.6", use_errno=True)
syscall = libc.syscall
syscall.restype = ctypes.c_long

# __NR_bpf on x86_64
NR_BPF = 321

class bpf_attr(ctypes.Structure):
    _fields_ = [
        ("map_fd", ctypes.c_uint32),
        ("key", ctypes.c_uint64),
        ("value", ctypes.c_uint64),
        ("flags", ctypes.c_uint64),
    ]

def bpf_map_update(map_fd, key, value):
    key_buf = ctypes.create_string_buffer(struct.pack("I", key))
    val_buf = ctypes.create_string_buffer(value)
    attr = bpf_attr(
        map_fd=map_fd,
        key=ctypes.addressof(key_buf),
        value=ctypes.addressof(val_buf),
        flags=BPF_ANY,
    )
    ret = syscall(NR_BPF, BPF_MAP_UPDATE_ELEM, ctypes.byref(attr), ctypes.sizeof(attr))
    return ret

def arm_pid(pid, reason="structural-unknown"):
    """Arm FLAG_DATA_MANIPULATION for the given PID."""
    # Open the pinned map
    map_fd = os.open(str(PROCESSES_MAP), os.O_RDWR)
    try:
        # Build a minimal state: only flags matter for the block
        # flags = TARGET_READ | DATA_MANIPULATION = 0x3
        state = bytearray(STATE_SIZE)
        struct.pack_into("I", state, 0, FLAG_TARGET_READ | FLAG_DATA_MANIPULATION)
        ret = bpf_map_update(map_fd, pid, bytes(state))
        if ret == 0:
            log(f"ARMED pid={pid} reason={reason} flags=0x3")
            log(f"BLOCKED algorithm – to unblock run: "
                f"python3 -c \"from p0_arm_and_log import unarm_pid; unarm_pid({pid})\"")
        else:
            log(f"FAILED to arm pid={pid} ret={ret} errno={ctypes.get_errno()}")
    finally:
        os.close(map_fd)

def unarm_pid(pid):
    map_fd = os.open(str(PROCESSES_MAP), os.O_RDWR)
    try:
        state = bytearray(STATE_SIZE)
        bpf_map_update(map_fd, pid, bytes(state))
        log(f"UNARMED pid={pid}")
    finally:
        os.close(map_fd)

def main():
    log("P0 arming daemon starting")
    allow = load_allowlist()
    log(f"allowlist = {sorted(allow)}")
    log("Kernel LSM is already attached – waiting for transforms to arm")

    # For now we expose the arm_pid function so a structural detector
    # (or a manual test) can call it.
    # In production the structural observer calls arm_pid(pid) when
    # a non-allowlisted transform is seen.

    signal.pause()   # keep alive; real structural loop goes here later

if __name__ == "__main__":
    main()
