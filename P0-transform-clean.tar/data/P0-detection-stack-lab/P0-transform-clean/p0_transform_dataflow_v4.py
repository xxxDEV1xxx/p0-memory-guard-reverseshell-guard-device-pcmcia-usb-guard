#!/usr/bin/env python3

import argparse
import json
from dataclasses import dataclass, asdict
from typing import Optional

from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from capstone.x86 import X86_OP_IMM, X86_OP_MEM


TRANSFORMS = {
    "add", "adc", "sub", "sbb",
    "xor", "pxor", "por", "pand", "pandn",
    "or", "and",
    "imul", "mul",
    "neg", "not",
    "shl", "shr", "sar",
    "rol", "ror", "rcl", "rcr",
    "lea",
}

CONDITIONAL_BRANCHES = {
    "ja", "jae", "jb", "jbe",
    "jc", "je", "jg", "jge",
    "jl", "jle", "jna", "jnae",
    "jnb", "jnbe", "jnc", "jne",
    "jng", "jnge", "jnl", "jnle",
    "jno", "jnp", "jns", "jnz",
    "jo", "jp", "jpe", "jpo",
    "js", "jz",
}

UNCONDITIONAL_BRANCHES = {"jmp"}


@dataclass
class Instruction:
    address: int
    mnemonic: str
    op_str: str
    reads: list
    writes: list
    memory: list
    target: Optional[int]


def alias(a, b):
    if a == b:
        return True

    groups = [
        {"rax", "eax", "ax", "al", "ah"},
        {"rbx", "ebx", "bx", "bl", "bh"},
        {"rcx", "ecx", "cx", "cl", "ch"},
        {"rdx", "edx", "dx", "dl", "dh"},
        {"rsi", "esi", "si", "sil"},
        {"rdi", "edi", "di", "dil"},
        {"rbp", "ebp", "bp", "bpl"},
        {"rsp", "esp", "sp", "spl"},
    ]

    for group in groups:
        if a in group and b in group:
            return True

    for prefix in ("r8", "r9", "r10", "r11",
                   "r12", "r13", "r14", "r15"):
        if a in {prefix, prefix + "d", prefix + "w", prefix + "b"}:
            return b in {prefix, prefix + "d", prefix + "w", prefix + "b"}
        if b in {prefix, prefix + "d", prefix + "w", prefix + "b"}:
            return a in {prefix, prefix + "d", prefix + "w", prefix + "b"}

    return False


def contains_alias(registers, target):
    return any(alias(reg, target) for reg in registers)


def decode(data, base):
    md = Cs(CS_ARCH_X86, CS_MODE_64)
    md.detail = True

    result = []

    for insn in md.disasm(data, base):
        reads, writes = insn.regs_access()

        memories = []

        for index, operand in enumerate(insn.operands):
            if operand.type != X86_OP_MEM:
                continue

            mem = operand.mem

            if insn.mnemonic == "lea":
                read = False
                write = False
            else:
                read = index != 0
                write = index == 0

            memories.append({
                "operand_index": index,
                "base": insn.reg_name(mem.base) if mem.base else None,
                "index": insn.reg_name(mem.index) if mem.index else None,
                "scale": mem.scale or 1,
                "disp": mem.disp,
                "size": operand.size,
                "read": read,
                "write": write,
            })

        target = None

        if insn.operands:
            operand = insn.operands[0]
            if operand.type == X86_OP_IMM and (
                insn.mnemonic in CONDITIONAL_BRANCHES
                or insn.mnemonic in UNCONDITIONAL_BRANCHES
            ):
                target = operand.imm

        result.append(
            Instruction(
                address=insn.address,
                mnemonic=insn.mnemonic,
                op_str=insn.op_str,
                reads=[insn.reg_name(r) for r in reads],
                writes=[insn.reg_name(r) for r in writes],
                memory=memories,
                target=target,
            )
        )

    return result


def same_memory(a, b):
    return (
        a["base"] == b["base"]
        and a["index"] == b["index"]
        and a["scale"] == b["scale"]
        and a["disp"] == b["disp"]
        and a["size"] == b["size"]
    )


def successors(instructions, index, address_to_index):
    insn = instructions[index]

    result = []

    if insn.mnemonic in UNCONDITIONAL_BRANCHES:
        if insn.target in address_to_index:
            result.append(address_to_index[insn.target])
        return result

    if insn.mnemonic in CONDITIONAL_BRANCHES:
        if insn.target in address_to_index:
            result.append(address_to_index[insn.target])

        if index + 1 < len(instructions):
            result.append(index + 1)

        return result

    if insn.mnemonic == "ret":
        return result

    if index + 1 < len(instructions):
        result.append(index + 1)

    return result


def analyze(instructions, max_nodes):
    address_to_index = {
        insn.address: i
        for i, insn in enumerate(instructions)
    }

    loads = []

    for index, insn in enumerate(instructions):
        for memory in insn.memory:
            if memory["read"] and not memory["write"] and insn.writes:
                loads.append((index, insn, memory))

    candidates = []
    traces = []

    for load_index, load_insn, load_memory in loads:
        initial_provenance = set(load_insn.writes)

        queue = [
            (
                load_index,
                initial_provenance,
                False,
                [],
                0,
            )
        ]

        visited = set()

        while queue and len(visited) < max_nodes:
            index, provenance, transformed, transforms, depth = queue.pop(0)

            state = (
                index,
                tuple(sorted(provenance)),
                transformed,
            )

            if state in visited:
                continue

            visited.add(state)

            insn = instructions[index]

            # A store is valid only if the stored value derives from
            # the original load and has passed through a transform.
            if transformed:
                for memory in insn.memory:
                    if not memory["write"]:
                        continue

                    if not same_memory(load_memory, memory):
                        continue

                    if not any(
                        contains_alias(provenance, reg)
                        for reg in insn.reads
                    ):
                        continue

                    evidence = [
                        "memory-load",
                        "dataflow-transform",
                        "memory-store",
                        "same-memory-expression",
                    ]

                    if any(
                        target < insn.address
                        for target in [
                            instructions[s].address
                            for s in successors(
                                instructions,
                                index,
                                address_to_index,
                            )
                            if instructions[s].address < insn.address
                        ]
                    ):
                        evidence.append("control-flow")

                    candidates.append({
                        "load_address": load_insn.address,
                        "transform_addresses": transforms,
                        "store_address": insn.address,
                        "evidence": evidence,
                        "score": 9,
                    })

                    traces.append({
                        "load": load_insn.address,
                        "transforms": transforms,
                        "store": insn.address,
                        "visited_nodes": len(visited),
                        "provenance": sorted(provenance),
                    })

                    queue.clear()
                    break

            next_provenance = set(provenance)
            next_transformed = transformed
            next_transforms = list(transforms)

            depends = any(
                contains_alias(provenance, reg)
                for reg in insn.reads
            )

            if depends and insn.mnemonic in TRANSFORMS:
                next_transformed = True
                next_transforms.append(insn.address)
                next_provenance.update(insn.writes)

            elif depends:
                # Instructions that preserve the tracked value can
                # continue the data-flow without being transformations.
                next_provenance.update(
                    reg for reg in insn.writes
                    if contains_alias(provenance, reg)
                )

            for successor in successors(
                instructions,
                index,
                address_to_index,
            ):
                queue.append((
                    successor,
                    next_provenance,
                    next_transformed,
                    next_transforms,
                    depth + 1,
                ))

    return loads, candidates, traces


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--base", type=lambda x: int(x, 0), default=0)
    parser.add_argument("--max-nodes", type=int, default=128)
    parser.add_argument("--diagnostic", action="store_true")
    args = parser.parse_args()

    with open(args.input, "rb") as f:
        data = f.read()

    instructions = decode(data, args.base)

    loads, candidates, traces = analyze(
        instructions,
        args.max_nodes,
    )

    result = {
        "base_address": args.base,
        "bytes": len(data),
        "instruction_count": len(instructions),
        "load_count": len(loads),
        "candidate_count": len(candidates),
        "candidates": candidates,
        "traces": traces,
    }

    if args.diagnostic:
        result["decoded"] = [
            asdict(insn)
            for insn in instructions
        ]

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
