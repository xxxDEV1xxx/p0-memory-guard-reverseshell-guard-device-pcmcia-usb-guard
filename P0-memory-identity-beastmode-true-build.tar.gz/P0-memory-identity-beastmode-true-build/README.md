# P0 Memory Identity Beastmode — True Build Source

Copyright (c) 2026 Christopher T. Williams

## Purpose

This tree assembles the P0 Memory Identity Beastmode implementation with the
empirical memory-crystal acquisition and research tooling used to establish
and validate observed process-memory identity.

The architecture separates three functions:

1. Beastmode runtime enforcement.
2. Empirical memory-crystal construction and validation.
3. Large-scale executable inventory, memory acquisition, and indexing.

The generated empirical corpus is intentionally not part of this source tree.

## Architecture

    P0-memory-identity-beastmode-true-build/
    |
    +-- beastmode/
    |     |
    |     +-- P0 Memory Identity Beastmode runtime
    |     +-- eBPF enforcement sources
    |     +-- loaders
    |     +-- identity worker
    |     +-- build/package scripts
    |     +-- service unit
    |     +-- existing provenance and test artifacts
    |
    +-- memory-crystal/
    |     |
    |     +-- process_baseline.py
    |     +-- process_identity_test.py
    |     +-- test_5000_identity.py
    |     +-- test_5000_identity_indexed.py
    |
    +-- crystal-acquisition/
    |     |
    |     +-- inventory_executables.py
    |     +-- build_acquisition_manifest.py
    |     +-- memory_p0_acquire.py
    |     +-- build_memory_master_index.py
    |     +-- build_sort32_index.py
    |
    +-- LICENSE
    +-- README.md

## P0 Memory Identity Model

The memory-crystal research layer treats observed process memory as an
empirical identity signal.

The baseline process set contains:

    /bin/echo
    /bin/cat
    /bin/sleep
    /bin/true
    /bin/false
    /bin/pwd
    /bin/hostname
    /bin/uname
    /bin/date
    /bin/id
    /bin/ls
    /bin/kill
    /bin/mkdir
    /bin/rm
    /bin/sh

The empirical baseline uses five acquisition runs.

The first four runs form the training/reference crystal.

The fifth run is retained as a hidden validation sample.

The reference calculation derives byte-level invariants and masks from the
training observations. Candidate process memories can then be evaluated
against the observed memory identity rather than relying only on declared
process names, paths, or executable labels.

## Memory-Crystal Source

`memory-crystal/` contains the empirical research and validation programs.

`process_baseline.py`

Acquires the 15-process baseline over five runs and records process-memory
observations and associated metadata.

`process_identity_test.py`

Loads the empirical baseline sets, constructs process-level invariant data,
and evaluates identity against observed memory.

`test_5000_identity.py`

Builds the four-run reference crystal and performs broader candidate testing
against the empirical memory corpus.

`test_5000_identity_indexed.py`

Performs indexed candidate lookup using the memory master index produced by
the acquisition pipeline.

These programs are research/validation tooling. They do not embed the
generated empirical corpus into the source distribution.

## Crystal Acquisition Pipeline

`crystal-acquisition/` provides the large-scale acquisition path:

    executable inventory
            |
            v
    acquisition manifest
            |
            v
    process-memory acquisition
            |
            v
    candidate corpus
            |
            v
    memory master index
            |
            v
    sort-32 index

The acquisition scripts use a package-relative generated build root:

    ./build/

Generated acquisition data is therefore kept separate from source.

Expected generated directories include:

    build/inventory/
    build/p0/
    build/database/
    build/logs/
    build/process_baseline/
    build/process_baseline2/

The generated corpus can be very large and is not intended to be committed
to or distributed with this source tree.

## Existing Beastmode Runtime

The `beastmode/` directory is the existing P0 Memory Identity Beastmode
runtime/build tree copied into this assembly without redesigning its internal
build model.

Its established build environment uses:

    /data/lib-ext/usr/bin/clang-14
    /data/lib-ext/usr/include
    /data/lib-ext/usr/lib/x86_64-linux-gnu

Its deployment model uses:

    /data/P0-memory-identity-beastmode/

The existing systemd service executes:

    /data/P0-memory-identity-beastmode/beastmode_loader.isolated

These paths are intentional characteristics of the existing Beastmode
implementation and are not changed by the memory-crystal packaging work.

See:

    beastmode/README.md

for the Beastmode-specific build, enforcement, testing, deployment, and
security documentation.

## Build Separation

The Beastmode build remains under:

    beastmode/build/

The memory-crystal and acquisition generated data remains under:

    build/

These are separate build domains.

The source assembly does not require the empirical candidate corpus to be
present.

## Source Versus Generated Evidence

Source:

    beastmode/
    memory-crystal/
    crystal-acquisition/
    LICENSE
    README.md

Generated evidence intentionally excluded from the source assembly includes:

    memory.bin
    maps.json
    metadata.json
    process_memory.db
    memory_master_index.tsv
    memory_master_index_sort32.tsv
    large candidate-memory corpora
    Python bytecode
    __pycache__

The empirical acquisition results may be archived separately as research
evidence with their own hashes, manifests, and provenance records.

## Provenance

The memory-crystal and acquisition sources were assembled from the empirical
P0 memory-identity research tooling and adapted only where required to make
their generated-data paths package-relative.

The Beastmode subtree is preserved as its existing implementation rather
than reconstructed from historical snapshots.

Historical Beastmode artifacts present within that subtree are retained as
part of its existing provenance/runtime package and are not represented by
the acquisition tooling as empirical corpus data.

## Reproducibility

For the empirical memory-crystal layer, reproducibility requires:

    Linux host
    Python 3
    root privileges for process-memory acquisition
    sufficient writable storage
    executable/process access required by the acquisition scripts

The exact kernel, executable corpus, filesystem state, process state, and
runtime environment affect observed process memory. Consequently, an
empirical crystal is an observation of a particular acquisition environment,
not a universal byte sequence independent of execution context.

For Beastmode reproduction, use the toolchain and dependency paths documented
in:

    beastmode/README.md

and:

    beastmode/build.sh

## Security Considerations

Memory acquisition can expose sensitive process contents. Acquisition
corpora must be handled as security-sensitive forensic data.

The Beastmode global-enforcement mode is intentionally powerful and can
terminate processes system-wide. Do not deploy unvalidated BPF objects or
destructive blocklists on production systems.

Validate generated objects and runtime behavior in a controlled environment
before deployment.

## License

The user-owned source assembled in this tree is provided under the license
in:

    LICENSE

Third-party components, system libraries, compiler toolchains, and other
externally supplied dependencies retain their respective licenses.

The separate `/data/lib-ext` dependency tree used by the existing Beastmode
build is not included in this source assembly.

