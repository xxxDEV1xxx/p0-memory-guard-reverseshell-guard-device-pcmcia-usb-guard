#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
BUILD="$ROOT/build"

CLANG="/data/lib-ext/usr/bin/clang-14"
CC="${CC:-gcc}"
LIBBPF="/data/lib-ext/usr/lib/x86_64-linux-gnu"

mkdir -p "$BUILD"
rm -f "$BUILD"/*

echo "[+] Building enforcement BPF object"
"$CLANG" -O2 -g -target bpf \
    -D__TARGET_ARCH_x86 \
    -I/usr/include/x86_64-linux-gnu \
    -I/data/lib-ext/usr/include \
    -c "$ROOT/beastmode.bpf.test.c" \
    -o "$BUILD/beastmode.bpf.o"

echo "[+] Building global enforcement BPF object"
"$CLANG" -O2 -g -target bpf \
    -D__TARGET_ARCH_x86 \
    -I/usr/include/x86_64-linux-gnu \
    -I/data/lib-ext/usr/include \
    -c "$ROOT/beastmode.bpf.test.c" \
    -o "$BUILD/beastmode.bpf.global-enforce.o"

echo "[+] Building enforcement loader"
"$CC" -O2 -Wall -Wextra \
    -I/data/lib-ext/usr/include \
    "$ROOT/beastmode_loader.enforce.c" \
    -o "$BUILD/beastmode_loader" \
    -L"$LIBBPF" \
    -Wl,-rpath,"$LIBBPF" \
    -lbpf

echo "[+] Building global enforcement loader"
"$CC" -O2 -Wall -Wextra \
    -I/data/lib-ext/usr/include \
    "$ROOT/beastmode_loader.global-enforce.c" \
    -o "$BUILD/beastmode_loader.global-enforce" \
    -L"$LIBBPF" \
    -Wl,-rpath,"$LIBBPF" \
    -lbpf

echo
echo "=== ARTIFACTS ==="
file \
    "$BUILD/beastmode.bpf.o" \
    "$BUILD/beastmode.bpf.global-enforce.o" \
    "$BUILD/beastmode_loader" \
    "$BUILD/beastmode_loader.global-enforce"

echo
echo "=== GLOBAL LOADER OBJECT ==="
strings "$BUILD/beastmode_loader.global-enforce" |
    grep 'beastmode.bpf.global-enforce.o' || true

echo
echo "[+] Build complete"
