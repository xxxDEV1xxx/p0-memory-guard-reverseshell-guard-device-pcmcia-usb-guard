#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
PARENT="$(dirname "$ROOT")"
NAME="P0-memory-identity-beastmode"
STAGE="/data/${NAME}-package"
ARCHIVE="/data/${NAME}.tar.gz"

echo "[+] Preparing staging directory: $STAGE"

python3 - "$STAGE" "$ROOT" <<'PY'
import os
import shutil
import sys
from pathlib import Path

stage = Path(sys.argv[1])
root = Path(sys.argv[2])

if stage.exists():
    shutil.rmtree(stage)

stage.mkdir(parents=True)

# Copy the complete project tree.
dst = stage / "P0-memory-identity-beastmode"
shutil.copytree(
    root,
    dst,
    symlinks=True,
    ignore=shutil.ignore_patterns(
        ".package-stage",
        "*.tar.gz",
    ),
)

# Copy the installed service unit into the bundle.
service_src = Path("/etc/systemd/system/p0-memory-identity-beastmode.service")
if service_src.exists():
    service_dst = dst / "p0-memory-identity-beastmode.service"
    shutil.copy2(service_src, service_dst)

# Bundle the custom compiler/libbpf tree.
libext_src = Path("/data/lib-ext/usr")
libext_dst = stage / "lib-ext" / "usr"
if libext_src.exists():
    shutil.copytree(libext_src, libext_dst, symlinks=True)

print(f"staged: {stage}")
PY

echo "[+] Recording build environment"

{
    echo "P0 Memory Identity Beastmode build environment"
    echo "=============================================="
    echo
    echo "date:"
    date -u
    echo
    echo "hostname:"
    hostname
    echo
    echo "kernel:"
    uname -a
    echo
    echo "clang:"
    /data/lib-ext/usr/bin/clang-14 --version || true
    echo
    echo "gcc:"
    gcc --version | head -n 1 || true
    echo
    echo "bpftool:"
    bpftool version || true
    echo
    echo "make:"
    make --version | head -n 1 || true
    echo
    echo "libbpf:"
    find /data/lib-ext/usr/lib -maxdepth 3 \
        \( -name 'libbpf.so*' -o -name 'libbpf.a' \) \
        -ls 2>/dev/null || true
} > "$STAGE/BUILD-ENVIRONMENT.txt"

echo "[+] Recording executable/tool paths"

{
    command -v gcc || true
    command -v make || true
    command -v bpftool || true
    command -v ld || true
    command -v ar || true
    command -v objcopy || true
    command -v readelf || true
    command -v file || true
    echo "/data/lib-ext/usr/bin/clang-14"
} > "$STAGE/TOOL-PATHS.txt"

echo "[+] Recording service installation source"

systemctl cat p0-memory-identity-beastmode.service \
    > "$STAGE/SERVICE-UNIT-LIVE.txt" 2>&1 || true

echo "[+] Recording project inventory"

(
    cd "$STAGE"
    find P0-memory-identity-beastmode -type f -o -type l |
        sort
) > "$STAGE/FILE-LIST.txt"

echo "[+] Creating SHA-256 manifest"

(
    cd "$STAGE"
    find . -type f -print0 |
        sort -z |
        xargs -0 sha256sum
) > "$STAGE/SHA256SUMS.txt"

echo "[+] Creating archive"

python3 - "$STAGE" "$ARCHIVE" <<'PY'
import sys
import tarfile
from pathlib import Path

stage = Path(sys.argv[1])
archive = Path(sys.argv[2])

if archive.exists():
    archive.unlink()

with tarfile.open(archive, "w:gz") as tar:
    tar.add(stage, arcname=stage.name)

print(archive)
PY

echo
echo "=============================================="
echo "PACKAGE READY"
echo "=============================================="
ls -lh "$ARCHIVE"
echo
echo "SHA256:"
sha256sum "$ARCHIVE"
echo
echo "Contents:"
tar -tzf "$ARCHIVE" | head -40
echo
echo "Total archived entries:"
tar -tzf "$ARCHIVE" | wc -l
