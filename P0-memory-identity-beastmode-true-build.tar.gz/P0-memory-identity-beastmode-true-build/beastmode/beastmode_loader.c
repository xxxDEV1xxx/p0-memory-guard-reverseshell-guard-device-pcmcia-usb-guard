#define _GNU_SOURCE

#include <bpf/bpf.h>
#include <bpf/libbpf.h>

#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define BEASTMODE_BLOCKLIST "/etc/p0/beastmode/blocklist"

struct beastmode_event {
    uint32_t pid;
    uint32_t uid;
    uint64_t cgroup;
    char comm[16];
    char claimed[64];
    uint32_t match;
    uint32_t reason;
};

static volatile sig_atomic_t stop;

static void print_help(const char *prog)
{
    printf("P0 Memory Identity BEASTMODE\n");
    printf("\n");
    printf("Usage:\n");
    printf("  %s help\n", prog);
    printf("  %s status\n", prog);
    printf("  %s list\n", prog);
    printf("  %s block <command>\n", prog);
    printf("  %s unblock <command>\n", prog);
    printf("\n");
    printf("Policy file: %s\n", BEASTMODE_BLOCKLIST);
}

static int ensure_policy_dir(void)
{
    if (mkdir("/etc/p0", 0755) != 0 && errno != EEXIST) {
        fprintf(stderr, "mkdir /etc/p0: %s\n", strerror(errno));
        return -1;
    }

    if (mkdir("/etc/p0/beastmode", 0755) != 0 && errno != EEXIST) {
        fprintf(stderr, "mkdir /etc/p0/beastmode: %s\n",
                strerror(errno));
        return -1;
    }

    return 0;
}

static int valid_command_name(const char *name)
{
    size_t i;

    if (!name || !name[0])
        return 0;

    if (strlen(name) > 63)
        return 0;

    for (i = 0; name[i]; i++) {
        unsigned char c = (unsigned char)name[i];

        if (!(c == '_' || c == '-' ||
              (c >= 'a' && c <= 'z') ||
              (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9')))
            return 0;
    }

    return 1;
}

static int command_in_blocklist(const char *command)
{
    FILE *f;
    char line[128];

    f = fopen(BEASTMODE_BLOCKLIST, "r");
    if (!f)
        return errno == ENOENT ? 0 : -1;

    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = '\0';

        if (strcmp(line, command) == 0) {
            fclose(f);
            return 1;
        }
    }

    fclose(f);
    return 0;
}

static int list_blocklist(void)
{
    FILE *f;
    char line[128];
    int count = 0;

    printf("BEASTMODE BLOCKLIST\n");
    printf("policy=%s\n", BEASTMODE_BLOCKLIST);

    f = fopen(BEASTMODE_BLOCKLIST, "r");
    if (!f) {
        if (errno == ENOENT) {
            printf("entries=0\n");
            return 0;
        }

        fprintf(stderr, "open %s: %s\n",
                BEASTMODE_BLOCKLIST,
                strerror(errno));
        return -1;
    }

    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = '\0';

        if (!line[0])
            continue;

        printf("%s\n", line);
        count++;
    }

    fclose(f);

    printf("entries=%d\n", count);
    return 0;
}

static int add_blocked_command(const char *command)
{
    FILE *f;
    int present;

    if (!valid_command_name(command)) {
        fprintf(stderr, "invalid command name: %s\n", command);
        return 2;
    }

    if (ensure_policy_dir() != 0)
        return 1;

    present = command_in_blocklist(command);

    if (present < 0) {
        fprintf(stderr, "cannot read blocklist: %s\n",
                strerror(errno));
        return 1;
    }

    if (present) {
        printf("ALREADY_BLOCKED %s\n", command);
        return 0;
    }

    f = fopen(BEASTMODE_BLOCKLIST, "a");
    if (!f) {
        fprintf(stderr, "open %s: %s\n",
                BEASTMODE_BLOCKLIST,
                strerror(errno));
        return 1;
    }

    fprintf(f, "%s\n", command);
    fclose(f);

    printf("BLOCKED %s\n", command);
    return 0;
}

static int remove_blocked_command(const char *command)
{
    FILE *in;
    FILE *out;
    char line[128];
    char tmp[256];
    int found = 0;

    if (!valid_command_name(command)) {
        fprintf(stderr, "invalid command name: %s\n", command);
        return 2;
    }

    in = fopen(BEASTMODE_BLOCKLIST, "r");
    if (!in) {
        if (errno == ENOENT) {
            printf("NOT_BLOCKED %s\n", command);
            return 0;
        }

        fprintf(stderr, "open %s: %s\n",
                BEASTMODE_BLOCKLIST,
                strerror(errno));
        return 1;
    }

    snprintf(tmp, sizeof(tmp), "%s.tmp.%ld",
             BEASTMODE_BLOCKLIST,
             (long)getpid());

    out = fopen(tmp, "w");
    if (!out) {
        fprintf(stderr, "open temporary blocklist: %s\n",
                strerror(errno));
        fclose(in);
        return 1;
    }

    while (fgets(line, sizeof(line), in)) {
        char *nl;

        nl = strpbrk(line, "\\r\n");
        if (nl)
            *nl = '\0';

        if (strcmp(line, command) == 0) {
            found = 1;
            continue;
        }

        fprintf(out, "%s\n", line);
    }

    fclose(in);
    fclose(out);

    if (rename(tmp, BEASTMODE_BLOCKLIST) != 0) {
        fprintf(stderr, "rename blocklist: %s\n",
                strerror(errno));
        unlink(tmp);
        return 1;
    }

    if (found)
        printf("UNBLOCKED %s\n", command);
    else
        printf("NOT_BLOCKED %s\n", command);

    return 0;
}

static int cli_command(int argc, char **argv)
{
    if (argc < 2 || strcmp(argv[1], "help") == 0) {
        print_help(argv[0]);
        return 0;
    }

    if (strcmp(argv[1], "list") == 0) {
        if (argc != 2) {
            fprintf(stderr, "usage: %s list\n", argv[0]);
            return 2;
        }

        return list_blocklist() == 0 ? 0 : 1;
    }

    if (strcmp(argv[1], "block") == 0) {
        if (argc != 3) {
            fprintf(stderr,
                    "usage: %s block <command>\n",
                    argv[0]);
            return 2;
        }

        return add_blocked_command(argv[2]);
    }

    if (strcmp(argv[1], "unblock") == 0) {
        if (argc != 3) {
            fprintf(stderr,
                    "usage: %s unblock <command>\n",
                    argv[0]);
            return 2;
        }

        return remove_blocked_command(argv[2]);
    }

    if (strcmp(argv[1], "status") == 0) {
        if (argc != 2) {
            fprintf(stderr, "usage: %s status\n", argv[0]);
            return 2;
        }

        printf("BEASTMODE CLI\n");
        printf("policy=%s\n", BEASTMODE_BLOCKLIST);
        printf("service=p0-memory-identity-beastmode.service\n");
        printf("enforcement=kernel-ebpf\n");
        printf("current_builtin_target=dd\n");
        return 0;
    }

    fprintf(stderr, "unknown command: %s\n", argv[1]);
    print_help(argv[0]);
    return 2;
}

static void on_signal(int sig)
{
    (void)sig;
    stop = 1;
}

static int discover_cgroup_inode(uint64_t *inode)
{
    FILE *f;
    char line[4096];
    char path[4096];
    char *p;
    struct stat st;

    f = fopen("/proc/self/cgroup", "r");
    if (!f) {
        perror("fopen /proc/self/cgroup");
        return -1;
    }

    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "0::", 3) != 0)
            continue;

        p = line + 3;

        while (*p == ' ')
            p++;

        p[strcspn(p, "\r\n")] = '\0';

        if (p[0] == '\0') {
            snprintf(path, sizeof(path), "/sys/fs/cgroup");
        } else {
            if (snprintf(
                    path,
                    sizeof(path),
                    "/sys/fs/cgroup%s",
                    p) >= (int)sizeof(path)) {
                fprintf(stderr, "cgroup path too long\n");
                fclose(f);
                return -1;
            }
        }

        if (stat(path, &st) != 0) {
            fprintf(
                stderr,
                "stat(%s): %s\n",
                path,
                strerror(errno));
            fclose(f);
            return -1;
        }

        *inode = (uint64_t)st.st_ino;

        printf("target_cgroup=%" PRIu64 "\n", *inode);
        printf("target_cgroup_path=%s\n", path);

        fclose(f);
        return 0;
    }

    fclose(f);

    fprintf(stderr, "unified cgroup entry not found\n");
    return -1;
}


static void launch_p0_identity_worker(
    uint32_t pid,
    const char *claimed)
{
    pid_t child;
    char pidbuf[32];

    snprintf(pidbuf, sizeof(pidbuf), "%u", pid);

    child = fork();

    if (child < 0) {
        fprintf(stderr,
                "P0 IDENTITY WORKER FORK FAILED "
                "pid=%u claimed=%s: %s\n",
                pid,
                claimed,
                strerror(errno));
        return;
    }

    if (child == 0) {
        execl(
            "/usr/bin/python3",
            "/usr/bin/python3",
            "/data/P0-memory-identity-beastmode/"
            "p0_identity_worker.py",
            pidbuf,
            claimed,
            (char *)NULL);

        _exit(127);
    }
}

static int handle_event(
    void *ctx,
    void *data,
    size_t data_sz)
{
    const struct beastmode_event *e = data;

    (void)ctx;

    if (data_sz < sizeof(*e)) {
        fprintf(stderr, "short event: %zu bytes\n", data_sz);
        return 0;
    }

    printf(
        "P0_MEMORY_IDENTITY_BEASTMODE "
        "pid=%u uid=%u cgroup=%" PRIu64
        " comm=%s claimed=%s match=%u reason=%u\n",
        e->pid,
        e->uid,
        e->cgroup,
        e->comm,
        e->claimed,
        e->match,
        e->reason);

    fflush(stdout);

    if (e->match == 1 && e->claimed[0] != '\0')
        launch_p0_identity_worker(e->pid, e->claimed);

    /*
     * Reap completed P0 workers without blocking the ring-buffer
     * callback. The worker itself performs the memory observation.
     */
    while (waitpid(-1, NULL, WNOHANG) > 0)
        ;

    return 0;
}

int main(int argc, char **argv)
{
    struct bpf_object *obj = NULL;
    struct bpf_program *prog = NULL;
    struct bpf_program *postexec_prog = NULL;
    struct bpf_link *link = NULL;
    struct bpf_link *postexec_link = NULL;
    struct ring_buffer *rb = NULL;

    struct bpf_map *target_map;
    struct bpf_map *events_map;
    int target_map_fd;
    int events_map_fd;
    int err;
    uint32_t key = 0;
    uint64_t cgroup_inode;

    if (argc > 1)
        return cli_command(argc, argv);

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    libbpf_set_strict_mode(LIBBPF_STRICT_ALL);

    obj = bpf_object__open_file(
        "/data/P0-memory-identity-beastmode/beastmode.bpf.global.o",
        NULL);

    if (libbpf_get_error(obj)) {
        err = (int)-libbpf_get_error(obj);
        obj = NULL;
        fprintf(stderr, "bpf_object__open_file failed: %s\n",
                strerror(-err));
        return 1;
    }

    err = bpf_object__load(obj);
    if (err) {
        fprintf(stderr, "bpf_object__load failed: %s\n",
                strerror(-err));
        goto cleanup;
    }

    target_map = bpf_object__find_map_by_name(
        obj,
        "target_cgroup");

    if (!target_map) {
        fprintf(stderr, "target_cgroup map not found\n");
        err = -1;
        goto cleanup;
    }

    target_map_fd = bpf_map__fd(target_map);

    if (target_map_fd < 0) {
        fprintf(stderr, "target_cgroup map fd unavailable\n");
        err = target_map_fd;
        goto cleanup;
    }

    /*
     * GLOBAL TEST MODE:
     * target_cgroup == 0 disables the cgroup filter in the BPF helper.
     */
    cgroup_inode = 0;

    err = bpf_map_update_elem(
        target_map_fd,
        &key,
        &cgroup_inode,
        BPF_ANY);

    if (err) {
        fprintf(
            stderr,
            "bpf_map_update_elem(target_cgroup): %s\n",
            strerror(errno));
        goto cleanup;
    }

    prog = bpf_object__find_program_by_name(
        obj,
        "beastmode_execve");

    if (!prog) {
        fprintf(stderr, "beastmode_execve program not found\n");
        err = -1;
        goto cleanup;
    }

    link = bpf_program__attach_tracepoint(
        prog,
        "syscalls",
        "sys_enter_execve");

    if (libbpf_get_error(link)) {
        err = (int)-libbpf_get_error(link);
        link = NULL;
        fprintf(stderr,
                "bpf_program__attach_tracepoint failed: %s\n",
                strerror(-err));
        goto cleanup;
    }

    postexec_prog = bpf_object__find_program_by_name(
        obj,
        "beastmode_process_exec");

    if (!postexec_prog) {
        fprintf(stderr,
                "beastmode_process_exec program not found\n");
        err = -1;
        goto cleanup;
    }

    postexec_link = bpf_program__attach_tracepoint(
        postexec_prog,
        "sched",
        "sched_process_exec");

    if (libbpf_get_error(postexec_link)) {
        err = (int)-libbpf_get_error(postexec_link);
        postexec_link = NULL;
        fprintf(stderr,
                "bpf_program__attach_tracepoint(postexec) failed: %s\n",
                strerror(-err));
        goto cleanup;
    }

    events_map = bpf_object__find_map_by_name(
        obj,
        "events");

    if (!events_map) {
        fprintf(stderr, "events map not found\n");
        err = -1;
        goto cleanup;
    }

    events_map_fd = bpf_map__fd(events_map);

    if (events_map_fd < 0) {
        fprintf(stderr, "events map fd unavailable\n");
        err = events_map_fd;
        goto cleanup;
    }

    rb = ring_buffer__new(
        events_map_fd,
        handle_event,
        NULL,
        NULL);

    if (!rb) {
        fprintf(stderr, "ring_buffer__new failed\n");
        err = -1;
        goto cleanup;
    }

    printf("P0 MEMORY IDENTITY BEASTMODE ATTACHED\n");
    printf("BLOCKING MODE ENABLED\n");
    printf("target: dd\n");
    printf("execve(dd) -> SIGKILL\n");
    fflush(stdout);

    while (!stop) {
        err = ring_buffer__poll(rb, 1000);

        if (err < 0 && err != -EINTR) {
            fprintf(stderr,
                    "ring_buffer__poll failed: %s\n",
                    strerror(-err));
            break;
        }
    }

    err = 0;

cleanup:
    ring_buffer__free(rb);
    bpf_link__destroy(postexec_link);
    bpf_link__destroy(link);
    bpf_object__close(obj);

    return err ? 1 : 0;
}
