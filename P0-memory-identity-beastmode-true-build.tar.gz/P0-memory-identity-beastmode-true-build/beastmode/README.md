# P0 Memory Identity Beastmode

P0 Memory Identity Beastmode is an eBPF-based process-execution enforcement
service. It observes `execve`/process-exec activity, tracks execution identity,
and can terminate executions that violate configured policy.

## Current enforcement model

The enforcement BPF program is:

    beastmode.bpf.test.c

It contains:

- `tracepoint/syscalls/sys_enter_execve`
- `tracepoint/sched/sched_process_exec`
- `target_cgroup`
- `blocked_commands`
- `claimed_exec`
- `events`
- execution identity verification
- command blocklist enforcement
- `bpf_send_signal(9)` enforcement

### Global enforcement mode

`target_cgroup` is an ARRAY map with one entry.

A non-zero value restricts enforcement to the specified cgroup inode.

A value of zero means GLOBAL mode:

    target_cgroup[0] == 0

In GLOBAL mode, enforcement applies regardless of the calling process'
cgroup.

This behavior is implemented in `in_target_cgroup()` in
`beastmode.bpf.test.c`.

## Repository layout

    beastmode.bpf.test.c          Enforcement BPF source
    beastmode_loader.test.c       Enforcement loader source
    beastmode.bpf.c               Observe-only BPF source
    beastmode_loader.c             Observe-only/global test loader source

    systemd/
        p0-memory-identity-beastmode.service

    Makefile
    build.sh
    README.md

Build output is placed under:

    build/

The Makefile does not overwrite production artifacts in the repository root.

## Toolchain

Validated build environment:

    clang: /data/lib-ext/usr/bin/clang-14
    gcc: system gcc
    libbpf headers: /data/lib-ext/usr/include
    libbpf library: /data/lib-ext/usr/lib/x86_64-linux-gnu

BPF compilation uses:

    -O2 -g -target bpf
    -D__TARGET_ARCH_x86
    -I/usr/include/x86_64-linux-gnu
    -I/data/lib-ext/usr/include

Loader compilation uses:

    -O2 -Wall -Wextra
    -I/data/lib-ext/usr/include
    -L/data/lib-ext/usr/lib/x86_64-linux-gnu
    -Wl,-rpath,/data/lib-ext/usr/lib/x86_64-linux-gnu
    -lbpf

## Build

Build everything:

    make

or:

    ./build.sh

The build produces:

    build/beastmode.bpf.o
    build/beastmode_loader
    build/beastmode.bpf.global-enforce.o
    build/beastmode_loader.global-enforce

The `global-enforce` artifacts use:

    target_cgroup = 0

and are intended for controlled testing before deployment.

## Clean build

    make clean
    make

## Verify artifacts

    file build/beastmode.bpf.o
    file build/beastmode_loader
    file build/beastmode.bpf.global-enforce.o
    file build/beastmode_loader.global-enforce

Inspect BPF programs:

    llvm-objdump -S build/beastmode.bpf.global-enforce.o

Inspect loader object path:

    strings build/beastmode_loader.global-enforce | \
        grep 'beastmode.bpf.global-enforce.o'

## Blocklist

The runtime blocklist is:

    /etc/p0/beastmode/blocklist

Example:

    ./build/beastmode_loader.global-enforce block dd
    ./build/beastmode_loader.global-enforce block rm
    ./build/beastmode_loader.global-enforce block sudo

List:

    ./build/beastmode_loader.global-enforce list

Remove:

    ./build/beastmode_loader.global-enforce unblock rm
    ./build/beastmode_loader.global-enforce unblock sudo

The loader updates the BPF `blocked_command` map from the persistent
blocklist when it starts.

## Manual global-enforcement test

Do not stop the production service until a replacement build has been
validated separately.

Start:

    ./build/beastmode_loader.global-enforce &

Verify the target cgroup map:

    bpftool map show | grep target_cgroup

    bpftool map dump id <TARGET_MAP_ID>

Expected:

    key: 0
    value: 0

Verify the enforcement program:

    bpftool prog show | grep -A4 -B1 beastmode_execve

The enforcement program should contain the `blocked_command`,
`claimed_exec`, and `target_cgroup` maps.

## Test policy

For a temporary test:

    ./build/beastmode_loader.global-enforce block dd
    ./build/beastmode_loader.global-enforce block rm
    ./build/beastmode_loader.global-enforce block sudo

Expected behavior from a process outside the Beastmode service cgroup:

    dd if=/dev/zero of=/dev/null bs=1M count=1

    -> SIGKILL / exit 137

    rm /tmp/test-file

    -> SIGKILL / exit 137

    sudo -n true

    -> SIGKILL / exit 137

After testing:

    ./build/beastmode_loader.global-enforce unblock rm
    ./build/beastmode_loader.global-enforce unblock sudo

Do not leave destructive-command tests enabled unintentionally.

## Systemd

The service unit is:

    systemd/p0-memory-identity-beastmode.service

The service is intended to execute the installed production loader:

    /data/P0-memory-identity-beastmode/beastmode_loader.isolated

Deployment should only replace production artifacts after the separately
built/tested artifacts have been validated.

## Production artifact preservation

Known production artifacts are deliberately not overwritten by `make`.

Before any deployment:

    sha256sum beastmode.bpf.o beastmode_loader.isolated

The repository should preserve a known-good copy before replacement.

## Reproducibility

The build depends on the following external runtime/build components:

    /data/lib-ext/usr/bin/clang-14
    /data/lib-ext/usr/include
    /data/lib-ext/usr/lib/x86_64-linux-gnu/libbpf.so*
    /usr/include/linux
    /usr/include/x86_64-linux-gnu
    gcc
    binutils
    bpftool
    clang/LLVM tools

For complete offline reproduction, package those dependencies separately
with the source and record their SHA-256 hashes.

## Security

Run loaders as root.

Do not deploy an untested BPF object over the known-good production object.

A malformed or overly broad blocklist can terminate critical system
executables.

GLOBAL mode is intentionally powerful: it removes the cgroup boundary and
allows the BPF enforcement path to act on processes throughout the system.
