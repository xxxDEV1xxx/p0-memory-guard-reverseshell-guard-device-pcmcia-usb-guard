#!/usr/bin/env python3

# Copyright (c) 2026 Christopher T. Williams
#
# Permission is granted to use, copy, modify, and distribute this software
# for research, testing, and security-analysis purposes, provided that the
# copyright notice and this permission notice are retained.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL
# NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE
# USE OF THIS SOFTWARE.


import os
import sys
import time
import json
import hashlib
import ctypes
import ctypes.util
import subprocess
from pathlib import Path

LIBC = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)

PTRACE_TRACEME = 0
PTRACE_CONT = 7

BASE = Path(__file__).resolve().parent.parent / "build" / "process_baseline"
RUNS = 5

TARGETS = [
    "/bin/echo",
    "/bin/cat",
    "/bin/sleep",
    "/bin/true",
    "/bin/false",
    "/bin/pwd",
    "/bin/hostname",
    "/bin/uname",
    "/bin/date",
    "/bin/id",
    "/bin/ls",
    "/bin/kill",
    "/bin/mkdir",
    "/bin/rm",
    "/bin/sh",
]

def personality_no_aslr():
    PER_LINUX = 0x0000
    ADDR_NO_RANDOMIZE = 0x0040000
    old = LIBC.personality(0xffffffff)
    LIBC.personality(old | ADDR_NO_RANDOMIZE)

def child_exec(path):
    personality_no_aslr()

    os.environ.clear()

    if LIBC.ptrace(PTRACE_TRACEME, 0, None, None) != 0:
        os._exit(111)

    args = [path]

    if os.path.basename(path) == "sleep":
        args.append("60")

    os.execve(path, args, {})

def read_maps(pid):
    maps = []

    with open(f"/proc/{pid}/maps", "r") as f:
        for line in f:
            parts = line.rstrip("\n").split(None, 5)
            if len(parts) < 5:
                continue

            a, perms, off, dev, inode = parts[:5]
            name = parts[5] if len(parts) == 6 else ""

            start_s, end_s = a.split("-")
            start = int(start_s, 16)
            end = int(end_s, 16)

            maps.append({
                "start": start,
                "end": end,
                "perms": perms,
                "offset": int(off, 16),
                "dev": dev,
                "inode": int(inode),
                "name": name
            })

    return maps

def capture(pid, maps):
    chunks = []

    with open(f"/proc/{pid}/mem", "rb", buffering=0) as mem:
        for m in maps:
            if "r" not in m["perms"]:
                continue

            size = m["end"] - m["start"]

            try:
                mem.seek(m["start"])
                data = mem.read(size)
            except OSError:
                continue

            if len(data) != size:
                continue

            chunks.append({
                "start": m["start"],
                "end": m["end"],
                "perms": m["perms"],
                "offset": m["offset"],
                "name": m["name"],
                "data": data
            })

    return chunks

def sha256_file(path):
    h = hashlib.sha256()

    with open(path, "rb") as f:
        while True:
            b = f.read(1024 * 1024)
            if not b:
                break
            h.update(b)

    return h.hexdigest()

def wait_for_exec(pid):
    while True:
        wpid, status = os.waitpid(pid, 0)

        if os.WIFSTOPPED(status):
            return

        if os.WIFEXITED(status) or os.WIFSIGNALED(status):
            raise RuntimeError(f"process {pid} exited before P0")

def capture_one(path, run_dir):
    pid = os.fork()

    if pid == 0:
        child_exec(path)
        os._exit(112)

    try:
        wait_for_exec(pid)

        maps = read_maps(pid)
        chunks = capture(pid, maps)

        metadata = {
            "path": path,
            "pid": pid,
            "maps": maps,
            "capture_time": time.time()
        }

        with open(run_dir / "maps.json", "w") as f:
            json.dump(metadata, f, indent=2)

        crystal_path = run_dir / "memory.bin"

        with open(crystal_path, "wb") as out:
            for c in chunks:
                out.write(c["data"])

        metadata["memory_bytes"] = crystal_path.stat().st_size
        metadata["sha256"] = sha256_file(crystal_path)

        with open(run_dir / "metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)

    finally:
        try:
            os.kill(pid, 9)
        except ProcessLookupError:
            pass

        try:
            os.waitpid(pid, 0)
        except ChildProcessError:
            pass

def main():
    BASE.mkdir(parents=True, exist_ok=True)

    targets = [
        p for p in TARGETS
        if os.path.isfile(p) and os.access(p, os.X_OK)
    ]

    print(f"[BASELINE] {len(targets)} executables")
    print(f"[BASELINE] {RUNS} P0 captures each")
    print()

    for path in targets:
        name = os.path.basename(path)
        exe_hash = sha256_file(path)

        print(f"[PROCESS] {path}")
        print(f"  ELF SHA256: {exe_hash}")

        proc_dir = BASE / name
        proc_dir.mkdir(exist_ok=True)

        for n in range(1, RUNS + 1):
            run_dir = proc_dir / f"run{n:02d}"
            run_dir.mkdir(exist_ok=True)

            try:
                capture_one(path, run_dir)

                meta = json.loads(
                    (run_dir / "metadata.json").read_text()
                )

                print(
                    f"  run {n:02d}: "
                    f"{meta['memory_bytes']} bytes "
                    f"{meta['sha256'][:16]}"
                )

            except Exception as e:
                print(f"  run {n:02d}: ERROR: {e}")

        print()

if __name__ == "__main__":
    main()
