# Copyright (c) 2026 Christopher T. Williams
# 
# Permission is granted to use, copy, modify, and distribute this software
# for research, testing, and security-analysis purposes, provided that the
# copyright notice and this permission notice are retained.
# 
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL
# NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE
# USE OF THIS SOFTWARE.

#!/usr/bin/env python3

import os
import stat
import json
import hashlib
import time

ROOTS = [
    "/bin",
    "/sbin",
    "/usr/bin",
    "/usr/sbin",
    "/usr/local/bin",
    "/usr/local/sbin",
    "/opt",
    "/data",
    "/root",
]

SKIP_PREFIXES = (
    "/proc",
    "/sys",
    "/dev",
    "/run",
    "/tmp",
    "/var/cache",
    "/var/lib/docker",
    "/var/lib/containers",
)

OUTDIR = str(Path(__file__).resolve().parent.parent / "build" / "inventory")
os.makedirs(OUTDIR, exist_ok=True)

RUN_ID = time.strftime("%Y%m%d_%H%M%S")

JSON_OUT = os.path.join(
    OUTDIR,
    f"executable_inventory_{RUN_ID}.json"
)

JSONL_OUT = os.path.join(
    OUTDIR,
    f"executable_inventory_{RUN_ID}.jsonl"
)

seen = set()
records = []


def should_skip(path):
    for prefix in SKIP_PREFIXES:
        if path == prefix or path.startswith(prefix + "/"):
            return True
    return False


def sha256_file(path):
    h = hashlib.sha256()

    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)

        return h.hexdigest()

    except Exception:
        return ""


def classify(path):
    try:
        with open(path, "rb") as f:
            head = f.read(4096)
    except Exception:
        return "UNREADABLE"

    if head.startswith(b"\x7fELF"):
        return "ELF"

    if head.startswith(b"#!"):
        return "SCRIPT"

    return "EXECUTABLE_OTHER"


def add_file(path):
    try:
        real = os.path.realpath(path)

        if real in seen:
            return

        seen.add(real)

        st = os.stat(path)

        if not stat.S_ISREG(st.st_mode):
            return

        if not (st.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)):
            return

        record = {
            "path": path,
            "resolved_path": real,
            "device": f"{st.st_dev:x}",
            "inode": st.st_ino,
            "size": st.st_size,
            "mode": oct(st.st_mode & 0o7777),
            "uid": st.st_uid,
            "gid": st.st_gid,
            "type": classify(path),
            "sha256": sha256_file(path),
        }

        records.append(record)

    except Exception as e:
        records.append({
            "path": path,
            "state": "FAILED",
            "error": type(e).__name__,
            "message": str(e),
        })


def scan_root(root):
    if not os.path.exists(root):
        return

    for current, dirs, files in os.walk(
        root,
        topdown=True,
        followlinks=False
    ):
        if should_skip(current):
            dirs[:] = []
            continue

        dirs[:] = [
            d for d in dirs
            if not should_skip(os.path.join(current, d))
        ]

        for name in files:
            path = os.path.join(current, name)

            try:
                if should_skip(path):
                    continue

                if os.access(path, os.X_OK):
                    add_file(path)

            except Exception:
                continue


print("=" * 60)
print(" FILESYSTEM EXECUTABLE INVENTORY")
print("=" * 60)
print()
print("READ ONLY")
print("NO EXECUTION")
print("NO PROCESS MODIFICATION")
print()
print("Roots:")

for root in ROOTS:
    print(f"  {root}")

print()

for root in ROOTS:
    print(f"[SCAN] {root}", flush=True)
    scan_root(root)

records.sort(
    key=lambda x: (
        x.get("type", ""),
        x.get("resolved_path", x.get("path", ""))
    )
)

with open(JSON_OUT, "w", encoding="utf-8") as f:
    json.dump(
        {
            "run_id": RUN_ID,
            "generated_unix": time.time(),
            "roots": ROOTS,
            "count": len(records),
            "records": records,
        },
        f,
        indent=2
    )

with open(JSONL_OUT, "w", encoding="utf-8") as f:
    for record in records:
        f.write(json.dumps(record, sort_keys=True) + "\n")

print()
print("=" * 60)
print(" INVENTORY COMPLETE")
print("=" * 60)
print()
print(f"Executable objects: {len(records)}")
print(f"JSON:               {JSON_OUT}")
print(f"JSONL:              {JSONL_OUT}")
print()

counts = {}

for r in records:
    t = r.get("type", "FAILED")
    counts[t] = counts.get(t, 0) + 1

for t in sorted(counts):
    print(f"{t:20s} {counts[t]:6d}")

print()
