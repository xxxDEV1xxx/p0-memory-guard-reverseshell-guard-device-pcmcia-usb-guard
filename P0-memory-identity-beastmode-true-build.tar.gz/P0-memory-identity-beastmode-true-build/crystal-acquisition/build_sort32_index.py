# Copyright (c) 2026 Christopher T. Williams
# 
# Permission is granted to use, copy, modify, and distribute this software
# for research, testing, and security-analysis purposes, provided that the
# copyright notice and this permission notice are retained.
# 
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL
# NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE
# USE OF THIS SOFTWARE.

#!/usr/bin/env python3

from pathlib import Path

BASE = Path(__file__).resolve().parent.parent / "build"
MASTER = BASE / "database/memory_master_index.tsv"
OUT = BASE / "database/memory_master_index_sort32.tsv"

SORT_OFFSET = 32
SORT_WIDTH = 32


def load_memory(directory):
    root = BASE / "p0" / directory
    parts = sorted(root.glob("*.bin"))
    if not parts:
        raise RuntimeError(f"no .bin files: {root}")
    return b"".join(p.read_bytes() for p in parts)


rows = []

with MASTER.open("r") as f:
    for line in f:
        line = line.rstrip("\n")
        if not line:
            continue

        parts = line.split("\t")

        if parts[0] == "fingerprint":
            continue

        if len(parts) < 5:
            continue

        fingerprint = parts[0]
        directory = parts[1]
        name = parts[2]
        path = parts[3]
        size = int(parts[4])

        memory = load_memory(directory)

        if len(memory) < SORT_OFFSET + SORT_WIDTH:
            raise RuntimeError(
                f"{directory}: only {len(memory)} bytes; "
                f"need {SORT_OFFSET + SORT_WIDTH}"
            )

        sort_key = memory[SORT_OFFSET:SORT_OFFSET + SORT_WIDTH]

        rows.append({
            "sort_key": sort_key,
            "fingerprint": fingerprint,
            "directory": directory,
            "name": name,
            "path": path,
            "size": size,
        })

        if len(rows) % 500 == 0:
            print(f"[LOAD] {len(rows):,}", flush=True)

rows.sort(key=lambda r: r["sort_key"])

with OUT.open("w") as f:
    f.write("sort_key_hex\tfingerprint\tdirectory\tname\tpath\tsize\n")

    for r in rows:
        f.write(
            f"{r['sort_key'].hex()}\t"
            f"{r['fingerprint']}\t"
            f"{r['directory']}\t"
            f"{r['name']}\t"
            f"{r['path']}\t"
            f"{r['size']}\n"
        )

print()
print(f"[DONE] entries : {len(rows):,}")
print(f"[DONE] offset  : {SORT_OFFSET}")
print(f"[DONE] width   : {SORT_WIDTH}")
print(f"[DONE] output  : {OUT}")
