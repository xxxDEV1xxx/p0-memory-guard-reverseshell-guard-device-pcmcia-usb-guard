# Copyright (c) 2026 Christopher T. Williams
# 
# Permission is granted to use, copy, modify, and distribute this software
# for research, testing, and security-analysis purposes, provided that the
# copyright notice and this permission notice are retained.
# 
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL
# NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE
# USE OF THIS SOFTWARE.

#!/usr/bin/env python3

import os
import sys
import json
import time
import signal
import ctypes
import ctypes.util
import hashlib
import subprocess

BASE = str(Path(__file__).resolve().parent.parent / "build")
INV = os.path.join(BASE, "inventory")
P0 = os.path.join(BASE, "p0")
LOG = os.path.join(BASE, "logs")

os.makedirs(P0, exist_ok=True)
os.makedirs(LOG, exist_ok=True)

libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)

PER_LAUNCH_TIMEOUT = 5


def personality_no_aslr():
    ADDR_NO_RANDOMIZE = 0x0040000
    libc.personality.argtypes = [ctypes.c_ulong]
    libc.personality.restype = ctypes.c_int
    libc.personality(ADDR_NO_RANDOMIZE)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def parse_maps(pid):
    result = []

    with open(f"/proc/{pid}/maps", "r") as f:
        for line in f:
            parts = line.rstrip("\n").split(None, 5)

            if len(parts) < 5:
                continue

            address, perms, offset, dev, inode = parts[:5]
            path = parts[5] if len(parts) == 6 else ""

            start, end = address.split("-", 1)

            result.append({
                "start": int(start, 16),
                "end": int(end, 16),
                "length": int(end, 16) - int(start, 16),
                "perms": perms,
                "file_offset": int(offset, 16),
                "dev": dev,
                "inode": int(inode),
                "path": path,
            })

    return result


def read_memory(pid, address, length):
    path = f"/proc/{pid}/mem"

    with open(path, "rb", buffering=0) as f:
        f.seek(address)
        return f.read(length)


def capture(pid):
    maps = parse_maps(pid)
    records = []

    for m in maps:
        if "r" not in m["perms"]:
            continue

        try:
            data = read_memory(
                pid,
                m["start"],
                m["length"]
            )
        except Exception as e:
            records.append({
                "mapping": m,
                "state": "READ_FAILED",
                "error": type(e).__name__,
                "message": str(e),
            })
            continue

        records.append({
            "mapping": m,
            "state": "CAPTURED",
            "sha256": sha256(data),
            "bytes": len(data),
            "data": data,
        })

    return records


def wait_exec_stop(pid):
    while True:
        try:
            waited, status = os.waitpid(
                pid,
                os.WUNTRACED
            )

            if waited != pid:
                continue

            if os.WIFSTOPPED(status):
                return os.WSTOPSIG(status)

            return None

        except InterruptedError:
            continue


def launch_elf(path):
    pid = os.fork()

    if pid == 0:
        try:
            personality_no_aslr()

            os.environ.clear()

            libc.ptrace(
                0,
                0,
                None,
                None
            )

            os.execve(
                path,
                [path],
                {}
            )

        except BaseException:
            os._exit(127)

    return pid


def acquire_one(item, index, total):
    path = item.get("resolved_path") or item.get("path")
    analysis = item.get("analysis", {})
    fmt = analysis.get("format")
    action = analysis.get("acquisition")

    print(
        f"[{index:5d}/{total:5d}] "
        f"{fmt:18s} "
        f"{path}",
        flush=True
    )

    if action != "ELF_CONTROLLED_P0":
        return {
            "state": "DEFERRED",
            "path": path,
            "reason": action,
        }

    pid = launch_elf(path)

    start = time.time()

    while True:
        result = os.waitpid(
            pid,
            os.WUNTRACED | os.WNOHANG
        )

        if result[0] == pid:
            _, status = result

            if os.WIFSTOPPED(status):
                break

            return {
                "state": "LAUNCH_FAILED",
                "path": path,
                "status": status,
            }

        if time.time() - start > PER_LAUNCH_TIMEOUT:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

            try:
                os.waitpid(pid, 0)
            except Exception:
                pass

            return {
                "state": "TIMEOUT",
                "path": path,
            }

        time.sleep(0.01)

    try:
        records = capture(pid)

        run_id = time.strftime(
            "%Y%m%d_%H%M%S"
        )

        safe = os.path.basename(path).replace(
            "/", "_"
        )

        outdir = os.path.join(
            P0,
            f"{safe}_{run_id}_{pid}"
        )

        os.makedirs(outdir, exist_ok=True)

        maps = []

        for r in records:
            m = dict(r["mapping"])

            m.pop("data", None)

            if r["state"] == "CAPTURED":
                m["sha256"] = r["sha256"]
                m["bytes"] = r["bytes"]

                filename = (
                    f"{m['start']:016x}_"
                    f"{m['length']:x}.bin"
                )

                with open(
                    os.path.join(outdir, filename),
                    "wb"
                ) as f:
                    f.write(r["data"])

            maps.append({
                **m,
                "state": r["state"],
                "error": r.get("error", ""),
            })

        metadata = {
            "path": path,
            "resolved_path": item.get(
                "resolved_path",
                path
            ),
            "inventory_sha256": item.get(
                "sha256",
                ""
            ),
            "pid": pid,
            "captured_unix": time.time(),
            "mapping_count": len(records),
        }

        with open(
            os.path.join(outdir, "metadata.json"),
            "w"
        ) as f:
            json.dump(metadata, f, indent=2)

        with open(
            os.path.join(outdir, "maps.json"),
            "w"
        ) as f:
            json.dump(maps, f, indent=2)

        return {
            "state": "P0_CAPTURED",
            "path": path,
            "pid": pid,
            "output": outdir,
            "mappings": len(records),
        }

    finally:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

        try:
            os.waitpid(pid, 0)
        except Exception:
            pass


def main():
    if len(sys.argv) != 2:
        print(
            "usage: memory_p0_acquire.py "
            "MANIFEST.json"
        )
        sys.exit(1)

    manifest_path = sys.argv[1]

    with open(manifest_path, "r") as f:
        manifest = json.load(f)

    objects = manifest["objects"]

    print("=" * 60)
    print(" CTW PROCESS MEMORY P0 ACQUISITION")
    print("=" * 60)
    print()
    print(f"Manifest objects: {len(objects)}")
    print()

    results = []

    for index, item in enumerate(
        objects,
        1
    ):
        try:
            result = acquire_one(
                item,
                index,
                len(objects)
            )

        except Exception as e:
            result = {
                "state": "FAILED",
                "path": item.get(
                    "resolved_path",
                    item.get("path", "")
                ),
                "error": type(e).__name__,
                "message": str(e),
            }

        results.append(result)

    logfile = os.path.join(
        LOG,
        f"p0_acquisition_{time.strftime('%Y%m%d_%H%M%S')}.json"
    )

    with open(logfile, "w") as f:
        json.dump(
            results,
            f,
            indent=2
        )

    counts = {}

    for result in results:
        state = result["state"]
        counts[state] = counts.get(
            state,
            0
        ) + 1

    print()
    print("=" * 60)
    print(" P0 ACQUISITION COMPLETE")
    print("=" * 60)
    print()

    for state in sorted(counts):
        print(
            f"{state:20s} "
            f"{counts[state]:6d}"
        )

    print()
    print(f"Log: {logfile}")


if __name__ == "__main__":
    main()
