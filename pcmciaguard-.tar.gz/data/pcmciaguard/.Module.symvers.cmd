cmd_/data/pcmciaguard/Module.symvers :=  sed 's/ko$$/o/'  /data/pcmciaguard/modules.order | scripts/mod/modpost -m      -o /data/pcmciaguard/Module.symvers -e -i Module.symvers -T - 
