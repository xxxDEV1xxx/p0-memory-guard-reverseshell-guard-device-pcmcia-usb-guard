#include <endian.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <linux/usb/ch9.h>
#include <linux/usb/functionfs.h>

struct bt_interface {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bInterfaceNumber;
    uint8_t bAlternateSetting;
    uint8_t bNumEndpoints;
    uint8_t bInterfaceClass;
    uint8_t bInterfaceSubClass;
    uint8_t bInterfaceProtocol;
    uint8_t iInterface;
} __attribute__((packed));

struct bt_desc_set {
    struct bt_interface interface;
    struct usb_endpoint_descriptor_no_audio ep1;
    struct usb_endpoint_descriptor_no_audio ep2;
    struct usb_endpoint_descriptor_no_audio ep3;
} __attribute__((packed));

struct bt_descs {
    struct usb_functionfs_descs_head_v2 head;
    uint32_t fs_count;
    uint32_t hs_count;
    struct bt_desc_set fs;
    struct bt_desc_set hs;
};

static struct bt_descs descs;

static void init_descs(void)
{
    descs.head.magic = FUNCTIONFS_DESCRIPTORS_MAGIC_V2;
    descs.head.length = sizeof(descs);
    descs.head.flags = FUNCTIONFS_HAS_FS_DESC |
                       FUNCTIONFS_HAS_HS_DESC;

    descs.fs_count = 4;
    descs.hs_count = 4;

    descs.fs.interface.bLength = 9;
    descs.fs.interface.bDescriptorType = USB_DT_INTERFACE;
    descs.fs.interface.bInterfaceNumber = 0;
    descs.fs.interface.bAlternateSetting = 0;
    descs.fs.interface.bNumEndpoints = 3;
    descs.fs.interface.bInterfaceClass = 0xE0;
    descs.fs.interface.bInterfaceSubClass = 0x01;
    descs.fs.interface.bInterfaceProtocol = 0x01;
    descs.fs.interface.iInterface = 0;

    descs.fs.ep1.bLength = 7;
    descs.fs.ep1.bDescriptorType = USB_DT_ENDPOINT;
    descs.fs.ep1.bEndpointAddress = 0x81;
    descs.fs.ep1.bmAttributes = USB_ENDPOINT_XFER_BULK;
    descs.fs.ep1.wMaxPacketSize = 64;
    descs.fs.ep1.bInterval = 0;

    descs.fs.ep2.bLength = 7;
    descs.fs.ep2.bDescriptorType = USB_DT_ENDPOINT;
    descs.fs.ep2.bEndpointAddress = 0x02;
    descs.fs.ep2.bmAttributes = USB_ENDPOINT_XFER_BULK;
    descs.fs.ep2.wMaxPacketSize = 64;
    descs.fs.ep2.bInterval = 0;

    descs.fs.ep3.bLength = 7;
    descs.fs.ep3.bDescriptorType = USB_DT_ENDPOINT;
    descs.fs.ep3.bEndpointAddress = 0x83;
    descs.fs.ep3.bmAttributes = USB_ENDPOINT_XFER_INT;
    descs.fs.ep3.wMaxPacketSize = 8;
    descs.fs.ep3.bInterval = 4;

    descs.hs = descs.fs;

    descs.hs.ep1.wMaxPacketSize = 512;
    descs.hs.ep2.wMaxPacketSize = 512;
}

struct bt_strings {
    uint32_t magic;
    uint32_t length;
    uint32_t str_count;
    uint32_t lang_count;
    uint16_t lang;
    char string[16];
} __attribute__((packed));

static struct bt_strings strings;

static void init_strings(void)
{
    strings.magic = FUNCTIONFS_STRINGS_MAGIC;
    strings.length = sizeof(strings);
    strings.str_count = 1;
    strings.lang_count = 1;
    strings.lang = 0x0409;
    snprintf(strings.string, sizeof(strings.string), "%s", "Bluetooth");
}

static int write_all(int fd, const void *buf, size_t len)
{
    const uint8_t *p = buf;

    while (len) {
        ssize_t n = write(fd, p, len);

        if (n < 0) {
            perror("write");
            return -1;
        }

        if (n == 0) {
            fprintf(stderr, "write returned zero\n");
            return -1;
        }

        p += n;
        len -= (size_t)n;
    }

    return 0;
}

int main(void)
{
    int fd;

    init_descs();
    init_strings();

    fd = open("/dev/ffs-bt0/ep0", O_RDWR);
    if (fd < 0) {
        perror("open ep0");
        return 1;
    }

    if (write_all(fd, &descs, sizeof(descs)) < 0) {
        close(fd);
        return 2;
    }

    if (write_all(fd, &strings, sizeof(strings)) < 0) {
        close(fd);
        return 3;
    }

    printf("DESCRIPTORS_WRITTEN=%zu\n", sizeof(descs));
    printf("STRINGS_WRITTEN=%zu\n", sizeof(strings));
    printf("BT_INTERFACE=09 04 00 00 03 E0 01 01 00\n");
    fflush(stdout);

    for (;;) {
        pause();
    }
}
