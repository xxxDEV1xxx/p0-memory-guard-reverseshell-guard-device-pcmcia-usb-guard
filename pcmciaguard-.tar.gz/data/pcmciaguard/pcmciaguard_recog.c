#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kprobes.h>
#include <linux/pci.h>
#include <linux/types.h>

#include "pcmciaguard_recog_policy.h"

struct pci_vid_probe_data {
	struct pci_bus *bus;
	u32 *id_word;
	int devfn;
	int timeout;
	unsigned long ip;
	bool valid;
};

static int pcmciaguard_vid_entry(struct kretprobe_instance *ri,
				 struct pt_regs *regs)
{
	struct pci_vid_probe_data *data;

	data = (struct pci_vid_probe_data *)ri->data;

	/*
	 * x86-64 System V kernel calling convention:
	 *
	 *   RDI = bus
	 *   RSI = devfn
	 *   RDX = l
	 *   RCX = timeout
	 */
	data->bus = (struct pci_bus *)regs->di;
	data->devfn = (int)regs->si;
	data->id_word = (u32 *)regs->dx;
	data->timeout = (int)regs->cx;
	data->ip = regs->ip;
	data->valid = true;

	return 0;
}

static int pcmciaguard_vid_ret(struct kretprobe_instance *ri,
			       struct pt_regs *regs)
{
	struct pci_vid_probe_data *data;
	struct pcmciaguard_pci_identity id;
	unsigned long result;

	data = (struct pci_vid_probe_data *)ri->data;

	if (!data->valid || !data->id_word)
		return 0;

	result = regs_return_value(regs);

	/*
	 * Original function returned false: there is no recognized
	 * PCI device to gate.
	 */
        pr_info("pcmciaguard: PCI AUDIT ip=%px bus=%s devfn=%02x "
                "raw=%08x vendor=%04x device=%04x timeout=%d result=%lu\n",
                (void *)data->ip,
                data->bus ? data->bus->name : "NULL",
                data->devfn,
                *data->id_word,
                (u16)(*data->id_word & 0xffff),
                (u16)((*data->id_word >> 16) & 0xffff),
                data->timeout,
                result);

	if (!result)
		return 0;

	/*
	 * pci_bus_read_dev_vendor_id() writes:
	 *
	 *   bits  0..15 = vendor
	 *   bits 16..31 = device
	 */
	id.vendor = (u16)(*data->id_word & 0xffff);
	id.device = (u16)((*data->id_word >> 16) & 0xffff);

	if (pcmciaguard_deny_identity(&id)) {
		pr_info("pcmciaguard: PCI RECOGNITION DENY "
			"vendor=%04x device=%04x "
			"devfn=%02x timeout=%d\n",
			id.vendor,
			id.device,
			data->devfn,
			data->timeout);

		regs_set_return_value(regs, 0);
		return 0;
	}

	return 0;
}

static struct kretprobe pcmciaguard_vid_probe = {
	.kp.symbol_name = "pci_bus_generic_read_dev_vendor_id",
	.entry_handler  = pcmciaguard_vid_entry,
	.handler        = pcmciaguard_vid_ret,
	.data_size      = sizeof(struct pci_vid_probe_data),
	.maxactive      = 64,
};

static struct kprobe pcmciaguard_cfg_addr_probe = {
        .symbol_name = "pci_bus_read_config_dword",
};

static int __init pcmciaguard_recog_init(void)
{
	int ret;

	ret = register_kretprobe(&pcmciaguard_vid_probe);
	if (ret) {
		pr_err("pcmciaguard: failed to register VID kretprobe: %d\n",
		       ret);
		return ret;
	}

	pr_info("pcmciaguard: PCI VID/DID recognition gate ACTIVE\n");
        pr_info("pcmciaguard: resolved target addr=%px\n", (void *)pcmciaguard_vid_probe.kp.addr);

        ret = register_kprobe(&pcmciaguard_cfg_addr_probe);
        if (ret) {
                pr_err("pcmciaguard: failed to register cfgread address probe: %d\n",
                       ret);
                unregister_kretprobe(&pcmciaguard_vid_probe);
                return ret;
        }

        pr_info("pcmciaguard: cfgread runtime addr=%px\n",
                (void *)pcmciaguard_cfg_addr_probe.addr);


	{
		unsigned char *text;
		int i;

		text = (unsigned char *)pcmciaguard_vid_probe.kp.addr;

		pr_info("pcmciaguard: target bytes:");
		for (i = 0; i < 128; i++)
			pr_cont(" %02x", text[i]);
		pr_cont("\n");
	}

    {
        struct pci_dev *bridge;
        struct pci_bus *subordinate;

        bridge = pci_get_domain_bus_and_slot(0, 0,
                                             PCI_DEVFN(0x1c, 0));

        if (!bridge) {
            pr_info("pcmciaguard: TEST bridge 0000:00:1c.0 not found\n");
        } else {
            subordinate = bridge->subordinate;

            pr_info("pcmciaguard: TEST subordinate=%s\n",
                    subordinate ? subordinate->name : "NULL");

            if (subordinate) {
                pci_lock_rescan_remove();
                pci_rescan_bus(subordinate);
                pci_unlock_rescan_remove();

                pr_info("pcmciaguard: TEST bus rescan complete\n");
            }

            pci_dev_put(bridge);
        }
    }
	return 0;
}

static void __exit pcmciaguard_recog_exit(void)
{
	unregister_kprobe(&pcmciaguard_cfg_addr_probe);
        unregister_kretprobe(&pcmciaguard_vid_probe);

	pr_info("pcmciaguard: PCI VID/DID recognition gate REMOVED\n");
}

module_init(pcmciaguard_recog_init);
module_exit(pcmciaguard_recog_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Christopher T. Williams");
MODULE_DESCRIPTION("PCI pre-allocation VID/DID recognition guard");
