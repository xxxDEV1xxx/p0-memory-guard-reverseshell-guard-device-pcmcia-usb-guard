/*
 * pcmciaguard
 *
 * P0 module-load enforcement for the PCMCIA/CardBus Yenta driver.
 *
 * Initial enforcement target:
 *     yenta_socket
 *
 * This is deliberately independent of the driver's own behavior.
 *
 * Covered paths:
 *     request_module("yenta_socket")
 *     finit_module(fd, ...)
 *     init_module(buf, ...)
 *
 * The request/read hooks provide early enforcement.
 * The post-load-data hook covers the raw init_module() image.
 */

#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/lsm_hooks.h>
#include <linux/fs.h>
#include <linux/kernel_read_file.h>
#include <linux/slab.h>
#include <linux/string.h>

#define PCMCIA_GUARD_NAME "pcmciaguard"
#define PCMCIA_GUARD_TARGET "yenta_socket"

static int pcmciaguard_deny_name(const char *name)
{
if (!name)
return 0;

if (!strcmp(name, PCMCIA_GUARD_TARGET)) {
pr_warn_ratelimited(
PCMCIA_GUARD_NAME ": DENY module %s\n",
name);
return -EPERM;
}

return 0;
}

static int pcmciaguard_module_request(char *kmod_name)
{
return pcmciaguard_deny_name(kmod_name);
}

static int pcmciaguard_module_load(const char *name)
{
return pcmciaguard_deny_name(name);
}

static int pcmciaguard_read_file(struct file *file,
 enum kernel_read_file_id id,
 bool contents)
{
char *path;
int ret = 0;

if (id != READING_MODULE || !file)
return 0;

path = kmalloc(PATH_MAX, GFP_KERNEL);
if (!path)
return -ENOMEM;

if (!IS_ERR(file_path(file, path, PATH_MAX))) {
char *p = strrchr(path, '/');

if (p && !strcmp(p + 1, "yenta_socket.ko"))
ret = -EPERM;
}

if (ret)
pr_warn_ratelimited(
PCMCIA_GUARD_NAME
": DENY module file %s\n",
path);

kfree(path);
return ret;
}

/*
 * init_module() supplies the module image directly rather than through
 * kernel_read_file_from_fd().  The generic post-load-data hook gives us
 * the complete image, but does not provide its parsed module name.
 *
 * The initial build intentionally does not reject arbitrary LOADING_MODULE
 * data here.  We first validate the request/finit_module gates, then add
 * the ELF/.modinfo identity parser for raw init_module().
 */
static int pcmciaguard_post_load_data(char *buf, loff_t size,
      enum kernel_load_data_id id,
      char *description)
{
if (id == LOADING_MODULE &&
    description &&
    !strcmp(description, "init_module")) {
pr_info_ratelimited(
PCMCIA_GUARD_NAME
": observed init_module image size=%lld\n",
size);
}

return 0;
}

static struct security_hook_list pcmciaguard_hooks[] = {
LSM_HOOK_INIT(kernel_module_request, pcmciaguard_module_request),
LSM_HOOK_INIT(kernel_module_load, pcmciaguard_module_load),
LSM_HOOK_INIT(kernel_read_file, pcmciaguard_read_file),
LSM_HOOK_INIT(kernel_post_load_data, pcmciaguard_post_load_data),
};


static int __init pcmciaguard_init(void)
{
    security_add_hooks(
        pcmciaguard_hooks,
        ARRAY_SIZE(pcmciaguard_hooks),
        "pcmciaguard"
    );

    pr_info("pcmciaguard: loaded\n");

    return 0;
}

static void __exit pcmciaguard_exit(void)
{
    pr_info("pcmciaguard: unloaded\n");
}

module_init(pcmciaguard_init);
module_exit(pcmciaguard_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("PCMCIA/CardBus module authorization guard");
MODULE_AUTHOR("DEV1");
