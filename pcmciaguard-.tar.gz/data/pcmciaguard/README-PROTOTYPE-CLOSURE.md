# PCMCIGUARD Device-Class Policy Prototype

## Prototype Closure

Date: 2026-10-02

This directory contains the completed prototype for USB device-class policy enforcement against printer and Bluetooth device classes.

The demonstrated path is:

    OBSERVED DEVICE
          |
          v
    USB INTERFACE IDENTITY
          |
          +-- class
          +-- subclass
          +-- protocol
          |
          v
    EXPLICIT CLASS POLICY
          |
          v
    USB AUTHORIZATION STATE

The prototype is deliberately limited to post-enumeration userspace authorization enforcement. Kernel-level driver-binding veto, module-loader enforcement, and insertion-time prevention are outside this prototype closure.

## Policy

The prototype contains blanket denial rules for:

- USB printer class: 0x07
- USB Bluetooth/wireless-controller class: 0xE0

Other USB interface classes remain undecided and untouched.

The policy is implemented through the generic device-class policy abstraction rather than treating USB as the complete device architecture.

## Validation

### Byte-level validation

Printer:

    09 04 00 00 02 07 01 02 00
    class=0x07 subclass=0x01 protocol=0x02
    policy=DENY

Bluetooth:

    09 04 00 00 03 E0 01 01 00
    class=0xe0 subclass=0x01 protocol=0x01
    policy=DENY

Hub:

    09 04 00 00 01 09 00 00 00
    class=0x09 subclass=0x00 protocol=0x00
    policy=UNDECIDED

### Synthetic printer

A configfs/FunctionFS synthetic printer gadget was enumerated through dummy_hcd.

Observed:

    3-1:1.0 CLASS=07 SUBCLASS=01 PROTOCOL=02

The policy denied the interface and the resulting authorization state was:

    authorized=0

### Synthetic Bluetooth

A FunctionFS synthetic Bluetooth gadget was enumerated through dummy_hcd.

Observed:

    3-1:1.0 CLASS=e0 SUBCLASS=01 PROTOCOL=01

The policy denied the interface and the resulting authorization state was:

    authorized=0

The synthetic device also exercised the kernel Bluetooth path. The synthetic controller was not intended to provide a complete functional Bluetooth HCI implementation.

### Real Bluetooth hardware

A physical Realtek Bluetooth Radio was observed:

    VID=0bda
    PID=8771
    MANUFACTURER=Realtek
    PRODUCT=Bluetooth Radio

Before enforcement:

    2-1.3:1.0 CLASS=e0 SUBCLASS=01 PROTOCOL=01 AUTHORIZED=1 DRIVER=btusb
    2-1.3:1.1 CLASS=e0 SUBCLASS=01 PROTOCOL=01 AUTHORIZED=1 DRIVER=btusb

The existing policy was applied without changing the Bluetooth rule.

The guard produced DENIED decisions for both interfaces.

After enforcement:

    2-1.3:1.0 CLASS=e0 SUBCLASS=01 PROTOCOL=01 AUTHORIZED=0
    2-1.3:1.1 CLASS=e0 SUBCLASS=01 PROTOCOL=01 AUTHORIZED=0

This is the real-hardware closure test.

## Demonstrated Security Path

    descriptor bytes
        ->
    kernel USB enumeration
        ->
    sysfs interface identity
        ->
    class policy lookup
        ->
    authorization action

The real-device test demonstrates that the policy does not depend on the synthetic device's vendor/product identity.

The Realtek device initially bound to btusb, establishing the observed Bluetooth identity on actual hardware. The policy then changed both interface authorization states to zero.

## Scope Boundary

This prototype does not claim:

- insertion-time prevention before enumeration;
- kernel-level veto of driver binding;
- module-loader enforcement;
- coverage of PCI, SDIO, platform, PNP, ACPI, or other buses;
- universal Bluetooth or printer detection across every possible bus;
- persistent enforcement across all future device events.

Those are subsequent stages of the broader device-fabric architecture.

## Closure

The prototype stage is closed after successful validation of:

1. deterministic byte-level class recognition;
2. synthetic live printer denial;
3. synthetic live Bluetooth denial; and
4. real USB Bluetooth denial against a Realtek 0bda:8771 device.

The next development stage should begin from this frozen snapshot rather than modifying the prototype in place.
