#ifndef DEVICE_CLASS_POLICY_H
#define DEVICE_CLASS_POLICY_H

#include <stddef.h>
#include <stdint.h>

enum device_bus {
    DEVICE_BUS_UNKNOWN = 0,
    DEVICE_BUS_USB,
    DEVICE_BUS_PCI
};

enum device_policy {
    DEVICE_POLICY_UNDECIDED = 0,
    DEVICE_POLICY_ALLOW,
    DEVICE_POLICY_DENY
};

struct device_class_identity {
    enum device_bus bus;
    uint8_t class_code;
    uint8_t subclass;
    uint8_t protocol;
};

struct device_class_rule {
    enum device_bus bus;
    uint8_t class_code;
    enum device_policy policy;
    const char *name;
};

static const struct device_class_rule device_class_rules[] = {
    {
        DEVICE_BUS_USB,
        0x07,
        DEVICE_POLICY_DENY,
        "printer"
    },
    {
        DEVICE_BUS_USB,
        0xE0,
        DEVICE_POLICY_DENY,
        "bluetooth"
    },
    {
        DEVICE_BUS_USB,
        0xFF,
        DEVICE_POLICY_DENY,
        "vendor-specific"
    }
};

#define DEVICE_CLASS_RULE_COUNT \
    (sizeof(device_class_rules) / sizeof(device_class_rules[0]))

static inline enum device_policy
device_class_policy(const struct device_class_identity *id,
                    const char **name)
{
    size_t i;

    if (name)
        *name = "undecided";

    for (i = 0; i < DEVICE_CLASS_RULE_COUNT; ++i) {
        const struct device_class_rule *rule = &device_class_rules[i];

        if (rule->bus != id->bus)
            continue;

        if (rule->class_code != id->class_code)
            continue;

        if (name)
            *name = rule->name;

        return rule->policy;
    }

    return DEVICE_POLICY_UNDECIDED;
}

#endif
