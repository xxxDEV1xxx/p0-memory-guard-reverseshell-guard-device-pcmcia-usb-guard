/data/pcmciaguard/pcmciaguard.o
