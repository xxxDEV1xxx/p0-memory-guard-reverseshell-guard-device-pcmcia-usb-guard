cmd_/data/pcmciaguard/pcmciaguard.mod := printf '%s\n'   pcmciaguard.o | awk '!x[$$0]++ { print("/data/pcmciaguard/"$$0) }' > /data/pcmciaguard/pcmciaguard.mod
