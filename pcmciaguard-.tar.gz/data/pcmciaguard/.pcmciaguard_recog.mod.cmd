cmd_/data/pcmciaguard/pcmciaguard_recog.mod := printf '%s\n'   pcmciaguard_recog.o | awk '!x[$$0]++ { print("/data/pcmciaguard/"$$0) }' > /data/pcmciaguard/pcmciaguard_recog.mod
