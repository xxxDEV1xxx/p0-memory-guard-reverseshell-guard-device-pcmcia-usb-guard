# PCMCIAGuard

Kernel-level default-deny enforcement for the Linux kernel module execution
boundary associated with the PCMCIA/CardBus subsystem.

## Project Scope

PCMCIAGuard currently enforces policy at the Linux kernel module admission
boundary.

The enforcement point is:

    MODULE_STATE_COMING
            |
            v
    PCMCIAGuard notifier
            |
            v
       allow-list
        /       \
      match    no match
       |          |
      ALLOW      DENY
       |          |
       v          v
    module      NOTIFY_BAD
    continues     |
                  v
             module load
                fails

The current implementation is intentionally module-level. It does not yet
attempt to make admission decisions from PCMCIA CIS contents, card identity,
socket identity, or driver/device identity.

## Current Policy

The policy is FULL_DEFAULT_DENY.

The current allow-list is intentionally empty:

    static const char *allow_list[] = {
        NULL
    };

Therefore, any module reaching MODULE_STATE_COMING after PCMCIAGuard has
registered its notifier is denied unless an explicit allow-list entry is
added.

There is no runtime "enforce" bypass parameter.

## PCMCIA Modules Removed From Allow-List

The following modules were previously present in the explicit allow-list and
were removed on 2026-10-01:

    pcmcia_core
    pcmcia_rsrc
    yenta_socket

They are now denied by the default-deny policy.

This change was made because the tested system currently exposes no active
PCMCIA socket and no yenta_socket PCI binding. The three modules could also
be unloaded cleanly during controlled testing.

This project does NOT claim that these modules are universally unnecessary.
The observation is specific to the tested system and its current hardware
configuration.

## Enforcement Test

After rebuilding PCMCIAGuard with the empty allow-list, the following test
was performed:

    modprobe pcmcia_core

The result was:

    modprobe: ERROR: could not insert 'pcmcia_core': Operation not permitted

    MODPROBE_RC=1

PCMCIAGuard recorded:

    pcmciaguard: observed module=pcmcia_core action=COMING
    pcmciaguard: policy=DENY module=pcmcia_core

The module was not loaded.

A subsequent request for the CardBus/PCMCIA driver path was also tested:

    modprobe yenta_socket

The result was:

    modprobe: ERROR: could not insert 'yenta_socket': Operation not permitted

    MODPROBE_YENTA_RC=1

PCMCIAGuard again recorded the dependency admission boundary:

    pcmciaguard: observed module=pcmcia_core action=COMING
    pcmciaguard: policy=DENY module=pcmcia_core

The PCMCIA stack remained unloaded.

## Hardware State During Testing

The tested system was running:

    Linux 6.1.0-50-amd64
    Debian kernel 6.1.176-1

Before the controlled unload, the relevant modules were:

    pcmciaguard
    yenta_socket
    pcmcia_rsrc
    pcmcia_core

The dependency relationship was:

    yenta_socket
        |
        v
    pcmcia_rsrc
        |
        v
    pcmcia_core

The system had no active yenta_socket PCI binding.

The system also had no registered PCMCIA socket at the time of testing.

The relevant PCI topology contained:

    00:1e.0-[03]--

with no CardBus/PCMCIA device populated beneath that bridge.

Therefore the tests establish module-admission behavior and the absence of a
currently active PCMCIA hardware path, but do not constitute a physical card
insertion test.

## Kernel Enforcement Mechanism

The Linux kernel source used for this project is:

    /data/linux-6.1.176

The kernel module subsystem maintains a module notifier chain.

The relevant kernel path calls the notifier chain during module preparation:

    MODULE_STATE_COMING
            |
            v
    module notifier chain
            |
            v
    notifier_to_errno()
            |
            v
    module admission result

PCMCIAGuard registers a blocking module notifier with:

    register_module_notifier()

For MODULE_STATE_COMING, the guard checks the module name against the
explicit allow-list.

An allowed module returns NOTIFY_OK.

A module not present in the allow-list returns NOTIFY_BAD.

The kernel's module preparation path converts the notifier result through
notifier_to_errno(), causing the module load to fail.

This is actual admission control rather than post-load observation.

## Guard Bootstrap Behavior

PCMCIAGuard must register its notifier during its own module initialization.

Consequently, the guard cannot observe its own MODULE_STATE_COMING event because
the notifier does not exist until the guard initialization routine registers
it.

The guard can therefore load itself as a bootstrap condition.

After initialization, subsequent module admission requests are subject to the
configured policy.

A completely self-protecting implementation would require a mechanism outside
this loadable-module bootstrap sequence, such as integration into the kernel
itself.

## Build

The module is built against:

    /data/linux-6.1.176

Build commands:

    cd /data/pcmciaguard
    make clean
    make

The resulting kernel module is:

    /data/pcmciaguard/pcmciaguard.ko

## Load

Load the guard:

    cd /data/pcmciaguard
    insmod ./pcmciaguard.ko

Verify:

    lsmod | grep '^pcmciaguard'

Expected policy message:

    pcmciaguard: active policy=FULL_DEFAULT_DENY

## Test Default-Deny

Example:

    dmesg -C

    modprobe dummy
    rc=$?
    echo "MODPROBE_RC=$rc"

    lsmod | grep '^dummy' || echo "dummy: NOT LOADED"

    dmesg | grep pcmciaguard

Expected result:

    modprobe: ERROR: could not insert 'dummy': Operation not permitted

    MODPROBE_RC=1

    pcmciaguard: observed module=dummy action=COMING
    pcmciaguard: policy=DENY module=dummy

## Restoring the Three PCMCIA Modules

To explicitly allow the three previously removed modules, edit
pcmciaguard.c so that the allow-list becomes:

    static const char *allow_list[] = {
        "pcmcia_core",
        "pcmcia_rsrc",
        "yenta_socket",
        NULL
    };

Then rebuild and reload the guard:

    cd /data/pcmciaguard

    make clean
    make

    rmmod pcmciaguard
    insmod ./pcmciaguard.ko

Verify:

    lsmod | grep '^pcmciaguard'
    dmesg | grep 'pcmciaguard:'

The restored entries permit those module names through the PCMCIAGuard
module-level admission boundary.

Allowing these module names does not guarantee that a PCMCIA/CardBus device
exists, that a socket is registered, or that a particular card will bind to
the resulting driver.

## Restoring Only One Module

The entries can also be restored individually.

For example, to allow only pcmcia_core:

    static const char *allow_list[] = {
        "pcmcia_core",
        NULL
    };

For only pcmcia_rsrc:

    static const char *allow_list[] = {
        "pcmcia_rsrc",
        NULL
    };

For only yenta_socket:

    static const char *allow_list[] = {
        "yenta_socket",
        NULL
    };

After every policy change:

    make clean
    make
    rmmod pcmciaguard
    insmod ./pcmciaguard.ko

## Current Security Boundary

The current enforcement boundary is:

    module request
          |
          v
    MODULE_STATE_COMING
          |
          v
    PCMCIAGuard
          |
          v
    module identity
          |
          v
    explicit policy
          |
       +--+--+
       |     |
      ALLOW DENY
       |     |
       v     v
    continue  fail

This is deliberately distinct from device identity.

The broader intended architecture is:

    PHYSICAL HARDWARE
          |
          v
    CARD IDENTITY
          |
          v
    SOCKET / DEVICE IDENTITY
          |
          v
    DRIVER BINDING
          |
          v
    MODULE IDENTITY
          |
          v
    KERNEL EXECUTION

PCMCIAGuard currently controls the MODULE IDENTITY boundary.

Future work may add a separate device/CIS identity layer rather than mixing
device identity with module admission policy.

## Files

The project directory contains the complete working module tree, including:

    Makefile
    pcmciaguard.c
    README.md
    pcmciaguard.ko
    kernel module build artifacts
    historical source snapshots
    supporting module files

Historical source snapshots are retained as development artifacts and are not
part of the active source path.

## Archive

The complete project archive is generated outside the project directory:

    /data/pcmciaguard.tar.gz

This prevents the archive from recursively including itself.

## Current State

Policy:

    FULL_DEFAULT_DENY

Explicitly allowed modules:

    NONE

Removed from explicit allow-list:

    pcmcia_core
    pcmcia_rsrc
    yenta_socket

Tested kernel:

    Linux 6.1.0-50-amd64

Kernel source:

    /data/linux-6.1.176

Project directory:

    /data/pcmciaguard
