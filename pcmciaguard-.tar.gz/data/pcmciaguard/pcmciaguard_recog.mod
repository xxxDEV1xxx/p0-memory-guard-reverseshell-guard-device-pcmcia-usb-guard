/data/pcmciaguard/pcmciaguard_recog.o
