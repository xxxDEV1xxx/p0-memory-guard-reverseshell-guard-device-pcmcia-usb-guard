#include <stdint.h>
#include <stdio.h>

#include "device-class-policy.h"

struct test_case {
    const char *name;
    const uint8_t *bytes;
    size_t length;
};

static int inspect_usb_interface(const uint8_t *b, size_t len)
{
    struct device_class_identity identity;
    const char *policy_name = NULL;
    enum device_policy policy;

    if (len < 9)
        return -1;

    if (b[0] < 9 || b[1] != 0x04)
        return -1;

    identity.bus = DEVICE_BUS_USB;
    identity.class_code = b[5];
    identity.subclass = b[6];
    identity.protocol = b[7];

    policy = device_class_policy(&identity, &policy_name);

    printf("class=0x%02x subclass=0x%02x protocol=0x%02x "
           "policy=%s identity=%s\n",
           identity.class_code,
           identity.subclass,
           identity.protocol,
           policy == DEVICE_POLICY_DENY ? "DENY" :
           policy == DEVICE_POLICY_ALLOW ? "ALLOW" :
           "UNDECIDED",
           policy_name);

    return policy == DEVICE_POLICY_DENY ? 1 : 0;
}

int main(void)
{
    static const uint8_t printer[] = {
        0x09, 0x04, 0x00, 0x00, 0x02,
        0x07, 0x01, 0x02, 0x00
    };

    static const uint8_t bluetooth[] = {
        0x09, 0x04, 0x00, 0x00, 0x03,
        0xE0, 0x01, 0x01, 0x00
    };

    static const uint8_t hub[] = {
        0x09, 0x04, 0x00, 0x00, 0x01,
        0x09, 0x00, 0x00, 0x00
    };

    static const struct test_case tests[] = {
        { "PRINTER", printer, sizeof(printer) },
        { "BLUETOOTH", bluetooth, sizeof(bluetooth) },
        { "HUB", hub, sizeof(hub) }
    };

    size_t i;

    for (i = 0; i < sizeof(tests) / sizeof(tests[0]); ++i) {
        printf("TEST=%s BYTES=", tests[i].name);

        for (size_t j = 0; j < tests[i].length; ++j)
            printf("%02X%s",
                   tests[i].bytes[j],
                   j + 1 == tests[i].length ? "" : " ");

        printf("\nRESULT ");
        inspect_usb_interface(tests[i].bytes, tests[i].length);
    }

    return 0;
}
