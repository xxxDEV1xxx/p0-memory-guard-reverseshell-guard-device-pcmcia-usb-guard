cmd_/data/pcmciaguard/modules.order := {   echo /data/pcmciaguard/pcmciaguard.ko;   echo /data/pcmciaguard/pcmciaguard_recog.ko; :; } > /data/pcmciaguard/modules.order
