#!/bin/sh
set -u
OUT=audit/system-critical/runtime-tree-v2
mkdir -p "$OUT"
: > "$OUT/objects.tsv"
: > "$OUT/links.tsv"
: > "$OUT/attributes.tsv"

cat audit/system-critical/runtime-ancestry.txt |
grep '^/sys/devices/' | grep -v '^===' | sort -u > "$OUT/roots.txt"

while IFS= read -r root; do
    [ -d "$root" ] || continue
    find "$root" -type d ! -type l -print
done < "$OUT/roots.txt" | sort -u > "$OUT/objects-paths.txt"

while IFS= read -r obj; do
    printf '%s\n' "$obj" >> "$OUT/objects.tsv"
    find "$obj" -maxdepth 1 -type l -print 2>/dev/null |
    while IFS= read -r link; do
        printf '%s\t%s\t%s\n' "$obj" "$(basename "$link")" "$(readlink "$link")" >> "$OUT/links.tsv"
    done
done < "$OUT/objects-paths.txt"

while IFS= read -r obj; do
    find "$obj" -type f -print 2>/dev/null |
    while IFS= read -r attr; do
        value=$(cat "$attr" 2>/dev/null || true)
        printf '%s\t%s\t%s\n' "$obj" "${attr#"$obj"/}" "$value" >> "$OUT/attributes.tsv"
    done
done < "$OUT/objects-paths.txt"

echo "OBJECTS     $(wc -l < "$OUT/objects.tsv")"
echo "LINKS       $(wc -l < "$OUT/links.tsv")"
echo "ATTRIBUTES  $(wc -l < "$OUT/attributes.tsv")"
