#!/bin/sh
set -u

OUT="audit/system-critical"

mkdir -p "$OUT"

: > "$OUT/proc-roots.txt"
: > "$OUT/proc-fds.txt"
: > "$OUT/proc-maps.txt"

for p in /proc/[0-9]*; do
    pid=${p##*/}

    [ -r "$p/comm" ] || continue

    comm=$(cat "$p/comm" 2>/dev/null || true)

    printf '%s\t%s\t' "$pid" "$comm" \
        >> "$OUT/proc-roots.txt"

    printf 'exe=%s\t' \
        "$(readlink "$p/exe" 2>/dev/null || true)" \
        >> "$OUT/proc-roots.txt"

    printf 'cwd=%s\t' \
        "$(readlink "$p/cwd" 2>/dev/null || true)" \
        >> "$OUT/proc-roots.txt"

    printf 'root=%s\n' \
        "$(readlink "$p/root" 2>/dev/null || true)" \
        >> "$OUT/proc-roots.txt"

    for fd in "$p"/fd/*; do
        [ -e "$fd" ] || continue

        fdnum=${fd##*/}

        target=$(readlink "$fd" 2>/dev/null || true)
        [ -n "$target" ] || continue

        printf '%s\t%s\t%s\t%s\n' \
            "$pid" "$comm" "$fdnum" "$target" \
            >> "$OUT/proc-fds.txt"
    done

    if [ -r "$p/maps" ]; then
        awk -v pid="$pid" -v comm="$comm" '
            NF >= 6 {
                print pid "\t" comm "\t" $1 "\t" $6
            }
        ' "$p/maps" >> "$OUT/proc-maps.txt"
    fi
done

sort -u "$OUT/proc-roots.txt" -o "$OUT/proc-roots.txt"
sort -u "$OUT/proc-fds.txt"   -o "$OUT/proc-fds.txt"
sort -u "$OUT/proc-maps.txt"  -o "$OUT/proc-maps.txt"

echo "=== COUNTS ==="
wc -l \
    "$OUT/proc-roots.txt" \
    "$OUT/proc-fds.txt" \
    "$OUT/proc-maps.txt"

echo '=== DEVICE-NODE REFERENCES ==='
grep -E '/dev/|major:|socket:|anon_inode:' \
    "$OUT/proc-fds.txt" |
    sort -u |
    head -200

echo '=== EXECUTABLE ROOTS ==='
cut -f3 "$OUT/proc-roots.txt" |
    sort -u

echo '=== CWD ROOTS ==='
sed -n 's/.*cwd=\([^]*\).*/\1/p' \
    "$OUT/proc-roots.txt" |
    sort -u

echo '=== PROCESS ROOTS ==='
sed -n 's/.*root=\([^]*\)$/\1/p' \
    "$OUT/proc-roots.txt" |
    sort -u

echo '=== MAPPED FILE ROOTS ==='
cut -f4 "$OUT/proc-maps.txt" |
    sort -u
