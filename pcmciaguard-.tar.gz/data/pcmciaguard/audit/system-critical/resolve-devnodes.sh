#!/bin/sh
set -u

OUT="audit/system-critical"
mkdir -p "$OUT"

: > "$OUT/devnode-roots.txt"

for f in "$OUT/proc-fds.txt"; do
    awk -F '\t' '
        $4 ~ /^\/dev\// {
            print $4
        }
    ' "$f"
done |
sort -u |
while read -r dev; do
    [ -e "$dev" ] || continue

    real=$(readlink -f "$dev" 2>/dev/null || true)
    stat=$(stat -Lc '%t:%T' "$dev" 2>/dev/null || true)

    printf '%s\t%s\t%s\n' \
        "$dev" "$real" "$stat" \
        >> "$OUT/devnode-roots.txt"
done

sort -u "$OUT/devnode-roots.txt" \
    -o "$OUT/devnode-roots.txt"

echo '=== DEVNODE ROOTS ==='
cat "$OUT/devnode-roots.txt"

echo '=== COUNT ==='
wc -l "$OUT/devnode-roots.txt"
