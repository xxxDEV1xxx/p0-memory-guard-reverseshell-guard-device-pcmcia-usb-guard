#!/bin/sh
set -u

OUT=audit/system-critical/runtime-tree-v2
OBJ="$OUT/objects.tsv"
JSON="$OUT/attributes.jsonl"

: > "$JSON"

python3 - "$OBJ" "$JSON" <<'PY'
import hashlib
import json
import os
import sys

objfile = sys.argv[1]
outfile = sys.argv[2]

with open(objfile, "r", encoding="utf-8", errors="surrogateescape") as f:
    objects = sorted(set(x.rstrip("\n") for x in f if x.rstrip("\n")))

count = 0

with open(outfile, "w", encoding="utf-8") as out:
    for obj in objects:
        if not os.path.isdir(obj):
            continue

        for dirpath, dirnames, filenames in os.walk(
            obj, topdown=True, followlinks=False
        ):
            dirnames[:] = [
                d for d in dirnames
                if not os.path.islink(os.path.join(dirpath, d))
            ]

            for name in sorted(filenames):
                path = os.path.join(dirpath, name)

                if os.path.islink(path) or not os.path.isfile(path):
                    continue

                try:
                    with open(path, "rb") as f:
                        raw = f.read()
                except (OSError, PermissionError):
                    continue

                value = raw.decode("utf-8", errors="replace")

                rec = {
                    "object": obj,
                    "path": path,
                    "attribute": os.path.relpath(path, obj),
                    "name": name,
                    "bytes": len(raw),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                    "value": value,
                }

                out.write(json.dumps(
                    rec,
                    ensure_ascii=False,
                    separators=(",", ":")
                ) + "\n")

                count += 1

print("ATTRIBUTE_RECORDS", count)
PY

echo '=== JSONL RECORDS ==='
wc -l "$JSON"

echo '=== SAMPLE RECORDS ==='
head -3 "$JSON"
