#!/bin/sh
set -u
OUT=audit/system-critical/runtime-tree
mkdir -p "$OUT"
: > "$OUT/objects.tsv"
: > "$OUT/attributes.tsv"

for root in \
 /sys/devices/platform/i8042/serio0/input/input0/event0 \
 /sys/devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input5/event1 \
 /sys/devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0D:00/input/input6/event2 \
 /sys/devices/LNXSYSTM:00/LNXPWRBN:00/input/input7/event3 \
 /sys/devices/virtual/input/input15/event7 \
 /sys/devices/virtual/misc/autofs \
 /sys/devices/virtual/misc/rfkill \
 /sys/devices/virtual/tty/tty1 \
 /sys/devices/virtual/tty/tty6; do
    find "$root" -print 2>/dev/null
done | sort -u > "$OUT/object-paths.txt"

while IFS= read -r obj; do
    [ -d "$obj" ] || continue
    real=$(readlink -f "$obj")
    driver=
    [ -L "$obj/driver" ] && driver=$(readlink -f "$obj/driver")
    printf '%s\t%s\t%s\n' "$obj" "$real" "$driver" >> "$OUT/objects.tsv"

    find "$obj" -maxdepth 1 -type f -print 2>/dev/null |
    sort | while IFS= read -r attr; do
        name=$(basename "$attr")
        value=$(cat "$attr" 2>/dev/null || true)
        printf '%s\t%s\t%s\n' "$obj" "$name" "$value" >> "$OUT/attributes.tsv"
    done
done < "$OUT/object-paths.txt"

echo "=== OBJECTS ==="
wc -l "$OUT/objects.tsv"
echo "=== ATTRIBUTES ==="
wc -l "$OUT/attributes.tsv"
echo "=== OBJECT PATHS ==="
wc -l "$OUT/object-paths.txt"
