#!/usr/bin/env python3
import json
import os
from collections import deque

BASE = "audit/system-critical/runtime-tree-v2"
OUT = "audit/system-critical/runtime-closure"

os.makedirs(OUT, exist_ok=True)

objects_out = os.path.join(OUT, "objects.tsv")
links_out = os.path.join(OUT, "links.jsonl")
attrs_out = os.path.join(OUT, "attributes.jsonl")

initial = set()

with open(os.path.join(BASE, "objects.tsv"), encoding="utf-8",
          errors="surrogateescape") as f:
    for line in f:
        p = line.rstrip("\n")
        if p:
            initial.add(os.path.realpath(p))

with open(os.path.join(BASE, "links.resolved.jsonl"), encoding="utf-8") as f:
    for line in f:
        r = json.loads(line)
        p = r["resolved_target"]
        if p.startswith("/sys/") and os.path.isdir(p):
            initial.add(os.path.realpath(p))

queue = deque(sorted(initial))
seen = set()
links = {}
attributes = {}

while queue:
    obj = queue.popleft()

    if obj in seen:
        continue
    seen.add(obj)

    if not obj.startswith("/sys/"):
        continue
    if not os.path.isdir(obj):
        continue

    try:
        entries = list(os.scandir(obj))
    except OSError:
        continue

    for ent in entries:
        path = ent.path

        try:
            if ent.is_symlink():
                literal = os.readlink(path)
                resolved = os.path.realpath(path)

                key = (obj, ent.name, literal, resolved)
                links[key] = {
                    "source": obj,
                    "name": ent.name,
                    "literal_target": literal,
                    "resolved_target": resolved,
                    "target_exists": os.path.exists(path),
                }

                if resolved.startswith("/sys/") and os.path.isdir(resolved):
                    queue.append(resolved)

            elif ent.is_dir(follow_symlinks=False):
                queue.append(os.path.realpath(path))

            elif ent.is_file(follow_symlinks=False):
                try:
                    with open(path, "rb") as rf:
                        raw = rf.read()
                except OSError:
                    continue

                import hashlib

                key = (obj, ent.name, path)
                attributes[key] = {
                    "object": obj,
                    "path": path,
                    "attribute": os.path.relpath(path, obj),
                    "name": ent.name,
                    "bytes": len(raw),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                    "value": raw.decode("utf-8", errors="replace"),
                }

        except OSError:
            continue

with open(objects_out, "w", encoding="utf-8") as f:
    for p in sorted(seen):
        f.write(p + "\n")

with open(links_out, "w", encoding="utf-8") as f:
    for key in sorted(links):
        f.write(json.dumps(
            links[key],
            ensure_ascii=False,
            separators=(",", ":")
        ) + "\n")

with open(attrs_out, "w", encoding="utf-8") as f:
    for key in sorted(attributes):
        f.write(json.dumps(
            attributes[key],
            ensure_ascii=False,
            separators=(",", ":")
        ) + "\n")

print("INITIAL_OBJECTS", len(initial))
print("CLOSURE_OBJECTS", len(seen))
print("CLOSURE_LINKS", len(links))
print("CLOSURE_ATTRIBUTES", len(attributes))
