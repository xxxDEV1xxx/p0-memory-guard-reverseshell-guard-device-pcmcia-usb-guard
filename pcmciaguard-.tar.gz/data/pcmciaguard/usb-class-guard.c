#define _GNU_SOURCE

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "device-class-policy.h"
#include "runtime-policy.h"

#define SYSFS_USB "/sys/bus/usb/devices"
#define LOG_TAG   "pcmciaguard-usb"
#define ENFORCE 1

static int read_attr(const char *path, char *buf, size_t len)
{
    int fd;
    ssize_t n;

    fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0)
        return -1;

    n = read(fd, buf, len - 1);
    close(fd);

    if (n < 0)
        return -1;

    buf[n] = '\0';

    while (n > 0 &&
           (buf[n - 1] == '\n' ||
            buf[n - 1] == '\r' ||
            buf[n - 1] == ' '  ||
            buf[n - 1] == '\t')) {
        buf[--n] = '\0';
    }

    return 0;
}

static int read_hex_attr(const char *dir, const char *name, unsigned int *value)
{
    char path[PATH_MAX];
    char buf[64];
    char *end;
    unsigned long v;

    if (snprintf(path, sizeof(path), "%s/%s", dir, name) >= (int)sizeof(path))
        return -1;

    if (read_attr(path, buf, sizeof(buf)) < 0)
        return -1;

    errno = 0;
    v = strtoul(buf, &end, 16);

    if (errno != 0 || end == buf || *end != '\0' || v > 0xff)
        return -1;

    *value = (unsigned int)v;
    return 0;
}

static int write_authorized(const char *dir, int value)
{
    char path[PATH_MAX];
    char buf[2];
    int fd;
    ssize_t n;

    if (snprintf(path, sizeof(path), "%s/authorized", dir) >= (int)sizeof(path))
        return -1;

    fd = open(path, O_WRONLY | O_CLOEXEC);
    if (fd < 0)
        return -1;

    buf[0] = value ? '1' : '0';
    buf[1] = '\n';

    n = write(fd, buf, sizeof(buf));
    close(fd);

    return n == (ssize_t)sizeof(buf) ? 0 : -1;
}

static const char *class_name(unsigned int cls)
{
    switch (cls) {
    case 0x07:
        return "printer";

    case 0xE0:
        return "bluetooth/wireless-controller";

    case 0xFF:
        return "vendor-specific";

    default:
        return "other";
    }
}

static void inspect_interface(const char *name)
{
    char dir[PATH_MAX];
    char path[PATH_MAX];
    char authorized[32];
    unsigned int cls;
    unsigned int subcls;
    unsigned int proto;

    /*
     * USB device directories such as:
     *
     *   1-1
     *   1-1.2
     *
     * are not interfaces.
     *
     * USB interface directories contain ':'.
     *
     * Examples:
     *
     *   1-1:1.0
     *   1-1.2:1.1
     */
    if (!strchr(name, ':'))
        return;

    if (snprintf(dir, sizeof(dir), "%s/%s", SYSFS_USB, name)
            >= (int)sizeof(dir))
        return;

    if (read_hex_attr(dir, "bInterfaceClass", &cls) < 0)
        return;

    if (read_hex_attr(dir, "bInterfaceSubClass", &subcls) < 0)
        subcls = 0xff;

    if (read_hex_attr(dir, "bInterfaceProtocol", &proto) < 0)
        proto = 0xff;

    struct device_class_identity identity = {
        .bus = DEVICE_BUS_USB,
        .class_code = (uint8_t)cls,
        .subclass = (uint8_t)subcls,
        .protocol = (uint8_t)proto
    };
    const char *policy_name = NULL;
    enum device_policy policy;

    policy = device_class_policy(&identity, &policy_name);

    /*
     * Runtime policy supplements the compiled policy.
     * A runtime deny takes precedence over an undecided/allowed class.
     */
    if (runtime_class_denied((uint8_t)cls)) {
        policy = DEVICE_POLICY_DENY;
        policy_name = class_name(cls);
    }

    if (policy != DEVICE_POLICY_DENY)
        return;

    if (snprintf(path, sizeof(path), "%s/authorized", dir)
            >= (int)sizeof(path))
        return;

    if (read_attr(path, authorized, sizeof(authorized)) < 0) {
        fprintf(stderr,
                "%s: interface=%s class=0x%02x "
                "subclass=0x%02x protocol=0x%02x "
                "authorized attribute unavailable\n",
                LOG_TAG, name, cls, subcls, proto);
        return;
    }

    if (strcmp(authorized, "0") == 0) {
        printf("%s: ALREADY_DENIED "
               "interface=%s class=0x%02x subclass=0x%02x "
               "protocol=0x%02x type=%s\n",
               LOG_TAG, name, cls, subcls, proto, class_name(cls));
        return;
    }

    if (ENFORCE && write_authorized(dir, 0) < 0) {
        fprintf(stderr,
                "%s: DENY_FAILED "
                "interface=%s class=0x%02x subclass=0x%02x "
                "protocol=0x%02x type=%s errno=%d (%s)\n",
                LOG_TAG, name, cls, subcls, proto,
                class_name(cls), errno, strerror(errno));
        return;
    }

    printf("%s: DENIED "
           "interface=%s class=0x%02x subclass=0x%02x "
           "protocol=0x%02x type=%s\n",
           LOG_TAG, name, cls, subcls, proto, class_name(cls));
}

int main(void)
{
    DIR *d;
    struct dirent *de;

    d = opendir(SYSFS_USB);
    if (!d) {
        fprintf(stderr,
                "%s: cannot open %s: %s\n",
                LOG_TAG, SYSFS_USB, strerror(errno));
        return EXIT_FAILURE;
    }

    while ((de = readdir(d)) != NULL) {
        if (de->d_name[0] == '.')
            continue;

        inspect_interface(de->d_name);
    }

    closedir(d);
    return EXIT_SUCCESS;
}
