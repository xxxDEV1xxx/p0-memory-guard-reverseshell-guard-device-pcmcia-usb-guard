#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x92997ed8, "_printk" },
	{ 0xacfde3ae, "register_kretprobe" },
	{ 0xfcca5424, "register_kprobe" },
	{ 0x50adaa18, "unregister_kretprobe" },
	{ 0x8f1daf79, "pci_get_domain_bus_and_slot" },
	{ 0xddbeeecc, "pci_lock_rescan_remove" },
	{ 0x8ada5a3b, "pci_rescan_bus" },
	{ 0x5790e7a0, "pci_unlock_rescan_remove" },
	{ 0xedc2214d, "pci_dev_put" },
	{ 0x63026490, "unregister_kprobe" },
	{ 0xbce1a965, "module_layout" },
};

MODULE_INFO(depends, "");

