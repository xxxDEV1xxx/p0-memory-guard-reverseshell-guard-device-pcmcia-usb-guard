#ifndef PCMCIAGUARD_RECOG_POLICY_H
#define PCMCIAGUARD_RECOG_POLICY_H

#include <linux/types.h>

struct pcmciaguard_pci_identity {
	u16 vendor;
	u16 device;
};

/*
 * Return true when this PCI VID:DID must be denied
 * before pci_alloc_dev().
 */
static inline bool pcmciaguard_deny_identity(
	const struct pcmciaguard_pci_identity *id)
{
	/*
	 * Policy entries will be added here.
	 *
	 * Keep default behavior ALLOW until explicitly populated.
	 */
	return false;
}

#endif
