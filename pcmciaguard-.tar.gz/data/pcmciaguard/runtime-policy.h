#ifndef RUNTIME_POLICY_H
#define RUNTIME_POLICY_H

#include <stdio.h>
#include <stdint.h>

#define RUNTIME_POLICY_FILE "/data/pcmciaguard/runtime-deny"

static int runtime_class_denied(uint8_t class_code)
{
    FILE *f;
    unsigned int code;

    f = fopen(RUNTIME_POLICY_FILE, "r");
    if (!f)
        return 0;

    while (fscanf(f, "%x", &code) == 1) {
        if (code == class_code) {
            fclose(f);
            return 1;
        }
    }

    fclose(f);
    return 0;
}

#endif
