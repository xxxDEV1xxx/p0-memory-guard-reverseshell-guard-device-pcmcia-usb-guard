#!/usr/bin/env python3

import hashlib
import os
import time

ROOT = "/sys/devices"
OUT = "corpus/attributes.tsv"

os.makedirs("corpus", exist_ok=True)

HEADER = (
    "identity_id|subsystem|object_path|attribute_path|"
    "attribute_name|value|first_seen|last_seen\n"
)

def subsystem_for(path):
    parts = os.path.realpath(path).split("/")
    try:
        i = parts.index("devices")
        return parts[i + 1] if i + 1 < len(parts) else ""
    except ValueError:
        return ""

def canonical(subsystem, obj, attr, name, value):
    return (
        f"attribute_name={name}\n"
        f"attribute_path={attr}\n"
        f"object_path={obj}\n"
        f"subsystem={subsystem}\n"
        f"value={value}\n"
    )

def iid(text):
    return hashlib.sha256(text.encode()).hexdigest()

rows = {}
now = str(int(time.time()))

if os.path.exists(OUT):
    with open(OUT, "r", errors="replace") as f:
        next(f, None)
        for line in f:
            p = line.rstrip("\n").split("|", 7)
            if len(p) == 8:
                rows[p[0]] = p

for dirpath, dirnames, filenames in os.walk(ROOT, followlinks=False):
    for name in filenames:
        path = os.path.join(dirpath, name)

        try:
            if not os.path.isfile(path):
                continue

            with open(path, "rb") as f:
                raw = f.read()

            value = raw.decode("utf-8", errors="replace").rstrip("\n")
        except (OSError, UnicodeError):
            continue

        obj = dirpath
        attr = os.path.relpath(path, ROOT)
        subsystem = subsystem_for(path)

        canonical_text = canonical(
            subsystem,
            obj,
            attr,
            name,
            value,
        )

        identity = iid(canonical_text)

        old = rows.get(identity)

        if old:
            old[7] = now
        else:
            rows[identity] = [
                identity,
                subsystem,
                obj,
                attr,
                name,
                value.replace("|", "\\x7c"),
                now,
                now,
            ]

with open(OUT, "w") as f:
    f.write(HEADER)
    for identity in sorted(rows):
        f.write("|".join(rows[identity]) + "\n")

print(f"ATTRIBUTE_IDENTITIES={len(rows)}")
print(f"OUTPUT={OUT}")
