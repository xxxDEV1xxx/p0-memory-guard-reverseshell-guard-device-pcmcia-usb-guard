#!/usr/bin/env python3
import hashlib
import os
import sys
import time

IDENTITY_FIELDS = (
    "subsystem", "modalias", "vendor", "device",
    "subsystem_vendor", "subsystem_device", "class",
    "revision", "manufacturer", "product", "serial",
)

def read(path):
    try:
        with open(path, "r", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""

def norm(v):
    return v.strip().lower()

def pci(path):
    fields = {"subsystem": "pci"}
    for name in IDENTITY_FIELDS[1:]:
        v = read(os.path.join(path, name))
        if v:
            fields[name] = norm(v)
    return fields

def usb(path):
    fields = {"subsystem": "usb"}
    mapping = {
        "idVendor": "vendor",
        "idProduct": "device",
        "bDeviceClass": "class",
        "bDeviceSubClass": "subclass",
        "bDeviceProtocol": "protocol",
        "bcdDevice": "revision",
        "manufacturer": "manufacturer",
        "product": "product",
        "serial": "serial",
        "modalias": "modalias",
    }
    for source, target in mapping.items():
        v = read(os.path.join(path, source))
        if v:
            fields[target] = norm(v)
    return fields

def validate(fields):
    if fields.get("subsystem") == "pci":
        return all(fields.get(x) for x in ("vendor", "device", "class", "modalias"))
    if fields.get("subsystem") == "usb":
        return all(fields.get(x) for x in ("vendor", "device", "class"))
    return False

def canonical(fields):
    return "\n".join(
        f"{k}={fields[k]}"
        for k in sorted(fields)
        if fields[k]
    ) + "\n"

def identity_id(fields):
    return hashlib.sha256(
        canonical(fields).encode("utf-8")
    ).hexdigest()

def parent_identity(path):
    cur = os.path.dirname(os.path.realpath(path))

    while cur != "/":
        if (
            os.path.isfile(os.path.join(cur, "vendor")) and
            os.path.isfile(os.path.join(cur, "device")) and
            os.path.isfile(os.path.join(cur, "class")) and
            os.path.isfile(os.path.join(cur, "modalias"))
        ):
            fields = pci(cur)

            if validate(fields):
                iid = identity_id(fields)

                try:
                    with open("corpus/identities.tsv") as f:
                        next(f)
                        for line in f:
                            parts = line.rstrip("\n").split("|")
                            if parts and parts[0] == iid:
                                return iid
                except OSError:
                    return ""

        cur = os.path.dirname(cur)

    return ""

def instance(path, subsystem):
    real = os.path.realpath(path)
    driver = read(os.path.join(path, "driver"))
    driver = os.path.basename(os.path.realpath(os.path.join(path, "driver")))         if driver or os.path.islink(os.path.join(path, "driver")) else ""

    devnode = ""
    if subsystem == "usb":
        busnum = read(os.path.join(path, "busnum"))
        devnum = read(os.path.join(path, "devnum"))
        if busnum and devnum:
            devnode = f"/dev/bus/usb/{int(busnum):03d}/{int(devnum):03d}"

    return real, driver, devnode

def record(path, subsystem):
    fields = pci(path) if subsystem == "pci" else usb(path)
    if not validate(fields):
        print("INSUFFICIENT_IDENTITY=1", file=sys.stderr)
        print("Refusing to generate identity_id.", file=sys.stderr)
        return 1

    iid = identity_id(fields)
    canonical_key = canonical(fields).rstrip("\n").replace("\n", "\\n")
    real, driver, devnode = instance(path, subsystem)
    parent = parent_identity(path)
    now = str(int(time.time()))

    identity_file = "corpus/identities.tsv"
    event_file = "corpus/events.tsv"

    values = [
        iid, subsystem, canonical_key,
        fields.get("modalias", ""),
        fields.get("vendor", ""),
        fields.get("device", ""),
        fields.get("subsystem_vendor", ""),
        fields.get("subsystem_device", ""),
        fields.get("class", ""),
        fields.get("revision", ""),
        fields.get("manufacturer", ""),
        fields.get("product", ""),
        fields.get("serial", ""),
        driver, real, os.path.realpath(path), devnode,
        parent, now, now,
    ]

    existing = False
    rows = []

    with open(identity_file) as f:
        lines = f.readlines()

    header = lines[0]
    for line in lines[1:]:
        parts = line.rstrip("\n").split("|")
        if parts and parts[0] == iid:
            existing = True
            if len(parts) >= 20:
                parts[19] = now
            line = "|".join(parts) + "\n"
        rows.append(line)

    if existing:
        with open(identity_file, "w") as f:
            f.write(header)
            f.writelines(rows)
        action = "SEEN"
    else:
        with open(identity_file, "a") as f:
            f.write("|".join(values) + "\n")
        action = "NEW"

    with open(event_file, "a") as f:
        f.write("|".join([
            now, iid, action, subsystem,
            os.path.realpath(path), real, driver
        ]) + "\n")

    print("IDENTITY_ID=" + iid)
    print("ACTION=" + action)
    print("RECORDED=1")
    print("SYSFS_PATH=" + os.path.realpath(path))
    print("PHYSICAL_PATH=" + real)
    print("DRIVER=" + driver)
    print("DEVNODE=" + devnode)

def verify(iid):
    with open("corpus/identities.tsv") as f:
        next(f)
        for line in f:
            parts = line.rstrip("\n").split("|")
            if parts and parts[0] == iid:
                stored = parts[2].replace("\\n", "\n") + "\n"
                calculated = hashlib.sha256(
                    stored.encode("utf-8")
                ).hexdigest()
                print("IDENTITY_ID=" + iid)
                print("CALCULATED=" + calculated)
                print("MATCH=" + ("1" if calculated == iid else "0"))
                return 0 if calculated == iid else 1

    print("IDENTITY_NOT_FOUND=1", file=sys.stderr)
    return 1

def show(path, subsystem):
    fields = pci(path) if subsystem == "pci" else usb(path)
    if not validate(fields):
        print("INSUFFICIENT_IDENTITY=1", file=sys.stderr)
        print("Refusing to generate identity_id.", file=sys.stderr)
        return 1
    key = canonical(fields)
    print("IDENTITY_ID=" + identity_id(fields))
    print("SUBSYSTEM=" + subsystem)
    print("=== CANONICAL IDENTITY ===")
    print(key, end="")
    print("=== SYSFS PATH ===")
    print(os.path.realpath(path))

def main():
    if len(sys.argv) == 3 and sys.argv[1] == "verify":
        return verify(sys.argv[2])

    if len(sys.argv) != 4 or sys.argv[1] not in ("show", "record"):
        print(f"usage: {sys.argv[0]} <show|record> <pci|usb> <sysfs-path>",
              file=sys.stderr)
        return 2

    action, subsystem, path = sys.argv[1], sys.argv[2], sys.argv[3]

    if not os.path.isdir(path):
        print(f"not a directory: {path}", file=sys.stderr)
        return 1

    if subsystem not in ("pci", "usb"):
        print("unsupported subsystem", file=sys.stderr)
        return 2

    if action == "record":
        return record(path, subsystem)

    return show(path, subsystem)

if __name__ == "__main__":
    raise SystemExit(main())
