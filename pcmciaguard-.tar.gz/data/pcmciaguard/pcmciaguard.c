#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/notifier.h>

static const char *allow_list[] = {
"pcmcia_core",
"pcmcia",
    "pcmciaguard_recog",
    "slotprobe",
NULL
};

static bool module_allowed(const char *name)
{
int i;

for (i = 0; allow_list[i]; i++) {
if (!strcmp(name, allow_list[i]))
return true;
}

return false;
}

static int pcmciaguard_module_event(struct notifier_block *nb,
    unsigned long action,
    void *data)
{
struct module *mod = data;

if (!mod)
return NOTIFY_DONE;

switch (action) {
case MODULE_STATE_COMING:
pr_info("pcmciaguard: observed module=%s action=COMING\n",
mod->name);

if (module_allowed(mod->name)) {
pr_info("pcmciaguard: policy=ALLOW module=%s\n",
mod->name);
return NOTIFY_OK;
}

pr_info("pcmciaguard: policy=DENY module=%s\n",
mod->name);

return NOTIFY_BAD;

case MODULE_STATE_LIVE:
pr_info("pcmciaguard: observed module=%s action=LIVE\n",
mod->name);
break;

case MODULE_STATE_GOING:
pr_info("pcmciaguard: observed module=%s action=GOING\n",
mod->name);
break;
}

return NOTIFY_OK;
}

static struct notifier_block pcmciaguard_nb = {
.notifier_call = pcmciaguard_module_event,
};

static int __init pcmciaguard_init(void)
{
int ret;

ret = register_module_notifier(&pcmciaguard_nb);
if (ret)
return ret;

pr_info("pcmciaguard: active policy=FULL_DEFAULT_DENY\n");

return 0;
}

static void __exit pcmciaguard_exit(void)
{
unregister_module_notifier(&pcmciaguard_nb);
pr_info("pcmciaguard: unloaded\n");
}

module_init(pcmciaguard_init);
module_exit(pcmciaguard_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("DEV1");
MODULE_DESCRIPTION("PCMCIA module full default-deny enforcement guard");
