#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kprobes.h>
#include <linux/pci.h>

struct slotprobe_data {
        struct pci_bus *bus;
        unsigned int devfn;
};

static int slotprobe_entry(struct kretprobe_instance *ri,
                           struct pt_regs *regs)
{
        struct slotprobe_data *d = (void *)ri->data;

        d->bus = (struct pci_bus *)regs->di;
        d->devfn = (unsigned int)regs->si;

        return 0;
}

static int slotprobe_ret(struct kretprobe_instance *ri,
                         struct pt_regs *regs)
{
        struct slotprobe_data *d = (void *)ri->data;
        struct pci_dev *dev;

        dev = (struct pci_dev *)regs_return_value(regs);

        if (d->bus && d->bus->name &&
            !strncmp(d->bus->name, "PCI Bus 0000:01", 15)) {
                pr_info("slotprobe: bus=%s devfn=%02x return=%px%s\n",
                        d->bus->name,
                        d->devfn,
                        dev,
                        dev ? " EXISTING" : " NULL");
        }

        return 0;
}

static struct kretprobe slotprobe = {
        .kp.symbol_name = "pci_get_slot",
        .entry_handler = slotprobe_entry,
        .handler = slotprobe_ret,
        .data_size = sizeof(struct slotprobe_data),
        .maxactive = 64,
};

static int __init slotprobe_init(void)
{
        int ret = register_kretprobe(&slotprobe);

        if (ret)
                return ret;

        pr_info("slotprobe: ACTIVE\n");
        return 0;
}

static void __exit slotprobe_exit(void)
{
        unregister_kretprobe(&slotprobe);
        pr_info("slotprobe: REMOVED\n");
}

module_init(slotprobe_init);
module_exit(slotprobe_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Temporary pci_get_slot return probe");
