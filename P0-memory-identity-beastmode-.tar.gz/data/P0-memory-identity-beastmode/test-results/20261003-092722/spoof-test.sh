#!/bin/bash
exec -a cat /usr/bin/yes
