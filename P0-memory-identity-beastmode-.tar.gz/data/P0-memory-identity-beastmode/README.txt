# P0 Memory Identity Beastmode

## License
Copyright (c) 2026 Christopher T. Williams

## License

Permission is granted to use, copy, modify, and distribute this software
for research, testing, and security-analysis purposes, provided that the
copyright notice and this permission notice are retained.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL
NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE
USE OF THIS SOFTWARE.
Block a command
cd /data/P0-memory-identity-beastmode
./beastmode_loader.isolated block dd
systemctl restart p0-memory-identity-beastmode.service

Verify it is listed:

./beastmode_loader.isolated list
Allow / unblock a command
cd /data/P0-memory-identity-beastmode
./beastmode_loader.isolated unblock dd
systemctl restart p0-memory-identity-beastmode.service

Verify:

./beastmode_loader.isolated list
Test that the block works

With dd blocked:

(
  echo $BASHPID > /sys/fs/cgroup/system.slice/p0-memory-identity-beastmode.service/cgroup.procs
  exec dd if=/dev/zero of=/dev/null bs=1M count=1
)
echo "rc=$?"

Expected:

Killed
rc=137

Then confirm the module loaded the blocklist:

journalctl -u p0-memory-identity-beastmode.service -n 10 --no-pager

Look for:

blocklist_entries=1
P0 MEMORY IDENTITY BEASTMODE ATTACHED
BLOCKING MODE ENABLED

To prove the rule is actually removed, unblock dd, restart, and run the same test; dd should complete normally.
Use these. They test a process whose argv[0] claims to be one command while the actual executable is another.

Test 1 — yes claiming to be cat
(
  echo $BASHPID > /sys/fs/cgroup/system.slice/p0-memory-identity-beastmode.service/cgroup.procs
  exec -a cat /usr/bin/yes
)
echo "rc=$?"

Expected:

Killed
rc=137
Test 2 — sleep claiming to be cat
(
  echo $BASHPID > /sys/fs/cgroup/system.slice/p0-memory-identity-beastmode.service/cgroup.procs
  exec -a cat /usr/bin/sleep 60
)
echo "rc=$?"

Expected:

Killed
rc=137
Verify the enforcement decision
journalctl -u p0-memory-identity-beastmode.service -n 20 --no-pager | grep 'P0_IDENTITY_'

You want to see:

P0_IDENTITY_OBSERVE ... claimed=cat actual=/usr/bin/yes
P0_IDENTITY_DECISION ... decision=IDENTITY_MISMATCH

or:

P0_IDENTITY_OBSERVE ... claimed=cat actual=/usr/bin/sleep
P0_IDENTITY_DECISION ... decision=IDENTITY_MISMATCH
Control test — correctly claiming sleep
(
  echo $BASHPID > /sys/fs/cgroup/system.slice/p0-memory-identity-beastmode.service/cgroup.procs
  exec -a sleep /usr/bin/sleep 1
)
echo "rc=$?"

Expected: it completes normally with rc=0, assuming the corresponding memory identity matches.
---

# FAST LAUNCH

Run these commands from the module directory:

```bash
cd /data/P0-memory-identity-beastmode

systemctl enable p0-memory-identity-beastmode.service
systemctl start p0-memory-identity-beastmode.service

systemctl status p0-memory-identity-beastmode.service --no-pager
```

Expected state:

```text
active (running)
```

Verify the module is attached:

```bash
journalctl -u p0-memory-identity-beastmode.service -n 10 --no-pager
```

Expected startup messages include:

```text
target_cgroup=...
target_cgroup_path=/sys/fs/cgroup/system.slice/p0-memory-identity-beastmode.service
blocklist_entries=...
P0 MEMORY IDENTITY BEASTMODE ATTACHED
BLOCKING MODE ENABLED
```

The module is then running as a systemd service and automatically restarts on failure.

---

# 1. Overview

P0 Memory Identity Beastmode is a kernel/userspace process-identity enforcement module.

It combines:

1. eBPF exec monitoring.
2. Claimed process identity captured from `argv[0]`.
3. Actual executable identity resolved through `/proc/<pid>/exe`.
4. Live process-memory acquisition.
5. Memory-crystal comparison against the claimed identity.
6. Fail-closed identity enforcement.
7. A kernel-side executable blocklist.
8. A systemd-managed persistent module launcher.

The module is designed to detect and terminate processes whose claimed identity does not correspond to their observed executable and memory.

The blocklist provides an independent immediate execution-denial mechanism for explicitly prohibited commands.

---

# 2. Module Location

Persistent module files are stored under:

```text
/data/P0-memory-identity-beastmode/
```

The `/data` filesystem is the persistent storage location for this module.

The systemd service is:

```text
p0-memory-identity-beastmode.service
```

The installed unit is:

```text
/etc/systemd/system/p0-memory-identity-beastmode.service
```

The service executes:

```text
/data/P0-memory-identity-beastmode/beastmode_loader.isolated
```

The loader opens:

```text
/data/P0-memory-identity-beastmode/beastmode.bpf.test.o
```

---

# 3. Startup Sequence

The normal launch sequence is:

```text
systemd
  |
  v
p0-memory-identity-beastmode.service
  |
  v
beastmode_loader.isolated
  |
  +--> discover service cgroup
  |
  +--> load beastmode.bpf.test.o
  |
  +--> configure target_cgroup BPF map
  |
  +--> load executable blocklist
  |
  +--> attach sys_enter_execve
  |
  +--> attach sched_process_exec
  |
  +--> create event ring buffer
  |
  v
P0 MEMORY IDENTITY BEASTMODE ATTACHED
  |
  v
BLOCKING MODE ENABLED
```

The service is configured to restart automatically if the loader exits unexpectedly.

---

# 4. Start / Stop / Restart

Start:

```bash
systemctl start p0-memory-identity-beastmode.service
```

Stop:

```bash
systemctl stop p0-memory-identity-beastmode.service
```

Restart:

```bash
systemctl restart p0-memory-identity-beastmode.service
```

Enable at boot:

```bash
systemctl enable p0-memory-identity-beastmode.service
```

Disable automatic startup:

```bash
systemctl disable p0-memory-identity-beastmode.service
```

Check status:

```bash
systemctl status p0-memory-identity-beastmode.service --no-pager
```

Check whether it is enabled:

```bash
systemctl is-enabled p0-memory-identity-beastmode.service
```

Check whether it is running:

```bash
systemctl is-active p0-memory-identity-beastmode.service
```

---

# 5. Journal

View recent module output:

```bash
journalctl -u p0-memory-identity-beastmode.service -n 50 --no-pager
```

Follow the module live:

```bash
journalctl -u p0-memory-identity-beastmode.service -f
```

The journal is the primary runtime interface for module status and enforcement events.

---

# 6. Executable Blocklist

The module supports an executable blocklist.

The current policy file is:

```text
/etc/p0/beastmode/blocklist
```

List blocked commands:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated list
```

Block a command:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated block dd
```

Remove a command from the blocklist:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated unblock dd
```

Display blocklist status:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated status
```

After changing the policy, restart the module so the BPF blocklist map is repopulated:

```bash
systemctl restart p0-memory-identity-beastmode.service
```

Verify:

```bash
journalctl -u p0-memory-identity-beastmode.service -n 10 --no-pager
```

The startup output should report the number of loaded blocklist entries:

```text
blocklist_entries=1
```

---

# 7. Blocklist Enforcement

The blocklist is enforced in the eBPF `sys_enter_execve` path.

The executable filename is hashed using FNV-1a 64-bit and compared against entries loaded into the kernel BPF map.

The check uses the actual `execve()` filename rather than `argv[0]`.

Therefore, changing the displayed process name does not bypass the blocklist.

For example:

```bash
exec -a cat /usr/bin/dd
```

still identifies the executable as:

```text
dd
```

and is subject to the `dd` block rule.

A blocked executable receives:

```text
SIGKILL
```

---

# 8. Memory Identity Enforcement

For an observed execution:

```text
sys_enter_execve
        |
        v
capture claimed argv[0]
        |
        v
sched_process_exec
        |
        v
resolve /proc/<pid>/exe
        |
        v
capture readable process memory
        |
        v
select claimed memory crystal
        |
        v
compare live memory against reference
        |
        v
identity decision
```

The claimed identity is derived from the process's `argv[0]`.

The observed identity is derived from:

```text
/proc/<pid>/exe
```

and the live process memory.

The enforcement decision is fail-closed:

```text
compared != reference
```

is not accepted as a valid identity match.

A process whose claimed identity and observed identity do not agree can be terminated.

---

# 9. Basic Identity Test

A process can be placed into the module's target cgroup and executed with a deliberately false `argv[0]`.

Example:

```bash
(
    echo $BASHPID > /sys/fs/cgroup/system.slice/p0-memory-identity-beastmode.service/cgroup.procs
    exec -a cat /usr/bin/yes
)
```

Inspect the result:

```bash
journalctl -u p0-memory-identity-beastmode.service -n 20 --no-pager
```

A successful enforcement event contains information similar to:

```text
P0_IDENTITY_OBSERVE ... claimed=cat actual=/usr/bin/yes
P0_IDENTITY_DECISION ... decision=IDENTITY_MISMATCH
```

The process should be terminated when the identity mismatch is enforced.

---

# 10. Blocklist Test

If `dd` is blocked:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated block dd
systemctl restart p0-memory-identity-beastmode.service
```

Run:

```bash
(
    echo $BASHPID > /sys/fs/cgroup/system.slice/p0-memory-identity-beastmode.service/cgroup.procs
    exec dd if=/dev/zero of=/dev/null bs=1M count=1
)
```

Expected result:

```text
Killed
```

The shell return code should normally be:

```text
137
```

which corresponds to termination by `SIGKILL`.

---

# 11. Service Unit

The module uses the existing systemd service mechanism:

```ini
[Unit]
Description=P0 Memory Identity Beastmode
RequiresMountsFor=/data
After=data.mount local-fs.target
Before=multi-user.target

[Service]
Type=simple
ExecStart=/data/P0-memory-identity-beastmode/beastmode_loader.isolated
Restart=on-failure
RestartSec=2
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

The service does not require modification of `/etc/rc.local`, initramfs, or the root ISO.

---

# 12. Rebuild

When the BPF source is changed:

```bash
cd /data/P0-memory-identity-beastmode

/data/lib-ext/usr/bin/clang-14 -O2 -g -target bpf \
  -D__TARGET_ARCH_x86 \
  -I/usr/include/x86_64-linux-gnu \
  -I/data/lib-ext/usr/include \
  -c beastmode.bpf.test.c \
  -o beastmode.bpf.test.o
```

When the loader source is changed:

```bash
gcc -O2 -Wall -Wextra \
  -I/data/lib-ext/usr/include \
  beastmode_loader.test.c \
  -o beastmode_loader.isolated \
  -L/data/lib-ext/usr/lib/x86_64-linux-gnu \
  -Wl,-rpath,/data/lib-ext/usr/lib/x86_64-linux-gnu \
  -lbpf
```

Then restart:

```bash
systemctl restart p0-memory-identity-beastmode.service
```

Verify:

```bash
systemctl is-active p0-memory-identity-beastmode.service
journalctl -u p0-memory-identity-beastmode.service -n 20 --no-pager
```

---

# 13. Operational Rule

The production module should be controlled through systemd:

```bash
systemctl start p0-memory-identity-beastmode.service
systemctl stop p0-memory-identity-beastmode.service
systemctl restart p0-memory-identity-beastmode.service
systemctl status p0-memory-identity-beastmode.service
```

Do not manually launch multiple copies of `beastmode_loader.isolated`.

There should be one systemd-managed loader instance responsible for the active BPF programs and event ring buffer.

---

# 14. Quick Operator Reference

Start:

```bash
systemctl start p0-memory-identity-beastmode.service
```

Stop:

```bash
systemctl stop p0-memory-identity-beastmode.service
```

Restart:

```bash
systemctl restart p0-memory-identity-beastmode.service
```

Status:

```bash
systemctl status p0-memory-identity-beastmode.service --no-pager
```

Live journal:

```bash
journalctl -u p0-memory-identity-beastmode.service -f
```

Block:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated block <command>
systemctl restart p0-memory-identity-beastmode.service
```

Unblock:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated unblock <command>
systemctl restart p0-memory-identity-beastmode.service
```

List:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated list
```

Status:

```bash
/data/P0-memory-identity-beastmode/beastmode_loader.isolated status
```

Verify service:

```bash
systemctl is-enabled p0-memory-identity-beastmode.service
systemctl is-active p0-memory-identity-beastmode.service
```

