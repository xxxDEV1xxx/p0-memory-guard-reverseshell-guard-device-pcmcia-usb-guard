# P0 MEMORY IDENTITY BEASTMODE

Copyright (c) 2026 Christopher T. Williams

## License

Permission is granted to use, copy, modify, and distribute this software
for research, testing, and security-analysis purposes, provided that the
copyright notice and this permission notice are retained.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL
NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE
USE OF THIS SOFTWARE.

## What This Does

P0 Memory Identity BEASTMODE enforces process identity by comparing
observed process memory against a memory crystal associated with the
process's claimed identity.

The architecture is:

    sys_enter_execve
          |
          | capture argv[0]
          v
    claimed_exec BPF map
          |
    sched_process_exec
          |
          v
    BPF ring buffer
          |
          v
    userspace P0 observer
          |
          +-- resolve actual /proc/PID/exe
          |
          +-- stop/capture live process memory
          |
          +-- select crystal using CLAIMED identity
          |
          +-- compare observed memory against claimed crystal
          |
          +-- similarity >= threshold -> identity accepted
          |
          +-- similarity < threshold -> SIGKILL

This is deliberately different from ordinary executable-name or
argv[0] allow/deny logic.

The security decision is based on observed process memory rather than
declared process identity alone.

## Current Test Environment

Tested on:

    Debian Linux
    Kernel: 6.1.0-50-amd64
    bpftool: 7.1.0
    libbpf: 1.1
    clang: /data/lib-ext/usr/bin/clang-14
    Python: /usr/bin/python3

The current isolated test cgroup is:

    /sys/fs/cgroup/p0-beastmode-test

The production service is separate and must not be replaced during
development testing.

## Build the BPF Object

From this directory:

    /data/lib-ext/usr/bin/clang-14 \
        -O2 \
        -g \
        -target bpf \
        -D__TARGET_ARCH_x86 \
        -I/usr/include/x86_64-linux-gnu \
        -I/data/lib-ext/usr/include \
        -c beastmode.bpf.c \
        -o beastmode.bpf.o

## Build the Userspace Loader

    gcc -O2 -Wall -Wextra \
        -I/data/lib-ext/usr/include \
        beastmode_loader.c \
        -o beastmode_loader.p0test \
        -L/data/lib-ext/usr/lib/x86_64-linux-gnu \
        -Wl,-rpath,/data/lib-ext/usr/lib/x86_64-linux-gnu \
        -lbpf

The current P0 worker is launched using:

    /usr/bin/python3

Verify it before testing:

    /usr/bin/python3 \
        -m py_compile \
        /data/P0-memory-identity-beastmode/p0_identity_worker.py

## Start an Isolated Test Loader

Do not replace the production service while testing.

Start the test loader inside the isolated cgroup:

    (
        echo $BASHPID > /sys/fs/cgroup/p0-beastmode-test/cgroup.procs
        exec ./beastmode_loader.p0test
    )

The loader should report the target cgroup and successful BPF
attachment.

## Adversarial Identity Test

The following creates a process whose actual executable is /usr/bin/yes
while its claimed argv[0] is "cat":

    (
        echo $BASHPID > /sys/fs/cgroup/p0-beastmode-test/cgroup.procs
        exec -a cat /usr/bin/yes
    ) >/dev/null &

    PID=$!
    echo "TEST_PID=$PID"

The expected observation is equivalent to:

    comm=yes claimed=cat

followed by:

    P0_IDENTITY_OBSERVE
    claimed=cat
    actual=/usr/bin/yes

The P0 observer then compares the live /usr/bin/yes memory against the
crystal selected for the claimed identity "cat".

A sufficiently low similarity produces:

    decision=IDENTITY_MISMATCH
    reason=IDENTITY_MISMATCH

and the process is terminated with SIGKILL.

The working isolated test demonstrated:

    matched=140145
    compared=409600
    reference=409600
    similarity=34.215088%

and the target subsequently reported:

    TARGET_KILLED=1

## Identity Model

The important distinction is:

    CLAIMED IDENTITY
          |
          +---- argv[0]

    OBSERVED IDENTITY
          |
          +---- /proc/PID/exe
          +---- live process memory

P0 does not accept the claimed identity merely because argv[0] says
the expected name.

The claimed name selects the reference crystal. The running process's
observed memory is what is compared against that reference.

## Crystal and Comparison Infrastructure

The P0 observer uses the existing memory-crystal infrastructure under:

    /data/P0_MEMORY_IDENTITY_BEASTMODE_20260918_092535

and the associated memory-watchdog/reference data.

The current comparison threshold is inherited from the P0 memory
identity implementation:

    EXPECTED_MATCH = 99.0

The current comparison implementation compares the available live
candidate bytes against the reference crystal. "100% compared" means
the complete reference length was compared; it does not by itself
prove that every byte of every live process mapping was successfully
captured.

## Current Event Flow

The BPF layer records:

    PID
    UID
    target cgroup
    comm
    claimed argv[0]
    match
    reason

The userspace observer then performs the memory-identity operation.

The observer itself currently enters the monitored cgroup and generates
a BPF exec event with an empty claimed identity. The empty-claim guard
prevents recursive P0 worker creation. Explicit observer exclusion is
a subsequent hardening task.

## Operational Modes

The existing userspace CLI supports the ordinary command-policy layer:

    ./beastmode_loader.p0test help
    ./beastmode_loader.p0test status
    ./beastmode_loader.p0test list
    ./beastmode_loader.p0test block <command>
    ./beastmode_loader.p0test unblock <command>

The ordinary blocklist policy and P0 memory-identity enforcement are
separate concepts:

    BLOCKLIST
        ordinary command policy

    IDENTITY_MISMATCH
        observed-memory identity failure

## Important Development Rule

Do not overwrite the known-good production service while modifying or
testing the P0 observer.

Test changes in:

    /sys/fs/cgroup/p0-beastmode-test

and use:

    beastmode_loader.p0test

until the change has been independently validated.

