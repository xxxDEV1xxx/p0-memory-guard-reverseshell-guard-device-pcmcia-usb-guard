License

Copyright (c) 2026 Christopher T. Williams

Permission is granted to use, copy, modify, and distribute this software for research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

P0 RX FIREWALL / RECREATION BUNDLE
===================================

Purpose
-------
Live kernel RX firewall enforcement for PlutoSDR.

This is separate from the P0 scanner. The firewall uses the Linux
netdev_rx_handler mechanism directly and does not depend on iptables,
Netfilter, tc, XDP, AF_PACKET, nc, or a userspace firewall daemon.

Target
------
PlutoSDR
ARMv7 hard-float
Linux 5.15.0-20952-ge14e351533f9-dirty
Build #10
Tue Jun 24 2025

Interface
---------
usb0

Kernel primitive
----------------
netdev_rx_handler_register()

Observed RX layout
------------------
On the tested Pluto usb0 RX path, skb->data starts at the IPv4
network header rather than an Ethernet header.

Firewall rule
-------------
Consume IPv4 ICMP packets:

    skb->protocol == htons(ETH_P_IP)
    IPv4 version == 4
    skb->data[9] == IPPROTO_ICMP

Matching packets return:

    RX_HANDLER_CONSUMED

All other packets return:

    RX_HANDLER_PASS

This was verified by blocking ping while preserving SSH management.

Files
-----
p0_rxhandler.ko       Known-good compiled kernel module.
p0_rxhandler.c        Source.
Makefile              Kernel module build file.
kernel.config         Running Pluto kernel configuration.
uname.txt              Running kernel identity.
proc-version.txt      Exact kernel/compiler build identity.
cmdline.txt            Kernel boot command line.
README.txt             This document.
SHA256SUMS             Integrity hashes.

DEPLOYMENT
==========

1. Confirm the target Pluto is running the matching kernel:

    uname -a
    cat /proc/version

2. Copy the module to the Pluto:

    scp p0_rxhandler.ko root@PLUTO_IP:/tmp/p0_rxhandler.ko

3. Verify SHA256SUMS.

4. Load:

    insmod /tmp/p0_rxhandler.ko

5. Inspect:

    dmesg | tail -30

6. Test that ICMP is consumed:

    ping -c 1 -W 1 PLUTO_IP

7. Verify management TCP remains available:

    ssh -o ConnectTimeout=3 root@PLUTO_IP 'echo SSH_PASS'

8. Remove:

    rmmod p0_rxhandler

IMPORTANT SAFETY NOTE
---------------------
Do not broaden the consume rule without testing.

A previous test that consumed all IPv4 traffic immediately interrupted
SSH management. The current rule is intentionally narrow: IPv4 ICMP only.

If a test rule locks out USB management, replug/reboot the Pluto to
restore the non-loaded state. The module is not configured for automatic
persistent loading.

BUILD RECREATION
================

The original module was built against the exact Pluto Linux source tree:

    Linux commit:
    e14e351533f934047ba0473e836e561682ec67fe

Firmware lineage:

    plutosdr-fw v0.38
    firmware source HEAD:
    0359a0b9a474567ab658619f3edf53ac65594f5a

Original build environment used the Pluto ARM hard-float toolchain:

    /data/armhf-toolchain/usr/bin/arm-linux-gnueabihf-

Required build command:

    LD_LIBRARY_PATH=/data/armhf-toolchain/usr/lib/x86_64-linux-gnu \
    make ARCH=arm \
    CROSS_COMPILE=/data/armhf-toolchain/usr/bin/arm-linux-gnueabihf- \
    EXTRA_CFLAGS="-march=armv7-a" \
    -C /data/pluto-linux \
    M=/data/pluto-linux/p0_rxhandler \
    modules

The exact kernel source and build environment are maintained separately
on FLEX. kernel.config is included here to identify the required target.

MODVERSIONS NOTE
----------------
The target kernel has CONFIG_MODVERSIONS=y. The original build did not
have the exact Module.symvers available, so modpost reported unresolved
symbol-version warnings. The resulting .ko loaded successfully on the
matching Pluto kernel and enforcement was verified.

SECURITY / DESIGN BOUNDARY
==========================
This module operates at the kernel RX-handler boundary.

It is not an AF_PACKET firewall. AF_PACKET observation alone cannot
suppress packets from the normal kernel network stack.

The P0 scanner is a separate component and should be compiled/deployed
as a separate module.
