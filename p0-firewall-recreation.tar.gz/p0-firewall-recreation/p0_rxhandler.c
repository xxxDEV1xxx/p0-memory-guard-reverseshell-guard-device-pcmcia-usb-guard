/*
 * License
 *
 * Copyright (c) 2026 Christopher T. Williams
 *
 * Permission is granted to use, copy, modify, and distribute this software
 * for research, testing, and security-analysis purposes, provided that the
 * copyright notice and this permission notice are retained.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL
 * NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE
 * USE OF THIS SOFTWARE.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <linux/rtnetlink.h>

static unsigned long p0_packets;

static rx_handler_result_t p0_rx_handler(struct sk_buff **pskb)
{
    struct sk_buff *skb = *pskb;

    if (!skb)
        return RX_HANDLER_PASS;

    p0_packets++;

    if (p0_packets <= 20) {
        pr_info("p0_rxhandler: packets=%lu len=%u dev=%s protocol=0x%04x\n",
                p0_packets,
                skb->len,
                skb->dev ? skb->dev->name : "?",
                ntohs(skb->protocol));

        if (skb->len >= 40)
            pr_info("p0_rxhandler: bytes=%02x %02x %02x %02x %02x %02x %02x %02x "
                    "%02x %02x %02x %02x %02x %02x %02x %02x "
                    "%02x %02x %02x %02x %02x %02x %02x %02x "
                    "%02x %02x %02x %02x %02x %02x %02x %02x "
                    "%02x %02x %02x %02x %02x %02x %02x %02x\n",
                    skb->data[0],  skb->data[1],
                    skb->data[2],  skb->data[3],
                    skb->data[4],  skb->data[5],
                    skb->data[6],  skb->data[7],
                    skb->data[8],  skb->data[9],
                    skb->data[10], skb->data[11],
                    skb->data[12], skb->data[13],
                    skb->data[14], skb->data[15],
                    skb->data[16], skb->data[17],
                    skb->data[18], skb->data[19],
                    skb->data[20], skb->data[21],
                    skb->data[22], skb->data[23],
                    skb->data[24], skb->data[25],
                    skb->data[26], skb->data[27],
                    skb->data[28], skb->data[29],
                    skb->data[30], skb->data[31],
                    skb->data[32], skb->data[33],
                    skb->data[34], skb->data[35],
                    skb->data[36], skb->data[37],
                    skb->data[38], skb->data[39]);
    }

    /*
     * P0 IPv4 signature:
     *   skb->protocol = IPv4
     *   skb->data starts at the IPv4 network header
     *   IPv4 version nibble = 4
     */
    if (skb->len >= 10 &&
        skb->protocol == htons(ETH_P_IP) &&
        (skb->data[0] & 0xf0) == 0x40 &&
        skb->data[9] == IPPROTO_ICMP) {
        pr_info("p0_rxhandler: P0 MATCH len=%u dev=%s\n",
                skb->len,
                skb->dev ? skb->dev->name : "?");
        return RX_HANDLER_CONSUMED;
    }

    return RX_HANDLER_PASS;
}

static int __init p0_rxhandler_init(void)
{
    struct net_device *dev;
    int ret;

    dev = dev_get_by_name(&init_net, "usb0");
    if (!dev) {
        pr_err("p0_rxhandler: usb0 not found\n");
        return -ENODEV;
    }

    rtnl_lock();
    ret = netdev_rx_handler_register(dev, p0_rx_handler, NULL);
    rtnl_unlock();

    dev_put(dev);

    if (ret) {
        pr_err("p0_rxhandler: register failed: %d\n", ret);
        return ret;
    }

    pr_info("p0_rxhandler: registered on usb0\n");
    return 0;
}

static void __exit p0_rxhandler_exit(void)
{
    struct net_device *dev;

    dev = dev_get_by_name(&init_net, "usb0");
    if (dev) {
        rtnl_lock();
        netdev_rx_handler_unregister(dev);
        rtnl_unlock();
        dev_put(dev);
    }

    pr_info("p0_rxhandler: unregistered; packets=%lu\n", p0_packets);
}

module_init(p0_rxhandler_init);
module_exit(p0_rxhandler_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("P0 RX handler observer");
