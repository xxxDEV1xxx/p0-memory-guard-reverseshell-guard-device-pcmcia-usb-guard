
cd /data/P0-memory-identity-beastmode

# 1. Confirm GLOBAL MODE is still present in the source
grep -n -A4 -B2 'GLOBAL MODE\|in_target_cgroup' beastmode.bpf.c

# 2. Recreate the service unit (same as before)
cat > /etc/systemd/system/p0-memory-identity-beastmode.service << 'EOF'
[Unit]
Description=P0 Memory Identity BEASTMODE (system-wide identity enforcement)
RequiresMountsFor=/data
After=data.mount local-fs.target
Before=multi-user.target
Documentation=file:///data/P0-memory-identity-beastmode/README.md

[Service]
Type=simple
WorkingDirectory=/data/P0-memory-identity-beastmode
ExecStart=/data/P0-memory-identity-beastmode/beastmode_loader.p0test
Restart=on-failure
RestartSec=3
User=root
Group=root
Environment=PYTHONPATH=/data/P0_MEMORY_IDENTITY_BEASTMODE_20260918_092535
Environment=PYTHONUNBUFFERED=1
StandardOutput=journal
StandardError=journal
SyslogIdentifier=p0-beastmode

[Install]
WantedBy=multi-user.target
EOF

# 3. Reload and start
systemctl daemon-reload
systemctl enable --now p0-memory-identity-beastmode.service
sleep 1
systemctl status p0-memory-identity-beastmode.service --no-pager -l
journalctl -u p0-memory-identity-beastmode.service -n 15 --no-pager
cd /data/P0-memory-identity-beastmode
