#include <linux/bpf.h>
#include <linux/in.h>
#include <linux/socket.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>

char LICENSE[] SEC("license") = "GPL";

#define FLAG_SHELL        (1U << 0)
#define FLAG_INTERACTIVE  (1U << 1)
#define FLAG_CONNECT      (1U << 2)
#define FLAG_FD_REDIRECT  (1U << 3)

#define EVENT_MATCH 1

struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, __u64);
} target_cgroup SEC(".maps");

struct trace_event_raw_sys_enter {
    __u64 unused;
    long syscall_nr;
    unsigned long args[6];
};

struct proc_state {
    __u32 flags;
    __u32 connect_count;
    __u32 redirect_count;
    __u32 reserved;
    __u64 match_latch;
};

struct reverse_shell_event {
    __u32 pid;
    __u32 uid;
    __u64 cgroup;
    __u32 flags;
    __u32 connect_count;
    __u32 redirect_count;
    __u32 match;
    char comm[16];
};

struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 16384);
    __type(key, __u32);
    __type(value, struct proc_state);
} processes SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 20);
} events SEC(".maps");

static __always_inline __u32 current_tgid(void)
{
    return (__u32)(bpf_get_current_pid_tgid() >> 32);
}

static __always_inline int in_target_cgroup(void)
{
    __u32 key = 0;
    __u64 *target;

    target = bpf_map_lookup_elem(&target_cgroup, &key);
    if (!target)
        return 0;

    return bpf_get_current_cgroup_id() == *target;
}

static __always_inline int read_arg(
    const char *const *argv,
    int index,
    char *dst,
    __u32 size)
{
    const char *p = 0;

    if (bpf_probe_read_user(
            &p,
            sizeof(p),
            &argv[index]) < 0)
        return -1;

    if (!p)
        return -1;

    if (bpf_probe_read_user_str(dst, size, p) < 0)
        return -1;

    return 0;
}

static __always_inline int str_equal(
    const char *a,
    const char *b)
{
    #pragma unroll
    for (int i = 0; i < 32; i++) {
        char ca = 0;
        char cb = 0;

        if (bpf_probe_read_user(&ca, sizeof(ca), &a[i]) < 0)
            return 0;

        cb = b[i];

        if (ca != cb)
            return 0;

        if (ca == '\0')
            return 1;
    }

    return 0;
}

static __always_inline int arg_has_prefix(
    const char *s,
    const char *token)
{
    #pragma unroll
    for (int i = 0; i < 8; i++) {
        char a = s[i];
        char b = token[i];

        if (b == '\0')
            return 1;

        if (a != b)
            return 0;
    }

    return 1;
}

static __always_inline void maybe_set_shell_flag(struct proc_state *st)
{
    char comm[16] = {};
    bpf_get_current_comm(comm, sizeof(comm));
    if (comm[0] == 'b' && comm[1] == 'a' && comm[2] == 's' && comm[3] == 'h')
        st->flags |= FLAG_SHELL;
    else if (comm[0] == 's' && comm[1] == 'h' && comm[2] == '\0')
        st->flags |= FLAG_SHELL;
}

static __always_inline void emit_match(
    __u32 pid,
    struct proc_state *st)
{
    /* Real-world reverse shells almost always do:
       connect + redirect stdin/stdout/stderr.
       The explicit "bash -i" execve is not always present
       in the same way, so we treat CONNECT + FD_REDIRECT
       as sufficient when the process looks like a shell.
    */
    if (!(st->flags & FLAG_CONNECT) ||
        !(st->flags & FLAG_FD_REDIRECT))
        return;

    /* Optional: still prefer seeing a shell, but do not require it */
    /* (we keep the original flags for logging) */

    struct reverse_shell_event *e;
    e = bpf_ringbuf_reserve(&events, sizeof(*e), 0);
    if (!e)
        return;

    __u64 old_latch = __sync_fetch_and_or(&st->match_latch, 1ULL);
    if (old_latch & 1ULL) {
        bpf_ringbuf_discard(e, 0);
        return;
    }

    e->pid = pid;
    e->uid = (__u32)bpf_get_current_uid_gid();
    e->cgroup = bpf_get_current_cgroup_id();
    e->flags = st->flags;
    e->connect_count = st->connect_count;
    e->redirect_count = st->redirect_count;
    e->match = EVENT_MATCH;
    bpf_get_current_comm(e->comm, sizeof(e->comm));
    bpf_ringbuf_submit(e, 0);

    /* Kill it */
    bpf_send_signal(9);   /* SIGKILL */
}

SEC("tracepoint/syscalls/sys_enter_execve")
int p0_reverseshell_v2_execve(
    struct trace_event_raw_sys_enter *ctx)
{
    const char *const *argv;
    const char *filename_ptr;
    const char *claimed_ptr;
    __u32 pid;
    struct proc_state st = {};
    char arg[16] = {};
    char filename[64] = {};
    char claimed[64] = {};

    /* GLOBAL MODE - watch all cgroups */
    // if (!in_target_cgroup())
    //     return 0;

    pid = current_tgid();

    /*
     * Read the actual execve filename from ctx->args[0] and the
     * declared argv[0] separately. Do not use argv[0] as the
     * authoritative executable identity.
     */
    filename_ptr = (const char *)ctx->args[0];
    argv = (const char *const *)ctx->args[1];

    if (!filename_ptr || !argv)
        return 0;

    if (bpf_probe_read_user_str(
            filename,
            sizeof(filename),
            filename_ptr) < 0)
        return 0;

    if (bpf_probe_read_user(
            &claimed_ptr,
            sizeof(claimed_ptr),
            &argv[0]) < 0)
        return 0;

    if (!claimed_ptr)
        return 0;

    if (bpf_probe_read_user_str(
            claimed,
            sizeof(claimed),
            claimed_ptr) < 0)
        return 0;

    /*
     * PRE-EXEC IDENTITY GATE.
     * Compare basename(execve filename) with basename(argv[0]).
     * A mismatch is killed before exec completes.
     */
    {
        __u64 actual_hash = 1469598103934665603ULL;
        __u64 claimed_hash = 1469598103934665603ULL;
        __u8 actual_seen = 0;
        __u8 claimed_seen = 0;

        #pragma unroll
        for (int i = 0; i < 63; i++) {
            __u8 c = filename[i];

            if (c == '\0')
                break;

            if (c == '/') {
                actual_hash = 1469598103934665603ULL;
                actual_seen = 0;
                continue;
            }

            actual_hash ^= c;
            actual_hash *= 1099511628211ULL;
            actual_seen = 1;
        }

        #pragma unroll
        for (int i = 0; i < 63; i++) {
            __u8 c = claimed[i];

            if (c == '\0')
                break;

            if (c == '/') {
                claimed_hash = 1469598103934665603ULL;
                claimed_seen = 0;
                continue;
            }

            claimed_hash ^= c;
            claimed_hash *= 1099511628211ULL;
            claimed_seen = 1;
        }

        if (!actual_seen || !claimed_seen ||
            actual_hash != claimed_hash) {
            bpf_send_signal(9);
            return 0;
        }
    }

    /*
     * argv[0]: requested interpreter.
     */
    if (read_arg(argv, 0, arg, sizeof(arg)) == 0) {
        if (arg_has_prefix(arg, "bash") ||
            arg_has_prefix(arg, "sh")) {
            st.flags |= FLAG_SHELL;
        }
    }

    __builtin_memset(arg, 0, sizeof(arg));

    /*
     * argv[1]: interactive-shell indication.
     */
    if (read_arg(argv, 1, arg, sizeof(arg)) == 0) {
        if (arg_has_prefix(arg, "-i"))
            st.flags |= FLAG_INTERACTIVE;
    }

    if (st.flags) {
        bpf_map_update_elem(
            &processes,
            &pid,
            &st,
            BPF_ANY);
    }

    return 0;
}

SEC("tracepoint/syscalls/sys_enter_connect")
int p0_reverseshell_v2_connect(
    struct trace_event_raw_sys_enter *ctx)
{
    /* GLOBAL MODE - watch all cgroups */
    // if (!in_target_cgroup())
    //     return 0;

    __u32 pid = current_tgid();
    struct proc_state *st;

    st = bpf_map_lookup_elem(&processes, &pid);

    if (!st)
        return 0;

    maybe_set_shell_flag(st);

    st->flags |= FLAG_CONNECT;
    st->connect_count++;

    emit_match(pid, st);

    return 0;
}

SEC("tracepoint/syscalls/sys_enter_dup2")
int p0_reverseshell_v2_dup2(
    struct trace_event_raw_sys_enter *ctx)
{
    /* GLOBAL MODE - watch all cgroups */
    // if (!in_target_cgroup())
    //     return 0;

    __u32 pid = current_tgid();
    struct proc_state *st;

    st = bpf_map_lookup_elem(&processes, &pid);

    if (!st)
        return 0;

    maybe_set_shell_flag(st);

    st->flags |= FLAG_FD_REDIRECT;
    st->redirect_count++;

    emit_match(pid, st);

    return 0;
}

SEC("tracepoint/syscalls/sys_enter_dup3")
int p0_reverseshell_v2_dup3(
    struct trace_event_raw_sys_enter *ctx)
{
    /* GLOBAL MODE - watch all cgroups */
    // if (!in_target_cgroup())
    //     return 0;

    __u32 pid = current_tgid();
    struct proc_state *st;

    st = bpf_map_lookup_elem(&processes, &pid);

    if (!st)
        return 0;

    maybe_set_shell_flag(st);

    st->flags |= FLAG_FD_REDIRECT;
    st->redirect_count++;

    emit_match(pid, st);

    return 0;
}

SEC("tracepoint/sched/sched_process_fork")
int p0_reverseshell_v2_fork(void *ctx)
{
    /* GLOBAL MODE - watch all cgroups */
    // if (!in_target_cgroup())
    //     return 0;

    __u32 pid = current_tgid();
    struct proc_state *st = bpf_map_lookup_elem(&processes, &pid);
    if (!st)
        return 0;

    return 0;
}
