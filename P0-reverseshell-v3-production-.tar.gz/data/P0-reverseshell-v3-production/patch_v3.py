from pathlib import Path

p = Path("p0_reverseshell_v3.bpf.c")
s = p.read_text()

def replace_once(old, new, label):
    global s
    count = s.count(old)
    if count != 1:
        raise SystemExit(
            f"ABORT: {label}: expected 1 occurrence, found {count}"
        )
    s = s.replace(old, new, 1)
    print(f"PATCHED: {label}")

replace_once(
'''#define FLAG_FD_REDIRECT  (1U << 3)

#define EVENT_MATCH 1
''',
'''#define FLAG_FD_REDIRECT  (1U << 3)
#define FLAG_MATCHED      (1U << 4)

#define MAC19_P0_CGROUP_ID 2168907ULL

#define EVENT_MATCH 1
''',
"production constants"
)

replace_once(
'''static __always_inline __u32 current_tgid(void)
{
    return (__u32)(bpf_get_current_pid_tgid() >> 32);
}
''',
'''static __always_inline __u32 current_tgid(void)
{
    return (__u32)(bpf_get_current_pid_tgid() >> 32);
}

static __always_inline int in_mac19_p0_cgroup(void)
{
    return bpf_get_current_cgroup_id() == MAC19_P0_CGROUP_ID;
}
''',
"cgroup boundary helper"
)

replace_once(
'''    if ((st->flags &
         (FLAG_SHELL |
          FLAG_INTERACTIVE |
          FLAG_CONNECT |
          FLAG_FD_REDIRECT))
        != (FLAG_SHELL |
            FLAG_INTERACTIVE |
            FLAG_CONNECT |
            FLAG_FD_REDIRECT))
        return;

    struct reverse_shell_event *e;
''',
'''    if ((st->flags &
         (FLAG_SHELL |
          FLAG_INTERACTIVE |
          FLAG_CONNECT |
          FLAG_FD_REDIRECT))
        != (FLAG_SHELL |
            FLAG_INTERACTIVE |
            FLAG_CONNECT |
            FLAG_FD_REDIRECT))
        return;

    __u32 old_flags;

    old_flags = __sync_fetch_and_or(
        &st->flags,
        FLAG_MATCHED);

    if (old_flags & FLAG_MATCHED)
        return;

    struct reverse_shell_event *e;
''',
"one-shot match latch"
)

replace_once(
'''    pid = current_tgid();

    argv = (const char *const *)ctx->args[1];
''',
'''    if (!in_mac19_p0_cgroup())
        return 0;

    pid = current_tgid();

    argv = (const char *const *)ctx->args[1];
''',
"execve cgroup boundary"
)

replace_once(
'''int p0_reverseshell_v2_connect(
    struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = current_tgid();
''',
'''int p0_reverseshell_v2_connect(
    struct trace_event_raw_sys_enter *ctx)
{
    if (!in_mac19_p0_cgroup())
        return 0;

    __u32 pid = current_tgid();
''',
"connect cgroup boundary"
)

replace_once(
'''int p0_reverseshell_v2_dup2(
    struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = current_tgid();
''',
'''int p0_reverseshell_v2_dup2(
    struct trace_event_raw_sys_enter *ctx)
{
    if (!in_mac19_p0_cgroup())
        return 0;

    __u32 pid = current_tgid();
''',
"dup2 cgroup boundary"
)

replace_once(
'''int p0_reverseshell_v2_dup3(
    struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = current_tgid();
''',
'''int p0_reverseshell_v2_dup3(
    struct trace_event_raw_sys_enter *ctx)
{
    if (!in_mac19_p0_cgroup())
        return 0;

    __u32 pid = current_tgid();
''',
"dup3 cgroup boundary"
)

p.write_text(s)
print("P1 SOURCE PATCH COMPLETE")
