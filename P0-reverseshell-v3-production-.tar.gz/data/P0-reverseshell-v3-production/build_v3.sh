#!/bin/bash
set -euo pipefail

BASE=/data/P0-reverseshell-v3-production
CLANG=/data/lib-ext/usr/bin/clang-14

"$CLANG" \
    -O2 \
    -g \
    -target bpf \
    -D__TARGET_ARCH_x86 \
    -I/data/lib-ext/usr/include \
    -I/usr/include/x86_64-linux-gnu \
    -I/usr/include \
    -c "$BASE/p0_reverseshell_v3.bpf.c" \
    -o "$BASE/p0_reverseshell_v3.bpf.o"

gcc \
    -O2 \
    -Wall \
    -Wextra \
    -I/data/lib-ext/usr/include \
    "$BASE/p0_reverseshell_v3_loader.c" \
    -L/data/lib-ext/usr/lib/x86_64-linux-gnu \
    -Wl,-rpath,/data/lib-ext/usr/lib/x86_64-linux-gnu \
    -lbpf \
    -lelf \
    -lz \
    -o "$BASE/p0_reverseshell_v3_loader"

echo
echo "=== V3 BUILD COMPLETE ==="
file "$BASE/p0_reverseshell_v3.bpf.o"
file "$BASE/p0_reverseshell_v3_loader"
