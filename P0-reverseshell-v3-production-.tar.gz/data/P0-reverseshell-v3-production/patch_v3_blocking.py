#!/usr/bin/env python3
"""
Robust patch – turn P0 reverse-shell detector into a real blocker
"""

import pathlib
import re
import sys

BASE = pathlib.Path("/data/P0-reverseshell-v3-production")
BPF_C    = BASE / "p0_reverseshell_v3.bpf.c"
LOADER_C = BASE / "p0_reverseshell_v3_loader.c"

# ------------------------------------------------------------------
# 1. Patch BPF – inject bpf_send_signal(9) at the end of emit_match
# ------------------------------------------------------------------
bpf = BPF_C.read_text()

# Find the end of emit_match by looking for the last bpf_ringbuf_submit
# and the closing brace of the function.
pattern = re.compile(
    r'(bpf_ringbuf_submit\(e,\s*0\);\s*)\n(\})',
    re.MULTILINE
)

replacement = r'''\1

    /* === BLOCKING === */
    bpf_send_signal(9);   /* SIGKILL */
\2'''

new_bpf, n = pattern.subn(replacement, bpf, count=1)

if n != 1:
    print("[!] Could not locate the end of emit_match() – source may have changed", file=sys.stderr)
    sys.exit(1)

BPF_C.write_text(new_bpf)
print(f"[+] Patched {BPF_C.name} → SIGKILL added")

# ------------------------------------------------------------------
# 2. Patch loader banner
# ------------------------------------------------------------------
loader = LOADER_C.read_text()

loader = loader.replace(
    'printf("Audit only. No blocking.\\n");',
    'printf("BLOCKING MODE ENABLED\\n");'
)
loader = loader.replace(
    'printf("execve + connect + dup2 + dup3\\n");',
    'printf("execve + connect + dup2 + dup3  →  SIGKILL on match\\n");'
)

LOADER_C.write_text(loader)
print(f"[+] Patched {LOADER_C.name} → banner updated")

print("\nDone. Rebuild with ./build_v3.sh and restart the loader.")
