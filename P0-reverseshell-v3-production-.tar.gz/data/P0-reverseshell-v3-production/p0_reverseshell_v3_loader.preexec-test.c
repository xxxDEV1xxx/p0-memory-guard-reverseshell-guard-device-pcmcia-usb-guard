#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <bpf/libbpf.h>
#include <bpf/bpf.h>

struct reverse_shell_event {
    unsigned int pid;
    unsigned int uid;
    unsigned long long cgroup;
    unsigned int flags;
    unsigned int connect_count;
    unsigned int redirect_count;
    unsigned int match;
    char comm[16];
};

static int get_current_cgroup_id(unsigned long long *id)
{
    FILE *f;
    char line[4096];
    char path[4096];
    char *sep;
    struct stat st;

    f = fopen("/proc/self/cgroup", "r");
    if (!f)
        return -errno;

    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "0::", 3) == 0) {
            sep = line + 3;
            sep[strcspn(sep, "\n")] = '\0';

            if (snprintf(path, sizeof(path),
                         "/sys/fs/cgroup%s", sep) >= (int)sizeof(path)) {
                fclose(f);
                return -ENAMETOOLONG;
            }

            fclose(f);

            if (stat(path, &st) < 0)
                return -errno;

            *id = (unsigned long long)st.st_ino;
            return 0;
        }
    }

    fclose(f);
    return -ENOENT;
}

static int handle_event(void *ctx, void *data, size_t data_sz)
{
    const struct reverse_shell_event *e = data;

    (void)ctx;
    (void)data_sz;

    printf(
        "P0_REVERSE_SHELL_V3 "
        "pid=%u uid=%u cgroup=%llu "
        "flags=0x%08x connect=%u redirect=%u "
        "comm=%s match=%u\n",
        e->pid,
        e->uid,
        e->cgroup,
        e->flags,
        e->connect_count,
        e->redirect_count,
        e->comm,
        e->match
    );

    fflush(stdout);
    return 0;
}

int main(void)
{
    struct bpf_object *obj = NULL;
    struct bpf_program *execve_prog = NULL;
    struct bpf_program *connect_prog = NULL;
    struct bpf_program *dup2_prog = NULL;
    struct bpf_program *dup3_prog = NULL;
    struct bpf_program *fork_prog = NULL;

    struct bpf_link *execve_link = NULL;
    struct bpf_link *connect_link = NULL;
    struct bpf_link *dup2_link = NULL;
    struct bpf_link *dup3_link = NULL;
    struct bpf_link *fork_link = NULL;

    struct bpf_map *events_map = NULL;
    struct bpf_map *target_cgroup_map = NULL;
    struct ring_buffer *rb = NULL;

    unsigned long long cgroup_id;
    __u32 cgroup_key = 0;

    int err;

    libbpf_set_strict_mode(LIBBPF_STRICT_ALL);

    obj = bpf_object__open_file(
        "/data/P0-reverseshell-v3-production/p0_reverseshell_v3.bpf.preexec-test.o",
        NULL
    );

    if (!obj) {
        fprintf(stderr, "bpf_object__open_file failed\n");
        return 1;
    }

    if (bpf_object__load(obj)) {
        fprintf(stderr, "bpf_object__load failed\n");
        bpf_object__close(obj);
        return 1;
    }

    if (get_current_cgroup_id(&cgroup_id) < 0) {
        fprintf(stderr, "failed to determine current cgroup id\n");
        bpf_object__close(obj);
        return 1;
    }

    target_cgroup_map = bpf_object__find_map_by_name(
        obj,
        "target_cgroup"
    );

    if (!target_cgroup_map) {
        fprintf(stderr, "target_cgroup map not found\n");
        bpf_object__close(obj);
        return 1;
    }

    if (bpf_map_update_elem(
            bpf_map__fd(target_cgroup_map),
            &cgroup_key,
            &cgroup_id,
            BPF_ANY) < 0) {
        fprintf(stderr, "failed to set target cgroup: %s\n",
                strerror(errno));
        bpf_object__close(obj);
        return 1;
    }

    printf("target_cgroup=%llu\n", cgroup_id);
    fflush(stdout);

    execve_prog = bpf_object__find_program_by_name(
        obj,
        "p0_reverseshell_v2_execve"
    );

    connect_prog = bpf_object__find_program_by_name(
        obj,
        "p0_reverseshell_v2_connect"
    );

    dup2_prog = bpf_object__find_program_by_name(
        obj,
        "p0_reverseshell_v2_dup2"
    );

    dup3_prog = bpf_object__find_program_by_name(
        obj,
        "p0_reverseshell_v2_dup3"
    );

    fork_prog = bpf_object__find_program_by_name(
        obj,
        "p0_reverseshell_v2_fork"
    );

    fprintf(stderr, "LOOKUP execve=%p connect=%p dup2=%p dup3=%p fork=%p\\n",
            (void *)execve_prog,
            (void *)connect_prog,
            (void *)dup2_prog,
            (void *)dup3_prog,
            (void *)fork_prog);

    {
        struct bpf_program *p_iter;

        bpf_object__for_each_program(p_iter, obj) {
            fprintf(stderr, "OBJECT PROGRAM: %s\\n",
                    bpf_program__name(p_iter));
        }
    }

    if (!execve_prog ||
        !connect_prog ||
        !dup2_prog ||
        !dup3_prog ||
        !fork_prog) {
        fprintf(stderr, "one or more v3 programs not found\n");
        bpf_object__close(obj);
        return 1;
    }

    printf("execve_fd=%d\n", bpf_program__fd(execve_prog));
    printf("connect_fd=%d\n", bpf_program__fd(connect_prog));
    printf("dup2_fd=%d\n", bpf_program__fd(dup2_prog));
    printf("dup3_fd=%d\n", bpf_program__fd(dup3_prog));
    printf("fork_fd=%d\n", bpf_program__fd(fork_prog));

    execve_link = bpf_program__attach_tracepoint(
        execve_prog,
        "syscalls",
        "sys_enter_execve"
    );

    if (!execve_link) {
        fprintf(stderr, "execve tracepoint attach failed\n");
        goto cleanup;
    }

    connect_link = bpf_program__attach_tracepoint(
        connect_prog,
        "syscalls",
        "sys_enter_connect"
    );

    if (!connect_link) {
        fprintf(stderr, "connect tracepoint attach failed\n");
        goto cleanup;
    }

    dup2_link = bpf_program__attach_tracepoint(
        dup2_prog,
        "syscalls",
        "sys_enter_dup2"
    );

    if (!dup2_link) {
        fprintf(stderr, "dup2 tracepoint attach failed\n");
        goto cleanup;
    }

    dup3_link = bpf_program__attach_tracepoint(
        dup3_prog,
        "syscalls",
        "sys_enter_dup3"
    );

    if (!dup3_link) {
        fprintf(stderr, "dup3 tracepoint attach failed\n");
        goto cleanup;
    }

    fork_link = bpf_program__attach_tracepoint(
        fork_prog,
        "sched",
        "sched_process_fork"
    );

    if (!fork_link) {
        fprintf(stderr, "fork tracepoint attach failed\n");
        goto cleanup;
    }

    events_map = bpf_object__find_map_by_name(
        obj,
        "events"
    );

    if (!events_map) {
        fprintf(stderr, "events map not found\n");
        goto cleanup;
    }

    rb = ring_buffer__new(
        bpf_map__fd(events_map),
        handle_event,
        NULL,
        NULL
    );

    if (!rb) {
        fprintf(stderr, "ring_buffer__new failed\n");
        goto cleanup;
    }

    printf("P0 REVERSE-SHELL V3 ATTACHED\n");
    printf("BLOCKING MODE ENABLED\n");
    printf("execve + connect + dup2 + dup3 + fork  →  SIGKILL on match\n");
    fflush(stdout);

    for (;;) {
        err = ring_buffer__poll(rb, 1000);

        if (err == -EINTR)
            break;

        if (err < 0) {
            fprintf(
                stderr,
                "ring_buffer__poll failed: %d\n",
                err
            );
            break;
        }
    }

cleanup:
    ring_buffer__free(rb);

    bpf_link__destroy(fork_link);
    bpf_link__destroy(dup3_link);
    bpf_link__destroy(dup2_link);
    bpf_link__destroy(connect_link);
    bpf_link__destroy(execve_link);

    bpf_object__close(obj);

    return 1;
}
