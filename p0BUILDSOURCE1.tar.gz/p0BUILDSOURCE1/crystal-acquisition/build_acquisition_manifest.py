# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import os
import sys
import json
import hashlib
import struct
import time
from pathlib import Path

INV_DIR = str(Path(__file__).resolve().parent.parent / "build" / "inventory")
OUT_DIR = str(Path(__file__).resolve().parent.parent / "build" / "inventory")

inventories = sorted(
    x for x in os.listdir(INV_DIR)
    if x.startswith("executable_inventory_") and x.endswith(".json")
)

if not inventories:
    print("NO EXECUTABLE INVENTORY FOUND")
    sys.exit(1)

inventory_file = os.path.join(INV_DIR, inventories[-1])

with open(inventory_file, "r", encoding="utf-8") as f:
    inventory = json.load(f)

records = inventory["records"]

run_id = time.strftime("%Y%m%d_%H%M%S")

manifest_path = os.path.join(
    OUT_DIR,
    f"acquisition_manifest_{run_id}.json"
)

jsonl_path = os.path.join(
    OUT_DIR,
    f"acquisition_manifest_{run_id}.jsonl"
)


def read_head(path, size=8192):
    try:
        with open(path, "rb") as f:
            return f.read(size)
    except Exception:
        return b""


def elf_info(data):
    if len(data) < 20 or data[:4] != b"\x7fELF":
        return None

    ei_class = data[4]
    ei_data = data[5]

    if ei_class == 2:
        elf_class = "ELF64"
    elif ei_class == 1:
        elf_class = "ELF32"
    else:
        elf_class = "ELF_UNKNOWN"

    if ei_data == 1:
        endian = "<"
    elif ei_data == 2:
        endian = ">"
    else:
        endian = "<"

    try:
        if ei_class == 2:
            e_type = struct.unpack_from(
                endian + "H", data, 16
            )[0]

            e_machine = struct.unpack_from(
                endian + "H", data, 18
            )[0]

            e_phoff = struct.unpack_from(
                endian + "Q", data, 32
            )[0]

            e_phentsize = struct.unpack_from(
                endian + "H", data, 54
            )[0]

            e_phnum = struct.unpack_from(
                endian + "H", data, 56
            )[0]

            ph_fmt = endian + "IIQQQQQQ"

        else:
            e_type = struct.unpack_from(
                endian + "H", data, 16
            )[0]

            e_machine = struct.unpack_from(
                endian + "H", data, 18
            )[0]

            e_phoff = struct.unpack_from(
                endian + "I", data, 28
            )[0]

            e_phentsize = struct.unpack_from(
                endian + "H", data, 42
            )[0]

            e_phnum = struct.unpack_from(
                endian + "H", data, 44
            )[0]

            ph_fmt = endian + "IIIIIIII"

        type_names = {
            1: "REL",
            2: "EXEC",
            3: "DYN",
            4: "CORE",
        }

        machine_names = {
            3: "x86",
            62: "x86_64",
            40: "ARM",
            183: "AARCH64",
            8: "MIPS",
            243: "RISCV",
        }

        interp = None

        for i in range(e_phnum):
            off = e_phoff + i * e_phentsize

            if off + struct.calcsize(ph_fmt) > len(data):
                break

            ph = struct.unpack_from(ph_fmt, data, off)

            if ei_class == 2:
                p_type = ph[0]
                p_offset = ph[2]
                p_filesz = ph[5]
            else:
                p_type = ph[0]
                p_offset = ph[1]
                p_filesz = ph[4]

            # PT_INTERP
            if p_type == 3:
                try:
                    end = min(
                        p_offset + p_filesz,
                        len(data)
                    )

                    raw = data[p_offset:end]
                    interp = raw.split(b"\0", 1)[0].decode(
                        "utf-8",
                        errors="replace"
                    )
                except Exception:
                    interp = None

        return {
            "class": elf_class,
            "endian": "little" if ei_data == 1 else "big",
            "type": type_names.get(
                e_type,
                f"TYPE_{e_type}"
            ),
            "machine": machine_names.get(
                e_machine,
                f"MACHINE_{e_machine}"
            ),
            "interpreter": interp,
        }

    except Exception as e:
        return {
            "class": elf_class,
            "parse_error": type(e).__name__,
            "parse_message": str(e),
        }


def shebang_info(data):
    if not data.startswith(b"#!"):
        return None

    line = data.split(b"\n", 1)[0][2:].strip()

    try:
        text = line.decode(
            "utf-8",
            errors="replace"
        )
    except Exception:
        return None

    parts = text.split()

    if not parts:
        return None

    interpreter = parts[0]
    interpreter_args = parts[1:]

    # /usr/bin/env python3
    env_name = None

    if os.path.basename(interpreter) == "env" and interpreter_args:
        env_name = interpreter_args[0]

    return {
        "raw": text,
        "interpreter": interpreter,
        "interpreter_args": interpreter_args,
        "env_dispatch": env_name,
    }


def classify(record):
    path = record.get("resolved_path", record.get("path", ""))

    data = read_head(path)

    if not data:
        return {
            "format": "UNREADABLE",
            "acquisition": "RECORD_ONLY",
        }

    ei = elf_info(data)

    if ei:
        result = {
            "format": "ELF",
            "elf": ei,
        }

        if ei.get("type") in ("EXEC", "DYN"):
            if ei.get("interpreter"):
                result["acquisition"] = "ELF_CONTROLLED_P0"
            else:
                result["acquisition"] = "ELF_CONTROLLED_P0"
        else:
            result["acquisition"] = "RECORD_ONLY"

        return result

    sb = shebang_info(data)

    if sb:
        interpreter = sb["interpreter"]

        if os.path.exists(interpreter):
            return {
                "format": "SCRIPT",
                "script": sb,
                "interpreter_exists": True,
                "acquisition": "SCRIPT_CONTROLLED_P0",
            }

        if sb.get("env_dispatch"):
            return {
                "format": "SCRIPT",
                "script": sb,
                "interpreter_exists": False,
                "acquisition": "SCRIPT_ENV_RESOLUTION",
            }

        return {
            "format": "SCRIPT",
            "script": sb,
            "interpreter_exists": False,
            "acquisition": "RECORD_ONLY",
        }

    return {
        "format": "EXECUTABLE_OTHER",
        "acquisition": "FORMAT_ANALYSIS_REQUIRED",
    }


unique = {}
duplicates = []

for n, record in enumerate(records, 1):

    if n % 1000 == 0:
        print(
            f"[{n:5d}/{len(records):5d}]",
            flush=True
        )

    path = record.get("resolved_path", record.get("path", ""))
    sha = record.get("sha256", "")

    key = (path, sha)

    analysis = classify(record)

    item = dict(record)
    item["analysis"] = analysis

    if key in unique:
        duplicates.append({
            "path": record.get("path", ""),
            "resolved_path": path,
            "sha256": sha,
            "duplicate_of": unique[key]["path"],
        })
        continue

    unique[key] = item


items = list(unique.values())

counts = {}
for item in items:
    fmt = item["analysis"].get("format", "UNKNOWN")
    action = item["analysis"].get(
        "acquisition",
        "UNKNOWN"
    )

    counts[fmt] = counts.get(fmt, 0) + 1

items.sort(
    key=lambda x: (
        x["analysis"].get("acquisition", ""),
        x.get("resolved_path", "")
    )
)

manifest = {
    "run_id": run_id,
    "source_inventory": inventory_file,
    "generated_unix": time.time(),
    "source_objects": len(records),
    "unique_objects": len(items),
    "duplicates": len(duplicates),
    "format_counts": counts,
    "acquisition_counts": {},
    "objects": items,
    "duplicates_detail": duplicates,
}

for item in items:
    action = item["analysis"].get(
        "acquisition",
        "UNKNOWN"
    )

    manifest["acquisition_counts"][action] = (
        manifest["acquisition_counts"].get(action, 0) + 1
    )

with open(
    manifest_path,
    "w",
    encoding="utf-8"
) as f:
    json.dump(
        manifest,
        f,
        indent=2
    )

with open(
    jsonl_path,
    "w",
    encoding="utf-8"
) as f:
    for item in items:
        f.write(
            json.dumps(
                item,
                sort_keys=True
            ) + "\n"
        )

print()
print("=" * 60)
print(" ACQUISITION MANIFEST COMPLETE")
print("=" * 60)
print()
print(f"Source objects:       {len(records)}")
print(f"Unique objects:       {len(items)}")
print(f"Duplicate references: {len(duplicates)}")
print()

print("FORMATS")
for key in sorted(counts):
    print(f"  {key:24s} {counts[key]:6d}")

print()
print("ACQUISITION ACTIONS")

for key in sorted(
    manifest["acquisition_counts"]
):
    print(
        f"  {key:32s} "
        f"{manifest['acquisition_counts'][key]:6d}"
    )

print()
print(f"Manifest: {manifest_path}")
print(f"JSONL:    {jsonl_path}")
print()