# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import json
import struct
from pathlib import Path

BASELINE_ROOT = Path(__file__).resolve().parent.parent / "build" / "process_baseline"
DATABASE = Path(__file__).resolve().parent.parent / "build" / "database"
INDEX = DATABASE / "memory_master_index.tsv"

CHUNK = 4096


def parse_maps(path):
    data = json.loads(path.read_text())

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("mappings", "maps", "records"):
            if isinstance(data.get(key), list):
                return data[key]

    raise RuntimeError(f"Unsupported maps format: {path}")


def mapping_blob(root, start, length):
    exact = root / f"{start:016x}_{length:x}.bin"

    if exact.exists() and exact.stat().st_size == length:
        return exact

    prefix = f"{start:016x}_"

    for p in root.glob(prefix + "*.bin"):
        if p.stat().st_size == length:
            return p

    for p in root.rglob(f"{start:016x}_{length:x}.bin"):
        if p.is_file() and p.stat().st_size == length:
            return p

    return None


def load_candidate(d):
    source = json.loads(
        (d / "source.json").read_text()
    )

    run = d / "run01"

    metadata = json.loads(
        (run / "metadata.json").read_text()
    )

    memory = (run / "memory.bin").read_bytes()

    return source, metadata, memory

def fingerprint(memory):
    """
    Locality-preserving numeric fingerprint.

    This is intentionally NOT a cryptographic hash.

    Similar memory images should produce nearby numerical values.
    Multiple statistics are packed into one sortable integer.
    """

    size = len(memory)

    if not size:
        return 0

    # Divide the image into eight fixed regions.
    regions = 8
    values = []

    for r in range(regions):
        start = (size * r) // regions
        end = (size * (r + 1)) // regions

        region = memory[start:end]

        if not region:
            values.append(0)
            continue

        total = sum(region)
        count = len(region)

        # Mean byte value, quantized to 16 bits.
        mean = (total * 65535) // (count * 255)

        values.append(mean)

    # Also include total size as a quantized component.
    size_component = min(size, 0xFFFFFFFF)

    value = size_component

    for v in values:
        value = (value << 16) | v

    return value


def candidate_directories():
    return sorted(
        d for d in BASELINE_ROOT.iterdir()
        if d.is_dir()
        and (d / "source.json").exists()
        and (d / "run01" / "metadata.json").exists()
        and (d / "run01" / "memory.bin").exists()
    )

def main():
    DATABASE.mkdir(parents=True, exist_ok=True)

    candidates = candidate_directories()

    print("=" * 72)
    print("BUILDING P0 MEMORY MASTER INDEX")
    print("=" * 72)
    print()
    print(f"Candidate root: {BASELINE_ROOT}")
    print(f"Candidates:     {len(candidates):,}")
    print(f"Output:         {INDEX}")
    print()

    rows = []

    for n, d in enumerate(candidates, 1):
        try:
            source, metadata, memory = load_candidate(d)

            if not memory:
                print(f"[WARN] empty memory: {d.name}")
                continue

            fp = fingerprint(memory)

            rows.append((
                fp,
                d.name,
                Path(source.get("path", "")).name or d.name,
                source.get("path", ""),
                len(memory),
            ))

        except Exception as e:
            print(f"[WARN] {d.name}: {e}")

        if n % 500 == 0:
            print(f"  indexed {n:,}/{len(candidates):,}")

    rows.sort(key=lambda x: (x[0], x[4], x[1]))

    tmp = INDEX.with_suffix(".tmp")

    with tmp.open("w") as f:
        f.write(
            "fingerprint\t"
            "directory\t"
            "name\t"
            "path\t"
            "size\n"
        )

        for fp, directory, name, path, size in rows:
            f.write(
                f"{fp}\t"
                f"{directory}\t"
                f"{name}\t"
                f"{path}\t"
                f"{size}\n"
            )

    tmp.replace(INDEX)

    print()
    print("=" * 72)
    print("INDEX COMPLETE")
    print("=" * 72)
    print()
    print(f"Indexed: {len(rows):,}")
    print(f"Master:  {INDEX}")
    print()

    if rows:
        print("FIRST ENTRY")
        print(rows[0])
        print()
        print("LAST ENTRY")
        print(rows[-1])


if __name__ == "__main__":
    main()