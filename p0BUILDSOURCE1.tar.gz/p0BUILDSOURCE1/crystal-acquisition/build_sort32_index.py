# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

from pathlib import Path

BASE = Path(__file__).resolve().parent.parent / "build"
MASTER = BASE / "database/memory_master_index.tsv"
OUT = BASE / "database/memory_master_index_sort32.tsv"

SORT_OFFSET = 32
SORT_WIDTH = 32


def load_memory(directory):
    root = BASE / "process_baseline" / directory / "run01"
    memory = root / "memory.bin"
    if not memory.is_file():
        raise RuntimeError(f"no memory.bin: {memory}")
    return memory.read_bytes()


rows = []

with MASTER.open("r") as f:
    for line in f:
        line = line.rstrip("\n")
        if not line:
            continue

        parts = line.split("\t")

        if parts[0] == "fingerprint":
            continue

        if len(parts) < 5:
            continue

        fingerprint = parts[0]
        directory = parts[1]
        name = parts[2]
        path = parts[3]
        size = int(parts[4])

        memory = load_memory(directory)

        if len(memory) < SORT_OFFSET + SORT_WIDTH:
            raise RuntimeError(
                f"{directory}: only {len(memory)} bytes; "
                f"need {SORT_OFFSET + SORT_WIDTH}"
            )

        sort_key = memory[SORT_OFFSET:SORT_OFFSET + SORT_WIDTH]

        rows.append({
            "sort_key": sort_key,
            "fingerprint": fingerprint,
            "directory": directory,
            "name": name,
            "path": path,
            "size": size,
        })

        if len(rows) % 500 == 0:
            print(f"[LOAD] {len(rows):,}", flush=True)

rows.sort(key=lambda r: r["sort_key"])

with OUT.open("w") as f:
    f.write("sort_key_hex\tfingerprint\tdirectory\tname\tpath\tsize\n")

    for r in rows:
        f.write(
            f"{r['sort_key'].hex()}\t"
            f"{r['fingerprint']}\t"
            f"{r['directory']}\t"
            f"{r['name']}\t"
            f"{r['path']}\t"
            f"{r['size']}\n"
        )

print()
print(f"[DONE] entries : {len(rows):,}")
print(f"[DONE] offset  : {SORT_OFFSET}")
print(f"[DONE] width   : {SORT_WIDTH}")
print(f"[DONE] output  : {OUT}")