#!/usr/bin/env python3
# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import os
import sys
import time
import json
import hashlib
import ctypes
import ctypes.util
import subprocess
from pathlib import Path

LIBC = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)

PTRACE_TRACEME = 0
PTRACE_CONT = 7

BASE = Path(__file__).resolve().parent.parent / "build" / "process_baseline"
RUNS = 5

MANIFEST_DIR = Path(__file__).resolve().parent.parent / "build" / "inventory"


def load_targets():
    manifests = sorted(
        MANIFEST_DIR.glob("acquisition_manifest_*.json")
    )

    if not manifests:
        raise RuntimeError(
            f"no acquisition manifest found in {MANIFEST_DIR}"
        )

    manifest_path = manifests[-1]

    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    objects = {}

    for item in manifest.get("objects", []):
        action = item.get("analysis", {}).get("acquisition")

        if action not in {
            "ELF_CONTROLLED_P0",
            "SCRIPT_CONTROLLED_P0",
        }:
            continue

        path = item.get("resolved_path") or item.get("path")

        if not path:
            continue

        if not os.path.isfile(path) or not os.access(path, os.X_OK):
            continue

        key = (
            item.get("device"),
            item.get("inode"),
            item.get("sha256"),
        )

        if key not in objects:
            objects[key] = {
                "path": path,
                "aliases": [path],
                "device": item.get("device"),
                "inode": item.get("inode"),
                "sha256": item.get("sha256"),
                "type": item.get("type"),
                "analysis": item.get("analysis", {}),
            }
        else:
            objects[key]["aliases"].append(path)

    targets = sorted(
        objects.values(),
        key=lambda x: x["path"],
    )

    if not targets:
        raise RuntimeError(
            f"manifest contains no executable P0 acquisition targets: "
            f"{manifest_path}"
        )

    print(f"[MANIFEST] {manifest_path}")
    print(f"[MANIFEST] {len(targets)} unique P0 acquisition objects")
    print(
        f"[MANIFEST] {sum(len(x['aliases']) for x in targets)} "
        f"manifest paths"
    )
    print()

    return targets

def personality_no_aslr():
    PER_LINUX = 0x0000
    ADDR_NO_RANDOMIZE = 0x0040000
    old = LIBC.personality(0xffffffff)
    LIBC.personality(old | ADDR_NO_RANDOMIZE)

def child_exec(path):
    personality_no_aslr()

    os.environ.clear()

    if LIBC.ptrace(PTRACE_TRACEME, 0, None, None) != 0:
        os._exit(111)

    args = [path]

    if os.path.basename(path) == "sleep":
        args.append("60")

    os.execve(path, args, {})

def read_maps(pid):
    maps = []

    with open(f"/proc/{pid}/maps", "r") as f:
        for line in f:
            parts = line.rstrip("\n").split(None, 5)
            if len(parts) < 5:
                continue

            a, perms, off, dev, inode = parts[:5]
            name = parts[5] if len(parts) == 6 else ""

            start_s, end_s = a.split("-")
            start = int(start_s, 16)
            end = int(end_s, 16)

            maps.append({
                "start": start,
                "end": end,
                "perms": perms,
                "offset": int(off, 16),
                "dev": dev,
                "inode": int(inode),
                "name": name
            })

    return maps

def capture(pid, maps):
    chunks = []

    with open(f"/proc/{pid}/mem", "rb", buffering=0) as mem:
        for m in maps:
            if "r" not in m["perms"]:
                continue

            size = m["end"] - m["start"]

            try:
                mem.seek(m["start"])
                data = mem.read(size)
            except OSError:
                continue

            if len(data) != size:
                continue

            chunks.append({
                "start": m["start"],
                "end": m["end"],
                "perms": m["perms"],
                "offset": m["offset"],
                "name": m["name"],
                "data": data
            })

    return chunks

def sha256_file(path):
    h = hashlib.sha256()

    with open(path, "rb") as f:
        while True:
            b = f.read(1024 * 1024)
            if not b:
                break
            h.update(b)

    return h.hexdigest()

def wait_for_exec(pid):
    while True:
        wpid, status = os.waitpid(pid, 0)

        if os.WIFSTOPPED(status):
            return

        if os.WIFEXITED(status):
            code = os.WEXITSTATUS(status)
            raise RuntimeError(
                f"process {pid} exited before P0: exit={code}"
            )

        if os.WIFSIGNALED(status):
            sig = os.WTERMSIG(status)
            raise RuntimeError(
                f"process {pid} terminated before P0: signal={sig}"
            )

def capture_one(path, run_dir):
    pid = os.fork()

    if pid == 0:
        child_exec(path)
        os._exit(112)

    try:
        wait_for_exec(pid)

        maps = read_maps(pid)
        chunks = capture(pid, maps)

        metadata = {
            "path": path,
            "pid": pid,
            "maps": maps,
            "capture_time": time.time()
        }

        with open(run_dir / "maps.json", "w") as f:
            json.dump(metadata, f, indent=2)

        crystal_path = run_dir / "memory.bin"

        with open(crystal_path, "wb") as out:
            for c in chunks:
                out.write(c["data"])

        metadata["memory_bytes"] = crystal_path.stat().st_size
        metadata["sha256"] = sha256_file(crystal_path)

        with open(run_dir / "metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)

    finally:
        try:
            os.kill(pid, 9)
        except ProcessLookupError:
            pass

        try:
            os.waitpid(pid, 0)
        except ChildProcessError:
            pass

def main():
    BASE.mkdir(parents=True, exist_ok=True)
    targets = load_targets()

    print(f"[BASELINE] {len(targets)} unique executable objects")
    print(f"[BASELINE] {RUNS} P0 captures each")
    print()

    for item in targets:
        path = item["path"]
        exe_hash = item["sha256"]

        identity_material = (
            f"{item['device']}:{item['inode']}:{exe_hash}"
        ).encode("utf-8")

        identity_key = hashlib.sha256(identity_material).hexdigest()[:32]

        print(f"[PROCESS] {path}")
        print(f"  ELF SHA256: {exe_hash}")
        print(f"  IDENTITY KEY: {identity_key}")

        if len(item["aliases"]) > 1:
            print(f"  ALIASES: {len(item['aliases'])}")

        proc_dir = BASE / identity_key
        proc_dir.mkdir(exist_ok=True)

        source_metadata = {
            "path": path,
            "aliases": sorted(set(item["aliases"])),
            "device": item["device"],
            "inode": item["inode"],
            "sha256": exe_hash,
            "type": item["type"],
            "analysis": item["analysis"],
            "identity_key": identity_key,
        }

        with open(proc_dir / "source.json", "w") as f:
            json.dump(source_metadata, f, indent=2)

        analysis = item.get("analysis", {})
        elf = analysis.get("elf", {})

        if analysis.get("format") == "ELF" and elf.get("machine") != "x86_64":
            deferred = {
                **source_metadata,
                "state": "DEFERRED",
                "reason": "FOREIGN_EXECUTION_REQUIRED",
                "host_architecture": "x86_64",
                "object_architecture": elf.get("machine"),
                "object_class": elf.get("class"),
                "object_endian": elf.get("endian"),
                "interpreter": elf.get("interpreter"),
                "execution_backend": None,
                "deferred_time": time.time(),
            }

            with open(proc_dir / "deferred.json", "w") as f:
                json.dump(deferred, f, indent=2)

            print(
                "  DEFERRED: FOREIGN_EXECUTION_REQUIRED "
                f"machine={elf.get('machine')} "
                f"class={elf.get('class')}"
            )
            print()
            continue

        for n in range(1, RUNS + 1):
            run_dir = proc_dir / f"run{n:02d}"
            run_dir.mkdir(exist_ok=True)

            try:
                capture_one(path, run_dir)
                meta = json.loads(
                    (run_dir / "metadata.json").read_text()
                )
                print(
                    f"  run {n:02d}: "
                    f"{meta['memory_bytes']} bytes "
                    f"{meta['sha256'][:16]}"
                )
            except Exception as e:
                failure = {
                    **source_metadata,
                    "state": "ACQUISITION_ERROR",
                    "run": n,
                    "error": str(e),
                    "error_time": time.time(),
                }

                with open(run_dir / "error.json", "w") as f:
                    json.dump(failure, f, indent=2)

                print(f"  run {n:02d}: ERROR: {e}")

        print()

if __name__ == "__main__":
    main()