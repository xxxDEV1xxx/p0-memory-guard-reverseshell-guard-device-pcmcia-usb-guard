#!/usr/bin/env python3
# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import json
from bisect import bisect_left
from pathlib import Path

BUILD_ROOT = Path(__file__).resolve().parent.parent / "build"
BASE = BUILD_ROOT / "process_baseline"
CANDIDATE_ROOT = BUILD_ROOT / "p0"
INDEX = BUILD_ROOT / "database" / "memory_master_index.tsv"

WINDOW = 10

TARGETS = {
    "sleep": "/bin/sleep",
    "cat":   "/bin/cat",
    "echo":  "/bin/echo",
}


def parse_maps(path):
    data = json.loads(path.read_text())

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("mappings", "maps", "records"):
            if isinstance(data.get(key), list):
                return data[key]

    raise RuntimeError(f"Unsupported maps format: {path}")


def load_reference_run(name, run):
    root = BASE / name / f"run{run:02d}"
    return (root / "memory.bin").read_bytes()


def build_reference_crystal(name):
    memories = [
        load_reference_run(name, r)
        for r in range(1, 5)
    ]

    hidden = load_reference_run(name, 5)

    if len({len(x) for x in memories}) != 1:
        raise RuntimeError(
            f"REFERENCE SIZE MISMATCH for {name}"
        )

    size = len(memories[0])

    invariant = bytearray(size)
    mask = bytearray(size)

    for i in range(size):
        value = memories[0][i]

        if all(m[i] == value for m in memories[1:]):
            invariant[i] = value
            mask[i] = 1

    return {
        "size": size,
        "invariant": invariant,
        "mask": mask,
    }, hidden


def mapping_blob(root, start, length=None):
    if length is not None:
        exact = root / f"{start:016x}_{length:x}.bin"

        if exact.exists() and exact.stat().st_size == length:
            return exact

    prefix = f"{start:016x}_"

    for p in root.glob(prefix + "*.bin"):
        if length is None or p.stat().st_size == length:
            return p

    if length is not None:
        for p in root.rglob(f"{start:016x}_{length:x}.bin"):
            if p.is_file() and p.stat().st_size == length:
                return p

    return None


def load_candidate(d):
    metadata = json.loads(
        (d / "metadata.json").read_text()
    )

    maps = parse_maps(d / "maps.json")

    chunks = []

    for m in maps:
        start = int(m["start"])
        end = int(m["end"])
        length = end - start

        blob = mapping_blob(
            d,
            start,
            length
        )

        if blob is None:
            continue

        data = blob.read_bytes()

        if len(data) != length:
            continue

        chunks.append(data)

    memory = b"".join(chunks)

    mask = bytearray(b"\x01") * len(memory)

    return {
        "metadata": metadata,
        "memory": memory,
        "size": len(memory),
        "mask": mask,
    }


def fingerprint(memory):
    size = len(memory)

    if not size:
        return 0

    regions = 8
    values = []

    for r in range(regions):
        start = (size * r) // regions
        end = (size * (r + 1)) // regions

        region = memory[start:end]

        if not region:
            values.append(0)
            continue

        total = sum(region)
        count = len(region)

        mean = (total * 65535) // (count * 255)

        values.append(mean)

    size_component = min(size, 0xFFFFFFFF)

    value = size_component

    for v in values:
        value = (value << 16) | v

    return value


def load_index():
    rows = []

    with INDEX.open() as f:
        next(f)

        for line in f:
            parts = line.rstrip("\n").split("\t")

            if len(parts) != 5:
                continue

            fp, directory, name, path, size = parts

            rows.append({
                "fingerprint": int(fp),
                "directory": directory,
                "name": name,
                "path": path,
                "size": int(size),
            })

    return rows


def compare(sample, target):
    size = min(
        len(sample),
        target["size"]
    )

    mask = target["mask"]
    inv = target["invariant"]

    matched = 0
    tested = 0

    for i in range(size):
        if mask[i]:
            tested += 1

            if sample[i] == inv[i]:
                matched += 1

    pct = (
        matched / tested * 100.0
        if tested else 0.0
    )

    return matched, tested, pct


def main():
    print("=" * 72)
    print("5000-PROCESS MEMORY IDENTITY TEST — INDEXED")
    print("=" * 72)
    print()

    if not INDEX.exists():
        raise RuntimeError(
            f"MASTER INDEX NOT FOUND: {INDEX}\n"
            f"Run build_memory_master_index.py first."
        )

    index = load_index()
    fingerprints = [r["fingerprint"] for r in index]

    print(f"Master index entries: {len(index):,}")
    print()

    for target, expected_path in TARGETS.items():

        print("=" * 72)
        print(f"TARGET:   {target}")
        print(f"EXPECTED: {expected_path}")
        print("=" * 72)

        crystal, hidden = build_reference_crystal(target)

        deterministic_count = sum(
            crystal["mask"]
        )

        print(f"Crystal regions:     {len(crystal):,}")
        print(f"Deterministic bytes: {deterministic_count:,}")

        query_fp = fingerprint(hidden)

        position = bisect_left(
            fingerprints,
            query_fp
        )

        lo = max(0, position - WINDOW)
        hi = min(
            len(index),
            position + WINDOW + 1
        )

        selected = index[lo:hi]

        print(f"Query fingerprint:   {query_fp}")
        print(f"Binary position:     {position:,}")
        print(f"Index range:         {lo:,}..{hi - 1:,}")
        print(f"Indexed candidates:  {len(selected):,}")
        print()

        results = []

        for n, entry in enumerate(selected, 1):
            d = CANDIDATE_ROOT / entry["directory"]

            try:
                candidate = load_candidate(d)

                matched, compared, pct = compare(
                    candidate["memory"],
                    crystal
                )

                results.append({
                    "dir": d,
                    "name": entry["name"],
                    "path": entry["path"],
                    "compared": compared,
                    "matched": matched,
                    "pct": pct,
                })

            except Exception as e:
                print(
                    f"[WARN] {entry['directory']}: {e}"
                )

        results.sort(
            key=lambda x: (x["pct"], x["compared"]),
            reverse=True
        )

        print("INDEXED MEMORY MATCHES")
        print()

        for rank, r in enumerate(results[:10], 1):
            print(
                f"{rank:2d}. "
                f"{r['name']:<30} "
                f"{r['pct']:9.4f}% "
                f"{r['matched']:>8,}/"
                f"{r['compared']:<8,} "
                f"{r['path']}"
            )

        if results:
            best = results[0]

            print()
            print("INDEXED RESULT")
            print(
                f"rank:     {best['pct']:.4f}% "
                f"within {len(selected)} candidates"
            )
            print(f"match:    {best['pct']:.4f}%")
            print(
                f"bytes:    "
                f"{best['matched']:,}/"
                f"{best['compared']:,}"
            )
            print(f"candidate: {best['path']}")

        print()


if __name__ == "__main__":
    main()