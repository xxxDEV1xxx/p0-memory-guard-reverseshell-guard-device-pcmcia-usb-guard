#!/data/memorydata/venv/bin/python
# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import json
from p0_observation_domain import load_reference_domain
import os
import signal
import sys
from pathlib import Path

sys.path.insert(
    0,
    "/data/p0BUILDSOURCE/beastmode",
)

import memory_watchdog as mw


def acquire_live_memory(pid: int) -> bytes:
    live = mw.read_live_maps(pid)
    chunks = []

    for m in live:
        if "r" not in m["perms"]:
            continue

        try:
            data = mw.read_live_memory(
                pid,
                m["start"],
                m["length"],
            )
        except Exception:
            continue

        if len(data) != m["length"]:
            continue

        chunks.append(data)

    return b"".join(chunks)

def main():
    if len(sys.argv) != 3:
        return 2
    pid = int(sys.argv[1])
    claimed = sys.argv[2]
    proc = Path(f"/proc/{pid}")
    if not proc.exists():
        return 0
    stopped = False
    try:
        stop_target(pid)
        stopped = True
        claimed = Path(claimed).name if claimed else claimed
        actual = mw.resolve_pid(pid)
        print(
            f"P0_IDENTITY_OBSERVE "
            f"pid={pid} "
            f"claimed={claimed} "
            f"actual={actual}",
            flush=True,
        )

        # 1. Capture live memory from the *actual* process
        try:
            memory = acquire_live_memory(pid)
        except Exception as exc:
            print(f"P0_LIVE_CAPTURE_FAILED pid={pid} error={exc}", flush=True)
            kill(pid, "LIVE_CAPTURE_FAILED")
            return 0

        # 2. Build crystal for the *actual executable* identity
        try:
            reference_identity = mw.resolve_reference_identity(actual)
            crystal, _ = mw.build_reference_crystal(reference_identity)
        except Exception as exc:
            print(
                f"P0_CRYSTAL_MISSING "
                f"claimed={claimed} "
                f"actual={actual} "
                f"error={exc}",
                flush=True,
            )
            kill(pid, "CRYSTAL_MISSING")
            return 0

        matched, compared, pct = mw.compare(memory, crystal)
        reference = crystal["size"]
        decision(pid, claimed, actual, matched, compared, reference, pct)

        if compared != reference:
            kill(pid, "COVERAGE_FAILURE")
            return 0
        if pct < mw.EXPECTED_MATCH:
            kill(pid, "IDENTITY_MISMATCH")
            return 0

        try:
            os.kill(pid, signal.SIGCONT)
        except ProcessLookupError:
            pass
        print(
            f"P0_IDENTITY_DECISION "
            f"pid={pid} "
            f"decision=IDENTITY_CONSISTENT",
            flush=True,
        )
        stopped = False
        return 0
    except ProcessLookupError:
        return 0
    except Exception as exc:
        print(
            f"P0_IDENTITY_DECISION "
            f"pid={pid} "
            f"decision=IDENTITY_MISMATCH "
            f"reason=OBSERVER_ERROR "
            f"error={exc}",
            flush=True,
        )
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        return 0
def decision(pid, claimed, actual, matched, compared, reference, pct):
    print(
        f"P0_IDENTITY_DECISION "
        f"pid={pid} "
        f"claimed={claimed} "
        f"actual={actual} "
        f"matched={matched} "
        f"compared={compared} "
        f"reference={reference} "
        f"similarity={pct:.6f}%",
        flush=True,
    )


def kill(pid, reason):
    print(
        f"P0_IDENTITY_DECISION "
        f"pid={pid} "
        f"decision=IDENTITY_MISMATCH "
        f"reason={reason}",
        flush=True,
    )

    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def wait_stopped(pid, timeout=2.0):
    deadline = __import__("time").time() + timeout

    while __import__("time").time() < deadline:
        state = Path(
            f"/proc/{pid}/status"
        ).read_text(errors="replace")

        for line in state.splitlines():
            if line.startswith("State:"):
                if "T" in line or "t" in line:
                    return True
                break

        __import__("time").sleep(0.005)

    return False


def stop_target(pid):
    os.kill(pid, signal.SIGSTOP)

    if not wait_stopped(pid):
        raise RuntimeError(
            f"PID {pid} did not enter stopped state"
        )



if __name__ == "__main__":
    raise SystemExit(main())