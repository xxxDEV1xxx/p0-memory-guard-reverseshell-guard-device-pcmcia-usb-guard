#!/usr/bin/env python3
# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

from dataclasses import dataclass
from pathlib import Path
import json

# Prefer the large crystal tree; fall back to the small development set
CANDIDATE_BASELINES = [
    Path("/data/P0_MEMORY_IDENTITY_BEASTMODE_20260918_092535/process_baseline"),
    Path("/data/process_baseline"),
]

@dataclass(frozen=True)
class P0DomainRegion:
    name: str
    perms: str
    offset: int
    length: int

@dataclass(frozen=True)
class P0ObservationDomain:
    name: str
    regions: tuple[P0DomainRegion, ...]

    @property
    def size(self):
        return sum(r.length for r in self.regions)

def _find_baseline(name: str) -> Path | None:
    for base in CANDIDATE_BASELINES:
        candidate = base / name / "run01" / "maps.json"
        if candidate.is_file():
            return candidate
    return None

def load_reference_domain(name: str) -> P0ObservationDomain:
    maps_path = _find_baseline(name)
    if maps_path is None:
        raise FileNotFoundError(f"no reference domain for claimed identity '{name}'")

    data = json.loads(maps_path.read_text())
    regions = []
    for m in data["maps"]:
        if m["name"] in ("[vvar]", "[vdso]"):
            continue
        regions.append(
            P0DomainRegion(
                name=m["name"],
                perms=m["perms"],
                offset=int(m["offset"]),
                length=int(m["end"]) - int(m["start"]),
            )
        )
    return P0ObservationDomain(name=name, regions=tuple(regions))