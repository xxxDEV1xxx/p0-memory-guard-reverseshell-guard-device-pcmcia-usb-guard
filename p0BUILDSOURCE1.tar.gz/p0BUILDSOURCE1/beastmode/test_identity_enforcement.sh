#!/bin/bash
# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

set -euo pipefail

BASE=/data/P0-memory-identity-beastmode
SERVICE=p0-memory-identity-beastmode.service
PROD_LOADER="$BASE/beastmode_loader"
P0TEST_LOADER="$BASE/beastmode_loader.p0test"
WORKER="$BASE/p0_identity_worker.py"

LOGDIR="$BASE/test-results"
STAMP="$(date +%Y%m%d-%H%M%S)"
RUN="$LOGDIR/$STAMP"

mkdir -p "$RUN"

echo "=== P0 SYSTEMWIDE IDENTITY-ENFORCEMENT TEST ==="
echo "RUN=$RUN"
echo

###############################################################################
# 1. FIX / ACTIVATE PRODUCTION WORKER PATH
###############################################################################

echo "=== 1. PRODUCTION WORKER PATH ==="

test -x "$P0TEST_LOADER"
test -f "$WORKER"

echo "P0TEST_LOADER:"
sha256sum "$P0TEST_LOADER"

echo
echo "PRODUCTION_LOADER:"
sha256sum "$PROD_LOADER"

echo
echo "WORKER:"
sha256sum "$WORKER"

echo
echo "Checking production loader for worker-launch support..."

if strings "$PROD_LOADER" | grep -Fq "p0_identity_worker.py"; then
    echo "PRODUCTION_WORKER_LAUNCH=present"
else
    echo "PRODUCTION_WORKER_LAUNCH=missing"

    cp -a "$PROD_LOADER" "$RUN/beastmode_loader.before-worker-fix"

    cp "$P0TEST_LOADER" "$PROD_LOADER"
    chmod 0755 "$PROD_LOADER"

    echo "PRODUCTION_LOADER_REPLACED=1"
fi

echo
echo "PRODUCTION_LOADER_AFTER:"
sha256sum "$PROD_LOADER"

echo
echo "WORKER_REFERENCE:"
strings "$PROD_LOADER" | grep -F "p0_identity_worker.py" || true

###############################################################################
# Restart and verify service
###############################################################################

echo
echo "Restarting $SERVICE..."

systemctl restart "$SERVICE"

sleep 2

systemctl is-active --quiet "$SERVICE"

echo "SERVICE_ACTIVE=1"

echo
systemctl --no-pager --full status "$SERVICE" | sed -n '1,14p'

CGROUP="$(systemctl show -p ControlGroup --value "$SERVICE")"

if [ -z "$CGROUP" ]; then
    echo "ERROR: service cgroup not found"
    exit 1
fi

echo
echo "TARGET_CGROUP=$CGROUP"

CGROUP_PROCS="/sys/fs/cgroup${CGROUP}/cgroup.procs"

test -w "$CGROUP_PROCS"

echo "CGROUP_PROCS=$CGROUP_PROCS"

###############################################################################
# 2. VERIFY SYSTEMWIDE GUARD IS OPERATIONAL
###############################################################################

echo
echo "=== 2. VERIFY GUARD ==="

echo "SERVICE_JOURNAL_BEFORE:"
journalctl -u "$SERVICE" -n 20 --no-pager \
    | tee "$RUN/journal-before.txt"

echo
echo "LOADER_PROCESSES:"
pgrep -a -f 'beastmode_loader|p0_identity_worker' \
    | tee "$RUN/processes.txt" || true

echo
echo "WORKER_PROCESSES:"
pgrep -a -f 'p0_identity_worker.py' \
    | tee "$RUN/worker-processes.txt" || true

###############################################################################
# 3. RUN IDENTITY-SPOOF TEST
###############################################################################

echo
echo "=== 3. IDENTITY-SPOOF TEST ==="

TEST_SCRIPT="$RUN/spoof-test.sh"

cat > "$TEST_SCRIPT" <<'EOF'
exec -a cat /usr/bin/yes
EOF

chmod 0755 "$TEST_SCRIPT"

echo "TEST:"
cat "$TEST_SCRIPT"

echo
echo "Launching spoof candidate..."

"$TEST_SCRIPT" &
TEST_PID=$!

echo "TEST_PID=$TEST_PID"

sleep 0.10

if ! kill -0 "$TEST_PID" 2>/dev/null; then
    echo "TEST_DIED_BEFORE_CGROUP=1"
    wait "$TEST_PID" || true
    TEST_STATUS=$?
else
    echo "$TEST_PID" > "$CGROUP_PROCS"
    echo "TEST_CGROUP_PLACED=1"

    set +e
    wait "$TEST_PID"
    TEST_STATUS=$?
    set -e

    echo "TEST_STATUS=$TEST_STATUS"
fi

###############################################################################
# 4. DETERMINE KILLED / AUDITED
###############################################################################

echo
echo "=== 4. RESULT ==="

sleep 1

journalctl -u "$SERVICE" \
    --since "$STAMP" \
    --no-pager \
    | tee "$RUN/journal-after.txt"

echo
echo "TEST_STATUS=$TEST_STATUS"

if [ "$TEST_STATUS" -eq 137 ]; then
    echo "RESULT=KILLED_SIGKILL"
else
    echo "RESULT=NOT_SIGKILL"
fi

echo
echo "RECENT_IDENTITY_EVENTS:"
journalctl -u "$SERVICE" -n 30 --no-pager \
    | grep -Ei 'beastmode|identity|exec|mismatch|block|kill|audit' \
    | tee "$RUN/identity-events.txt" || true

###############################################################################
# 5. ONLY IF BYPASS SURVIVES: INSPECT OBSERVATION / ENFORCEMENT BOUNDARY
###############################################################################

if [ "$TEST_STATUS" -eq 137 ]; then
    echo
    echo "=== PASS: SPOOF DID NOT BYPASS ENFORCEMENT ==="
    echo
    echo "No patch required for this test."
    echo "Proceed to next adversarial identity case."
    exit 0
fi

echo
echo "=== 5. POSSIBLE BYPASS DETECTED ==="

echo "The spoof candidate survived."
echo "NO PATCH WILL BE APPLIED AUTOMATICALLY."
echo

echo "=== PRODUCTION LOADER STRINGS ==="
strings "$PROD_LOADER" \
    | grep -Ei 'identity|argv|cmdline|comm|exe|worker|block|audit|kill' \
    | tee "$RUN/loader-identity-strings.txt" || true

echo
echo "=== WORKER IDENTITY REFERENCES ==="
grep -nEi \
    'argv|cmdline|comm|/proc|exe|identity|mismatch|block|audit|kill' \
    "$WORKER" \
    | tee "$RUN/worker-identity-references.txt" || true

echo
echo "=== SERVICE ENVIRONMENT ==="
systemctl show "$SERVICE" \
    -p ExecStart \
    -p ControlGroup \
    -p MainPID \
    -p ActiveState \
    -p SubState \
    | tee "$RUN/service-state.txt"

echo
echo "=== WORKER PROCESS TREE ==="
ps -eo pid,ppid,pgid,sid,user,args \
    | grep -E 'beastmode|p0_identity_worker|COMMAND' \
    | tee "$RUN/process-tree.txt" || true

echo
echo "=== TEST PROCESS CHECK ==="
pgrep -a -f '/usr/bin/yes' \
    | tee "$RUN/surviving-yes.txt" || true

echo
echo "=== BYPASS REPRODUCED ==="
echo "Run directory:"
echo "$RUN"
echo
echo "STOPPING BEFORE PATCH."
echo "Inspect the observation/enforcement boundary, patch it, then rerun this same harness."

exit 42