#!/usr/bin/env python3
# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import ctypes
import argparse
import bisect
import json
import os
import signal
import sys
import subprocess
import shutil
import time
import hashlib
import queue
import threading
from pathlib import Path
from datetime import datetime


BASE = Path(__file__).resolve().parent.parent / "build" / "process_baseline"
CANDIDATE_ROOT = BASE
INDEX = Path(__file__).resolve().parent.parent / "build" / "database" / "memory_master_index.tsv"
SORT_INDEX = Path(__file__).resolve().parent.parent / "build" / "database" / "memory_master_index_sort32.tsv"
SORT_OFFSET = 32
SORT_WIDTH = 32

WATCHDOG_ROOT = Path(__file__).resolve().parent.parent / "build" / "watchdog"
LIVE_ROOT = WATCHDOG_ROOT / "live"
LOG_ROOT = WATCHDOG_ROOT / "logs"
EVENT_LOG = LOG_ROOT / "watchdog.jsonl"

WINDOW = 10
EXPANDED_WINDOW = 100
POLL_SECONDS = 5.0
EXPECTED_MATCH = 99.0

FAST_COMPARE_SO = WATCHDOG_ROOT / "fast_compare.so"

_fast_compare_lib = None
_fast_compare_fn = None


def init_fast_compare():
    global _fast_compare_lib
    global _fast_compare_fn

    if _fast_compare_fn is not None:
        return

    _fast_compare_lib = ctypes.CDLL(
        str(FAST_COMPARE_SO)
    )

    _fast_compare_fn = _fast_compare_lib.count_equal_bytes

    _fast_compare_fn.argtypes = [
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_size_t,
    ]

    _fast_compare_fn.restype = ctypes.c_size_t

TARGETS = {
    "sleep": "/bin/sleep",
    "cat": "/bin/cat",
    "echo": "/bin/echo",
}


def parse_maps(path):
    data = json.loads(path.read_text())

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("mappings", "maps", "records"):
            if isinstance(data.get(key), list):
                return data[key]

    raise RuntimeError(f"Unsupported maps format: {path}")


def resolve_reference_identity(executable):
    executable = str(executable)
    basename = Path(executable).name

    if not INDEX.is_file():
        raise RuntimeError(f"memory master index missing: {INDEX}")

    basename_match = None

    with INDEX.open("r") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.startswith("fingerprint\t"):
                continue

            parts = line.split("\t")
            if len(parts) < 5:
                continue

            directory = parts[1]
            name = parts[2]
            path = parts[3]

            if path == executable:
                return directory

            if name == basename and basename_match is None:
                basename_match = directory

    if basename_match is not None:
        return basename_match

    raise RuntimeError(
        f"no crystal identity for executable: {executable}"
    )


def load_reference_run(name, run):
    root = BASE / name / f"run{run:02d}"
    return (root / "memory.bin").read_bytes()


def build_reference_crystal(name):
    memories = [
        load_reference_run(name, r)
        for r in range(1, 5)
    ]

    hidden = load_reference_run(name, 5)

    if len({len(x) for x in memories}) != 1:
        raise RuntimeError(
            f"REFERENCE SIZE MISMATCH for {name}"
        )

    size = len(memories[0])

    invariant = bytearray(size)
    mask = bytearray(size)

    for i in range(size):
        value = memories[0][i]

        if all(m[i] == value for m in memories[1:]):
            invariant[i] = value
            mask[i] = 1

    return {
        "size": size,
        "invariant": invariant,
        "mask": mask,
    }, hidden


def mapping_blob(root, start, length=None):
    if length is not None:
        exact = root / f"{start:016x}_{length:x}.bin"

        if exact.exists() and exact.stat().st_size == length:
            return exact

    prefix = f"{start:016x}_"

    for p in root.glob(prefix + "*.bin"):
        if length is None or p.stat().st_size == length:
            return p

    if length is not None:
        for p in root.rglob(f"{start:016x}_{length:x}.bin"):
            if p.is_file() and p.stat().st_size == length:
                return p

    return None


def load_candidate(d):
    metadata = json.loads(
        (d / "metadata.json").read_text()
    )

    maps = parse_maps(d / "maps.json")

    chunks = []

    for m in maps:
        if m.get("state") not in (None, "CAPTURED"):
            continue

        start = int(m["start"])
        end = int(m["end"])
        length = end - start

        blob = mapping_blob(
            d,
            start,
            length
        )

        if blob is None:
            continue

        data = blob.read_bytes()

        if len(data) != length:
            continue

        chunks.append(data)

    memory = b"".join(chunks)

    return {
        "metadata": metadata,
        "memory": memory,
        "size": len(memory),
        "mask": bytearray(b"\x01") * len(memory),
    }


def fingerprint(memory):
    """
    Locality-preserving fingerprint used by memory_master_index.tsv.

    Eight fixed regions are reduced to 16-bit mean-byte values,
    followed by total memory size.
    """

    size = len(memory)

    if size == 0:
        return 0

    values = []

    for n in range(8):
        start = (size * n) // 8
        end = (size * (n + 1)) // 8

        if end <= start:
            mean = 0
        else:
            total = sum(memory[start:end])
            mean = total // (end - start)

        values.append(mean & 0xffff)

    value = size & 0xffffffffffffffff

    for mean in values:
        value = (value << 16) | mean

    return value


def load_index():
    keys = []
    rows = []

    with SORT_INDEX.open("r") as f:
        for line in f:
            line = line.rstrip("\n")

            if not line:
                continue

            parts = line.split("\t")

            if len(parts) < 6:
                continue

            if parts[0] == "sort_key_hex":
                continue

            sort_key = bytes.fromhex(parts[0])
            key = int(parts[1])
            directory = parts[2]
            name = parts[3]
            path = parts[4]
            size = int(parts[5])

            keys.append(sort_key)
            rows.append({
                "key": key,
                "dir": directory,
                "name": name,
                "path": path,
                "size": size,
            })

    return keys, rows


def compare(sample, target):
    size = min(
        len(sample),
        target["size"]
    )

    if size == 0:
        return 0, 0, 0.0

    # The current P0 target mask is all ones.
    # Therefore every byte in the comparable range is tested.
    tested = size

    init_fast_compare()

    sample_buf = (ctypes.c_uint8 * size).from_buffer_copy(
        sample[:size]
    )

    invariant_buf = (
        ctypes.c_uint8 * size
    ).from_buffer(
        target["invariant"]
    )

    matched = int(
        _fast_compare_fn(
            sample_buf,
            invariant_buf,
            size
        )
    )

    pct = matched / tested * 100.0

    return matched, tested, pct


def resolve_pid(pid):
    proc = Path(f"/proc/{pid}")

    if not proc.exists():
        raise RuntimeError(
            f"PID {pid} does not exist"
        )

    try:
        exe = os.readlink(f"/proc/{pid}/exe")
    except OSError as e:
        raise RuntimeError(
            f"cannot resolve /proc/{pid}/exe: {e}"
        )

    return exe


def find_pids_for_path(path):
    target = os.path.realpath(path)
    found = []

    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue

        pid = int(entry.name)

        try:
            exe = os.path.realpath(
                os.readlink(f"/proc/{pid}/exe")
            )
        except OSError:
            continue

        if exe == target:
            found.append(pid)

    return sorted(found)


def read_live_maps(pid):
    maps = []

    with open(f"/proc/{pid}/maps", "r") as f:
        for line in f:
            parts = line.rstrip("\n").split(None, 5)

            if len(parts) < 5:
                continue

            address, perms, offset, dev, inode = parts[:5]
            path = parts[5] if len(parts) == 6 else ""

            start, end = address.split("-", 1)

            maps.append({
                "start": int(start, 16),
                "end": int(end, 16),
                "length": int(end, 16) - int(start, 16),
                "perms": perms,
                "file_offset": int(offset, 16),
                "dev": dev,
                "inode": int(inode),
                "path": path,
            })

    return maps


def read_live_memory(pid, address, length):
    with open(
        f"/proc/{pid}/mem",
        "rb",
        buffering=0
    ) as f:
        f.seek(address)
        return f.read(length)


def capture_live_pid(pid, executable, retain_stop=False):
    """
    Capture the actual running PID.

    The target is stopped before maps/mem are read so the memory
    image cannot change underneath the acquisition.
    """

    proc = Path(f"/proc/{pid}")

    if not proc.exists():
        raise RuntimeError(
            f"PID {pid} disappeared before capture"
        )

    LIVE_ROOT.mkdir(
        parents=True,
        exist_ok=True
    )

    capture_dir = LIVE_ROOT / (
        f"{Path(executable).name}_"
        f"{time.strftime('%Y%m%d_%H%M%S')}_"
        f"{pid}"
    )

    capture_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    stopped = False

    try:
        os.kill(pid, signal.SIGSTOP)
        stopped = True

        deadline = time.time() + 2.0

        while time.time() < deadline:
            state = Path(
                f"/proc/{pid}/status"
            ).read_text(errors="replace")

            for line in state.splitlines():
                if line.startswith("State:"):
                    if "T" in line or "t" in line:
                        deadline = 0
                    break

            if deadline == 0:
                break

            time.sleep(0.005)

        maps = read_live_maps(pid)
        records = []

        for m in maps:
            if "r" not in m["perms"]:
                continue

            try:
                data = read_live_memory(
                    pid,
                    m["start"],
                    m["length"]
                )

                if len(data) != m["length"]:
                    records.append({
                        "mapping": m,
                        "state": "READ_FAILED",
                        "error": "SHORT_READ",
                        "message": (
                            f"{len(data)} != "
                            f"{m['length']}"
                        ),
                    })
                    continue

                digest = hashlib.sha256(
                    data
                ).hexdigest()

                filename = (
                    f"{m['start']:016x}_"
                    f"{m['length']:x}.bin"
                )

                with open(
                    capture_dir / filename,
                    "wb"
                ) as f:
                    f.write(data)

                records.append({
                    "mapping": m,
                    "state": "CAPTURED",
                    "sha256": digest,
                    "bytes": len(data),
                })

            except Exception as e:
                records.append({
                    "mapping": m,
                    "state": "READ_FAILED",
                    "error": type(e).__name__,
                    "message": str(e),
                })

        maps_out = []

        for r in records:
            m = dict(r["mapping"])

            if r["state"] == "CAPTURED":
                m["sha256"] = r["sha256"]
                m["bytes"] = r["bytes"]

            maps_out.append({
                **m,
                "state": r["state"],
                "error": r.get("error", ""),
            })

        metadata = {
            "path": executable,
            "resolved_path": executable,
            "pid": pid,
            "captured_unix": time.time(),
            "live_pid": True,
            "mapping_count": len(records),
        }

        (capture_dir / "metadata.json").write_text(
            json.dumps(
                metadata,
                indent=2
            )
        )

        (capture_dir / "maps.json").write_text(
            json.dumps(
                maps_out,
                indent=2
            )
        )

        return capture_dir

    finally:
        if stopped and not retain_stop:
            try:
                os.kill(pid, signal.SIGCONT)
            except ProcessLookupError:
                pass


def identify(capture_dir, target_name, keys, rows, crystal):
    candidate = load_candidate(capture_dir)

    fp = fingerprint(
        candidate["memory"]
    )

    sort_key = candidate["memory"][
        SORT_OFFSET:SORT_OFFSET + SORT_WIDTH
    ]

    pos = bisect.bisect_left(
        keys,
        sort_key
    )

    lo = max(
        0,
        pos - WINDOW
    )

    hi = min(
        len(rows),
        pos + WINDOW + 1
    )

    def evaluate(lo, hi):
        results = []

        for row in rows[lo:hi]:
            candidate_dir = (
                CANDIDATE_ROOT /
                row["dir"]
            )

            try:
                candidate_data = load_candidate(
                    candidate_dir
                )

                matched, compared, pct = compare(
                    candidate_data["memory"],
                    crystal
                )

                results.append({
                    "name": row["name"],
                    "path": row["path"],
                    "dir": row["dir"],
                    "matched": matched,
                    "compared": compared,
                    "pct": pct,
                })

            except Exception as e:
                print(
                    f"[WARN] {row['dir']}: {e}",
                    flush=True
                )

        results.sort(
            key=lambda x: (
                x["pct"],
                x["compared"]
            ),
            reverse=True
        )

        return results

    results = evaluate(lo, hi)

    expanded = False

    if not results or results[0]["pct"] < EXPECTED_MATCH:
        expanded = True

        lo = max(
            0,
            pos - EXPANDED_WINDOW
        )

        hi = min(
            len(rows),
            pos + EXPANDED_WINDOW + 1
        )

        results = evaluate(lo, hi)

    best = results[0] if results else None

    return {
        "fingerprint": fp,
        "index_position": pos,
        "window_start": lo,
        "window_end": hi,
        "expanded": expanded,
        "best": best,
        "results": results,
        "candidate_size": candidate["size"],
    }


def log_event(event):
    LOG_ROOT.mkdir(
        parents=True,
        exist_ok=True
    )

    with EVENT_LOG.open(
        "a",
        encoding="utf-8"
    ) as f:
        f.write(
            json.dumps(
                event,
                sort_keys=True
            ) + "\n"
        )


def run_once(pid):
    executable = resolve_pid(pid)

    name = Path(executable).name

    if name not in TARGETS:
        raise RuntimeError(
            f"PID {pid} executable {executable} "
            f"is not a configured target: "
            f"{', '.join(sorted(TARGETS))}"
        )

    print(
        f"[WATCH] PID      : {pid}",
        flush=True
    )
    print(
        f"[WATCH] Executable: {executable}",
        flush=True
    )
    print(
        f"[WATCH] P0 crystal: {name}",
        flush=True
    )

    # Capture immediately.  Do not perform expensive reference
    # construction before securing the process memory image.
    capture_dir = capture_live_pid(
        pid,
        executable,
        retain_stop=True
    )

    # P0 admission owns the constructor stop from this point onward.
    # The target is released only after classification.
    crystal, hidden = build_reference_crystal(
        name
    )

    keys, rows = load_index()

    if not keys:
        raise RuntimeError(
            "master index is empty"
        )

    result = identify(
        capture_dir,
        name,
        keys,
        rows,
        crystal
    )

    best = result["best"]

    if best is None:
        state = "ALERT"
    elif best["pct"] >= EXPECTED_MATCH:
        state = "NORMAL"
    else:
        state = "ALERT"

    event = {
        "timestamp": datetime.now().isoformat(),
        "state": state,
        "pid": pid,
        "executable": executable,
        "capture": str(capture_dir),
        "fingerprint": str(
            result["fingerprint"]
        ),
        "index_position": result["index_position"],
        "candidate_size": result["candidate_size"],
        "expanded": result["expanded"],
        "best": best,
    }

    log_event(event)

    print()
    print(
        f"[RESULT] {state}",
        flush=True
    )

    if best:
        print(
            f"[RESULT] identity : {best['name']}",
            flush=True
        )
        print(
            f"[RESULT] path     : {best['path']}",
            flush=True
        )
        print(
            f"[RESULT] match    : "
            f"{best['pct']:.4f}%",
            flush=True
        )
        print(
            f"[RESULT] bytes    : "
            f"{best['matched']:,}/"
            f"{best['compared']:,}",
            flush=True
        )

    print(
        f"[RESULT] index pos : "
        f"{result['index_position']:,}",
        flush=True
    )

    print(
        f"[RESULT] window    : "
        f"{result['window_start']:,}.."
        f"{result['window_end'] - 1:,}",
        flush=True
    )

    print(
        f"[RESULT] expanded  : "
        f"{result['expanded']}",
        flush=True
    )

    print(
        f"[RESULT] capture   : "
        f"{capture_dir}",
        flush=True
    )

    if state == "NORMAL":
        try:
            os.kill(pid, signal.SIGCONT)
        except ProcessLookupError:
            pass
    else:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    return state

def observer_snapshot():
    snapshot = {}

    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue

        pid = int(entry.name)

        try:
            exe = os.readlink(
                f"/proc/{pid}/exe"
            )
        except (
            FileNotFoundError,
            PermissionError,
            ProcessLookupError,
            OSError
        ):
            continue

        try:
            raw = Path(
                f"/proc/{pid}/cmdline"
            ).read_bytes()

            argv = [
                x.decode(
                    "utf-8",
                    "replace"
                )
                for x in raw.split(b"\x00")
                if x
            ]

        except (
            FileNotFoundError,
            PermissionError,
            ProcessLookupError,
            OSError
        ):
            argv = []

        snapshot[pid] = {
            "exe": exe,
            "argv": argv,
        }

    return snapshot


def observer_is_p0_gate(info):
    """
    Identify the P0 execution gate's interpreter stage.

    This is infrastructure, not a trusted executable identity.
    The same PID must still be re-evaluated after execve().
    """
    argv = info.get("argv", [])

    if info.get("exe") == "/usr/bin/python3.11":
        print(
            f"[P0-DIAG] gate argv={argv!r}",
            flush=True
        )

    if len(argv) < 2:
        return False

    try:
        gate_path = os.path.realpath(argv[1])
    except Exception:
        return False

    return gate_path == os.path.realpath("/data/p0gate.py")


def observer_is_shell_child(pid, shell_pid):
    """
    Test mode scope: only direct children of the shell that launched
    the observer are considered executions.

    This excludes unrelated systemd/service processes while allowing
    commands entered directly at the launching shell.
    """
    try:
        status = Path(
            f"/proc/{pid}/status"
        ).read_text()

        for line in status.splitlines():
            if line.startswith("PPid:"):
                ppid = int(
                    line.split()[1]
                )
                return ppid == shell_pid

    except (
        FileNotFoundError,
        PermissionError,
        ProcessLookupError,
        OSError,
        ValueError
    ):
        pass

    return False


def execution_observer(interval, shell_pid=None):
    """
    Observe newly created direct children of the launching shell.

    Detection is independent from P0 classification.  A worker queue
    prevents a long P0 comparison from blocking detection of subsequent
    executions.
    """
    observer_pid = os.getpid()
    observer_ppid = (
        shell_pid
        if shell_pid is not None
        else os.getppid()
    )

    baseline = observer_snapshot()
    seen = set(baseline)

    # Track observed executable identity so same-PID execve()
    # transitions are admitted as a NEW identity.
    observed_exe = {
        pid: info["exe"]
        for pid, info in baseline.items()
    }

    work_queue = queue.Queue()

    print("[P0-OBSERVER] ACTIVE", flush=True)
    print(f"[P0-OBSERVER] shell PID: {observer_ppid}", flush=True)
    print(f"[P0-OBSERVER] baseline: {len(baseline):,} processes", flush=True)
    print("[P0-OBSERVER] workers: 4", flush=True)
    print("[P0-OBSERVER] waiting for new execution...", flush=True)

    logger = shutil.which("logger")

    def classify_worker(worker_id):
        while True:
            item = work_queue.get()

            if item is None:
                work_queue.task_done()
                return

            pid, info = item
            exe = info["exe"]
            argv = info["argv"]
            command = " ".join(argv) if argv else exe

            print()
            print(
                f"[P0-WORKER-{worker_id}] PID      : {pid}",
                flush=True
            )
            print(
                f"[P0-WORKER-{worker_id}] command  : {command}",
                flush=True
            )
            print(
                f"[P0-WORKER-{worker_id}] /proc/exe: {exe}",
                flush=True
            )

            if logger:
                subprocess.run(
                    [
                        logger,
                        "-t",
                        "P0-WATCHDOG",
                        "--",
                        f"EXEC pid={pid} exe={exe} argv={command!r}"
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False
                )

            try:
                state = run_once(pid)

                if logger:
                    subprocess.run(
                        [
                            logger,
                            "-t",
                            "P0-WATCHDOG",
                            "--",
                            f"STATE pid={pid} state={state}"
                        ],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        check=False
                    )

            except Exception as e:
                print(
                    f"[P0-WORKER-{worker_id}] ERROR: {e}",
                    flush=True
                )

                if logger:
                    subprocess.run(
                        [
                            logger,
                            "-t",
                            "P0-WATCHDOG",
                            "--",
                            f"ERROR pid={pid} exe={exe} error={e!r}"
                        ],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        check=False
                    )

            finally:
                work_queue.task_done()

    workers = []

    for worker_id in range(1, 5):
        t = threading.Thread(
            target=classify_worker,
            args=(worker_id,),
            name=f"p0-classifier-{worker_id}",
            daemon=True
        )
        t.start()
        workers.append(t)

    try:
        while True:
            current = observer_snapshot()

            new_pids = sorted(
                pid
                for pid in current
                if pid not in seen
                and pid != observer_pid
                and observer_is_shell_child(
                    pid,
                    observer_ppid
                )
            )

            for pid in new_pids:
                info = current[pid]

                print(
                    f"[P0-EXEC] PID      : {pid}",
                    flush=True
                )
                print(
                    f"[P0-EXEC] command  : "
                    f"{' '.join(info['argv']) if info['argv'] else info['exe']}",
                    flush=True
                )
                print(
                    f"[P0-EXEC] /proc/exe: {info['exe']}",
                    flush=True
                )

                # The P0 gate's interpreter is infrastructure.
                # Do not classify it as the target identity.
                # Its same-PID execve() transition is still observed
                # and queued below.
                gate_infra = observer_is_p0_gate(info)
                print(
                    f"[P0-DIAG] NEW PID {pid}: "
                    f"gate_infra={gate_infra} "
                    f"exe={info['exe']!r} "
                    f"argv={info['argv']!r}",
                    flush=True
                )

                if not gate_infra:
                    work_queue.put((pid, info))

                seen.add(pid)

            for pid, info in current.items():
                previous_exe = observed_exe.get(pid)

                if (
                    previous_exe is not None
                    and previous_exe != info["exe"]
                    and pid != observer_pid
                    and observer_is_shell_child(
                        pid,
                        observer_ppid
                    )
                ):
                    print(
                        f"[P0-DIAG] EXEC TRANSITION PID {pid}: "
                        f"{previous_exe} -> {info['exe']}",
                        flush=True
                    )

                    # Same-PID execve(): queue the NEW observed identity.
                    # The P0 gate interpreter is infrastructure; do not
                    # classify it as a target. Its next execve() transition
                    # remains observable and will be queued normally.
                    if not observer_is_p0_gate(info):
                        work_queue.put((pid, info))

                observed_exe[pid] = info["exe"]

            seen.update(current)

            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n[P0-OBSERVER] stopping", flush=True)

        for _ in workers:
            work_queue.put(None)

        return 0

def main():
    parser = argparse.ArgumentParser(
        description="P0 Memory Identity Watchdog"
    )

    group = parser.add_mutually_exclusive_group(
        required=False
    )

    group.add_argument(
        "--pid",
        type=int
    )

    group.add_argument(
        "--path"
    )

    parser.add_argument(
        "--once",
        action="store_true"
    )

    parser.add_argument(
        "--interval",
        type=float,
        default=POLL_SECONDS
    )

    parser.add_argument(
        "--observe",
        action="store_true"
    )

    parser.add_argument(
        "--shell-pid",
        type=int,
        default=None
    )

    args = parser.parse_args()

    if not args.observe and args.pid is None and args.path is None:
        parser.error(
            "one of the arguments --pid --path is required "
            "unless --observe is specified"
        )

    if os.geteuid() != 0:
        print(
            "[ERROR] watchdog must run as root",
            file=sys.stderr
        )
        return 1

    if not INDEX.exists():
        print(
            f"[ERROR] missing index: {INDEX}",
            file=sys.stderr
        )
        return 1

    keys, rows = load_index()

    if args.observe:
        print("=" * 72)
        print("P0 MEMORY IDENTITY EXECUTION OBSERVER")
        print("=" * 72)
        print()
        print(
            f"Sort index:  {SORT_INDEX}"
        )
        print(
            f"Entries:     {len(rows):,}"
        )
        print(
            f"Expected:    {EXPECTED_MATCH:.2f}%"
        )
        print(
            f"Interval:    {args.interval:.3f}s"
        )
        print()

        return execution_observer(
            args.interval,
            args.shell_pid
        )

    print("=" * 72)
    print("P0 MEMORY IDENTITY WATCHDOG")
    print("=" * 72)
    print()
    print(
        f"Master index: {INDEX}"
    )
    print(
        f"Entries:      {len(rows):,}"
    )
    print(
        f"Window:       ±{WINDOW}"
    )
    print(
        f"Expanded:     ±{EXPANDED_WINDOW}"
    )
    print(
        f"Threshold:    {EXPECTED_MATCH:.2f}%"
    )
    print()

    if args.pid is not None:
        pid = args.pid

    else:
        pids = find_pids_for_path(
            args.path
        )

        if not pids:
            print(
                f"[ERROR] no running process found "
                f"for {os.path.realpath(args.path)}"
            )
            return 1

        if len(pids) > 1:
            print(
                "[INFO] multiple matching PIDs:"
            )

            for p in pids:
                print(
                    f"       {p}"
                )

            print()
            print(
                "[ERROR] use --pid to select one"
            )
            return 1

        pid = pids[0]

    if args.once:
        try:
            run_once(pid)
            return 0
        except Exception as e:
            print(
                f"[ERROR] {e}",
                file=sys.stderr
            )
            return 1

    while True:
        try:
            if not Path(
                f"/proc/{pid}"
            ).exists():
                print(
                    f"[ERROR] PID {pid} exited"
                )
                return 1

            run_once(pid)

        except KeyboardInterrupt:
            print()
            print("[STOP] watchdog stopped")
            return 0

        except Exception as e:
            print(
                f"[ERROR] {e}",
                file=sys.stderr
            )

        time.sleep(
            max(0.1, args.interval)
        )


if __name__ == "__main__":
    sys.exit(main())