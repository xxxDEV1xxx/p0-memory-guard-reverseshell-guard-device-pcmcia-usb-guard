#!/bin/bash
# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

set -euo pipefail

ROOT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
BUILD="$ROOT/build"
PACKAGE_BUILD="$ROOT/../build"
WATCHDOG="$PACKAGE_BUILD/watchdog"

CLANG="/data/lib-ext/usr/bin/clang-14"
CC="${CC:-gcc}"
LIBBPF="/data/lib-ext/usr/lib/x86_64-linux-gnu"

mkdir -p "$BUILD" "$WATCHDOG"
find "$BUILD" -maxdepth 1 -type f -delete
rm -f "$WATCHDOG"/*

echo "[+] Building P0 comparison library"
"$CC" -O2 -fPIC -shared     "$ROOT/fast_compare.c"     -o "$WATCHDOG/fast_compare.so"

echo "[+] Building enforcement BPF object"
"$CLANG" -O2 -g -target bpf \
    -D__TARGET_ARCH_x86 \
    -I/usr/include/x86_64-linux-gnu \
    -I/data/lib-ext/usr/include \
    -c "$ROOT/beastmode.bpf.test.c" \
    -o "$BUILD/beastmode.bpf.o"

echo "[+] Building global enforcement BPF object"
"$CLANG" -O2 -g -target bpf \
    -D__TARGET_ARCH_x86 \
    -I/usr/include/x86_64-linux-gnu \
    -I/data/lib-ext/usr/include \
    -c "$ROOT/beastmode.bpf.test.c" \
    -o "$BUILD/beastmode.bpf.global-enforce.o"

echo "[+] Building enforcement loader"
"$CC" -O2 -Wall -Wextra \
    -I/data/lib-ext/usr/include \
    "$ROOT/beastmode_loader.enforce.c" \
    -o "$BUILD/beastmode_loader" \
    -L"$LIBBPF" \
    -Wl,-rpath,"$LIBBPF" \
    -lbpf

echo "[+] Building global enforcement loader"
"$CC" -O2 -Wall -Wextra \
    -I/data/lib-ext/usr/include \
    "$ROOT/beastmode_loader.global-enforce.c" \
    -o "$BUILD/beastmode_loader.global-enforce" \
    -L"$LIBBPF" \
    -Wl,-rpath,"$LIBBPF" \
    -lbpf

echo
echo "=== ARTIFACTS ==="
file     "$WATCHDOG/fast_compare.so" \
    "$BUILD/beastmode.bpf.o" \
    "$BUILD/beastmode.bpf.global-enforce.o" \
    "$BUILD/beastmode_loader" \
    "$BUILD/beastmode_loader.global-enforce"

echo
echo "=== GLOBAL LOADER OBJECT ==="
strings "$BUILD/beastmode_loader.global-enforce" |
    grep 'beastmode.bpf.global-enforce.o' || true

echo
echo "[+] Build complete"