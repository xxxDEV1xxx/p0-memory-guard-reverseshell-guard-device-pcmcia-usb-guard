/*
Copyright (c) 2026 Christopher T. Williams

## License

Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.

Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.
*/

size_t count_equal_bytes(
    const uint8_t *a,
    const uint8_t *b,
    size_t n
)
{
    size_t matched = 0;

    for (size_t i = 0; i < n; ++i)
        matched += (a[i] == b[i]);

    return matched;
}