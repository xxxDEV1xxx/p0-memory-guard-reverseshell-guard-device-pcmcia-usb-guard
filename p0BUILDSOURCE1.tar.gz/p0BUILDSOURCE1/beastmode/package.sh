#!/bin/bash
# Copyright (c) 2026 Christopher T. Williams
#
# ## License
#
# Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.
#
# Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

set -euo pipefail

ROOT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
PARENT="$(dirname "$ROOT")"
NAME="P0-memory-identity-beastmode-test"
STAGE="/data/${NAME}-package"
ARCHIVE="/data/${NAME}.tar.gz"

echo "[+] Preparing staging directory: $STAGE"

python3 - "$STAGE" "$ROOT" <<'PY'
import os
import shutil
import sys
from pathlib import Path

stage = Path(sys.argv[1])
root = Path(sys.argv[2])

if stage.exists():
    shutil.rmtree(stage)

stage.mkdir(parents=True)

# Copy the complete project tree.
dst = stage / "P0-memory-identity-beastmode"
shutil.copytree(
    root,
    dst,
    symlinks=True,
    ignore=shutil.ignore_patterns(
        ".package-stage",
        "*.tar.gz",
    ),
)

# Copy the package service unit into the bundle.
service_src = root.parent / "p0-memory-identity-beastmode-test.service"
if service_src.exists():
    service_dst = dst / "p0-memory-identity-beastmode-test.service"
    shutil.copy2(service_src, service_dst)
else:
    raise SystemExit(f"missing package service: {service_src}")


print(f"staged: {stage}")
PY

echo "[+] Recording build environment"

{
    echo "P0 Memory Identity Beastmode build environment"
    echo "=============================================="
    echo
    echo "date:"
    date -u
    echo
    echo "hostname:"
    hostname
    echo
    echo "kernel:"
    uname -a
    echo
    echo "clang:"
    /data/lib-ext/usr/bin/clang-14 --version || true
    echo
    echo "gcc:"
    gcc --version | head -n 1 || true
    echo
    echo "bpftool:"
    bpftool version || true
    echo
    echo "make:"
    make --version | head -n 1 || true
    echo
    echo "libbpf:"
    find /data/lib-ext/usr/lib -maxdepth 3 \
        \( -name 'libbpf.so*' -o -name 'libbpf.a' \) \
        -ls 2>/dev/null || true
} > "$STAGE/BUILD-ENVIRONMENT.txt"

echo "[+] Recording executable/tool paths"

{
    command -v gcc || true
    command -v make || true
    command -v bpftool || true
    command -v ld || true
    command -v ar || true
    command -v objcopy || true
    command -v readelf || true
    command -v file || true
    echo "/data/lib-ext/usr/bin/clang-14"
} > "$STAGE/TOOL-PATHS.txt"

echo "[+] Recording service installation source"

systemctl cat p0-memory-identity-beastmode.service \
    > "$STAGE/SERVICE-UNIT-LIVE.txt" 2>&1 || true

echo "[+] Recording project inventory"

(
    cd "$STAGE"
    find P0-memory-identity-beastmode -type f -o -type l |
        sort
) > "$STAGE/FILE-LIST.txt"

echo "[+] Creating SHA-256 manifest"

(
    cd "$STAGE"
    find . -type f -print0 |
        sort -z |
        xargs -0 sha256sum
) > "$STAGE/SHA256SUMS.txt"

echo "[+] Creating archive"

python3 - "$STAGE" "$ARCHIVE" <<'PY'
import sys
import tarfile
from pathlib import Path

stage = Path(sys.argv[1])
archive = Path(sys.argv[2])

if archive.exists():
    archive.unlink()

with tarfile.open(archive, "w:gz") as tar:
    tar.add(stage, arcname=stage.name)

print(archive)
PY

echo
echo "=============================================="
echo "PACKAGE READY"
echo "=============================================="
ls -lh "$ARCHIVE"
echo
echo "SHA256:"
sha256sum "$ARCHIVE"
echo
echo "Contents:"
tar -tzf "$ARCHIVE" | head -40
echo
echo "Total archived entries:"
tar -tzf "$ARCHIVE" | wc -l