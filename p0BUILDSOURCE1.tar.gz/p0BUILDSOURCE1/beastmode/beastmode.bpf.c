/*
Copyright (c) 2026 Christopher T. Williams

## License

Permission is granted to use, copy, modify, and distribute this software solely for non-commercial research, testing, and security-analysis purposes, provided that the copyright notice and this permission notice are retained.

Commercial use, sale, marketplace distribution, or monetization of this software, in whole or in part, is strictly prohibited without prior written consent from the author.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.
*/

char LICENSE[] SEC("license") = "GPL";

struct trace_event_raw_sys_enter {
    __u64 unused;
    long syscall_nr;
    unsigned long args[6];
};

struct trace_event_raw_sched_process_exec {
    __u64 common_type_flags_pid;
    __u32 filename;
    __s32 pid;
    __s32 old_pid;
};

struct beastmode_event {
    __u32 pid;
    __u32 uid;
    __u64 cgroup;
    char comm[16];
    char claimed[64];
    __u32 match;
    __u32 reason;
};

struct claimed_exec_state {
    char claimed[64];
};

struct {
    __uint(type, BPF_MAP_TYPE_LRU_HASH);
    __uint(max_entries, 4096);
    __type(key, __u32);
    __type(value, struct claimed_exec_state);
} claimed_exec SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, __u64);
} target_cgroup SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 20);
} events SEC(".maps");

static __always_inline int in_target_cgroup(void)
{
    __u32 key = 0;
    __u64 *target;

    target = bpf_map_lookup_elem(&target_cgroup, &key);
    if (!target)
        return 0;

    /* target_cgroup == 0 means GLOBAL enforcement. */
    if (*target == 0)
        return 1;

    return bpf_get_current_cgroup_id() == *target;
}

SEC("tracepoint/syscalls/sys_enter_execve")
int beastmode_execve(struct trace_event_raw_sys_enter *ctx)
{
    const char *const *argv;
    const char *filename_ptr;
    char filename[64] = {};
    __u32 pid;
    struct beastmode_event *e;

    /* GLOBAL MODE - watch all cgroups */
// if (!in_target_cgroup())
//     return 0;

    argv = (const char *const *)ctx->args[1];

    if (!argv)
        return 0;

    if (bpf_probe_read_user(
            &filename_ptr,
            sizeof(filename_ptr),
            &argv[0]) < 0)
        return 0;

    if (!filename_ptr)
        return 0;

    if (bpf_probe_read_user_str(
            filename,
            sizeof(filename),
            filename_ptr) < 0)
        return 0;

    pid = (__u32)(bpf_get_current_pid_tgid() >> 32);

     * Preserve the claimed identity across exec.
     * The resulting process image is observed later by
     * sched_process_exec.
    {
        struct claimed_exec_state state = {};

        __builtin_memcpy(
            state.claimed,
            filename,
            sizeof(state.claimed));

        bpf_map_update_elem(&claimed_exec, &pid, &state, BPF_ANY);
    }

    return 0;
}

SEC("tracepoint/sched/sched_process_exec")
int beastmode_process_exec(struct trace_event_raw_sched_process_exec *ctx)
{
    __u32 pid;
    struct claimed_exec_state *state;
    struct beastmode_event *e;

    /* GLOBAL MODE - watch all cgroups */
// if (!in_target_cgroup())
//     return 0;

    pid = (__u32)(bpf_get_current_pid_tgid() >> 32);

    state = bpf_map_lookup_elem(&claimed_exec, &pid);

    e = bpf_ringbuf_reserve(&events, sizeof(*e), 0);
    if (!e)
        return 0;

    e->pid = pid;
    e->uid = (__u32)bpf_get_current_uid_gid();
    e->cgroup = bpf_get_current_cgroup_id();
    e->match = 1;
    e->reason = 0;

    bpf_get_current_comm(e->comm, sizeof(e->comm));

    if (state)
        __builtin_memcpy(
            e->claimed,
            state->claimed,
            sizeof(e->claimed));

    bpf_ringbuf_submit(e, 0);

    if (state)
        bpf_map_delete_elem(&claimed_exec, &pid);

    return 0;
}
